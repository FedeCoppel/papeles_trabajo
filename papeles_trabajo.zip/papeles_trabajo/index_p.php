<head>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script> -->
</head>
<?php
session_start();
//header("Access-Control-Allow-Origin: *");
$_SESSION['G_token']= $_GET['ec_token'];

//$_SESSION['G_token'] = '681f7835a1ce8bd345c35d9074d48e1c1c5d696b';

if(isset($_GET['ec_token'])){	
	echo "<input id='tkn' type='hidden' value='".$_GET['ec_token']."'/>";
	?>		
		<!--<script src="js/script.php?ruta=coldfusion/opciones.cfm&posicion=oeste&titulo=Coldfusion" type="text/javascript" language="javascript1.2"></script>-->
        
		
		<script>
		// $.getScript("js/script.php?nameApp=Aps&ruta=aps/validar_empresa.cfm&posicion=oeste&titulo=&ms=<?php echo time(); ?>",function(){
		$.getScript("js/script.php?ruta=./east.cfm&posicion=oeste&titulo=&ms=<?php echo time(); ?>",function(){
			// alert("bienvenido");
		});	
		</script>       

	<?php
}else{
	//Header("Location: ../login.php");
	?>
		<script>window.location = "cierrasesion.php"</script>*

	<?php
}

?>	
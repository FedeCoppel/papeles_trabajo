<?php
/*****************************************************************

Autor:  Ernesto Diego Sanchez Tellaeche
Cambio: Aplicar compresion GZ al cargado de los elementos
******************************************************************/
ob_start("ob_gzhandler");
if ( isset($_REQUEST['pag']) )
{
	$url = $_REQUEST['pag'];
	unset($_REQUEST['pag']);
	unset($_REQUEST['PHPSESSID']);

	header("Content-type: text/javascript; charset: UTF-8");	
	include $url;
}
else if ( isset($_REQUEST['type']) ) //Se mandan cargar las librerias JS y CSS
{
	if ( $_REQUEST['type'] == "js" )
	{
		header("Content-type: text/javascript; charset: UTF-8");
		include $_REQUEST['js'];
	}
}
ob_end_flush();
?>
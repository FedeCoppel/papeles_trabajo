<?php
Class BuildMenu{
	var $cnxn = "";
	
	function BuildMenu($cnxn=""){
		$this->cnxn = $cnxn;	
	}
	
	//--- Iniciamos estructura del menu ---//
	function inicio(){
		$aux = "<div class='sc_menu'>";
		return $aux;
	}
		
	//--- Cada uno de las opciones del menu es agregado aqui, solo continue la secuencia ---//
	function get_menu($index){	
		$count = 0;
		$rs = $this->cnxn->query("SELECT intranet_administracion_menu_titulo,intranet_administracion_menu_icono,intranet_administracion_menu_archivo FROM intranet_administracion_menu ORDER BY intranet_administracion_menu_id");
		foreach($rs as $row){
			$a[$count] = $this->option($row["intranet_administracion_menu_titulo"],$row["intranet_administracion_menu_icono"],$row["intranet_administracion_menu_archivo"]);
			$count++;
		}
		$rs = null;
		return $a[$index];
	}
	
	//--- Para la aplicacion que aun no se han cargado y esta en los permisos de puesto ---//
	function get_app($id){	
		$rs = $this->cnxn->query("SELECT intranet_administracion_menu_titulo,intranet_administracion_menu_icono,intranet_administracion_menu_archivo FROM intranet_administracion_menu WHERE intranet_administracion_menu_id=$id AND intranet_administracion_menu_status='A'");
		foreach($rs as $row){
			return $this->option($row["intranet_administracion_menu_titulo"],$row["intranet_administracion_menu_icono"],$row["intranet_administracion_menu_archivo"]);
		}
		$rs = null;
	}

	//--- Para las aplicaciones que aun no se han cargado y estan en los permisos de puesto ---//
	function get_appz($ids){
		$str_menu = "";
		$rs = $this->cnxn->query("SELECT intranet_administracion_menu_titulo,intranet_administracion_menu_icono,intranet_administracion_menu_archivo FROM intranet_administracion_menu WHERE intranet_administracion_menu_id IN (".$ids.") AND intranet_administracion_menu_status='A'");
		foreach($rs as $row){
			$str_menu .= $this->option($row["intranet_administracion_menu_titulo"],$row["intranet_administracion_menu_icono"],$row["intranet_administracion_menu_archivo"]);
		}
		$rs = null;
		return $str_menu;
	}

	//--- Cerramos estructura del menu ---//
	function cierre(){
		$aux = " </div>";
		return $aux;
	}

	//--- Construye la opcion segun el titulo, icono y archivo ---//
	function option($title, $icon, $file){
		if(!file_exists("plugins/jquery-vertical-menu/icons/$icon")){ $icon="anonymous.png"; }
		if($file!=""){ $file = " onclick=cargaMenu('$file','#centro','')"; }
		return "<a title='$title' href='javascript:;' $file >
					<img src='plugins/jquery-vertical-menu/icons/$icon' alt='$title' width='34px' height='34px' />
				</a>";
	}
}
?>
<?php
include('cnfg/sessions.php');
$sess = new Session();
if (!$sess)
	$error_desc = "Ha ocurrido un error al iniciar session!";
$G_user = $sess->get_var('G_user');
//--------------------------------------------------

if(!empty($G_user)){
	Header("Location: index.php");
}

/* -----------------------------
 * Configuracion para Login:
 * -----------------------------
 * Parametro para desplegar el tipo de Login:
 *		H = Validacion con Huella
 *		C = Validacion Comun (Usuario y Password)
 *		D = Validacion Default (Empleado y Password)
 *		M = Validacion Mexico Only (Empleado y Password)
 * Parametros de conexion para Usuario y Password en una Base de Datos:
 *		$type = Tipo de base de datos a utilizar en la validacion. Nota: a utilizar... [sqlsrv -> Microsoft SQL Server, mysql -> MySQL, pg -> PostgreSQL]
 *		$host = Host o servidor donde esta la base de datos
 *		$user = Usuario de la base de datos
 *		$pass = Contrase�a de la base de datos
 *		$database = Base de datos a utilizar
 */
 
include('login.class.php');
$warLogin = new Login();
if ($_GET['login']==996)
	echo $warLogin->Caminito("M", $type, $host, $user, $pass, $database, $table_db, $field_usr, $field_pwd, $port);
else if($_GET['login']==2)
	echo $warLogin->Caminito("D", $type, $host, $user, $pass, $database, $table_db, $field_usr, $field_pwd, $port);
else
	echo $warLogin->Caminito("H", $type, $host, $user, $pass, $database, $table_db, $field_usr, $field_pwd, $port); 
?>
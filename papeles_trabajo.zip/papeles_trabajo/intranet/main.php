<?php
header("Expires: Tue, 11 Feb 1985 22:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");	
header("Content-Type: text/html; charset=iso-8859-1");
//header("Content-Type: text/html; charset=UTF-8");
?>
<table width="100%" align="center" border="0" style="margin-top:120px;">
	<tr>
		<td align="center">
			<img src="images/intranet_logo_big_transparent.png" border="0"/>
		</td>
	</tr>
</table>
<script>
try {
	// START [CHAT]
	xhr_messages.abort();
	xhr_conversations.abort();
	xhr_conversation.abort();
	xhr_sendmsg.abort();
	xhr_lastvisit.abort();

	listening_messages = null;
	xhr_messages = null;
	xhr_conversations = null;
	xhr_conversation = null;
	xhr_sendmsg = null;
	xhr_lastvisit = null;
	// END [CHAT]
}catch (e) { }
</script>
<?php
//Agregar en todas las paginas que lleven sesion
require("cnfg/sessions.php");
$sess = new Session();
if (!$sess)
	$error_desc = "Ha ocurrido un error al iniciar session!";
$G_nemp = $sess->get_var("G_nemp");
$G_puesto = $sess->get_var("G_puesto");
//--------------------------------------------------


require("cnfg/pdo_database.class.php");
require("cnfg/database.cnfg.php");
require("menu.class.php");
if(isset($_GET['menu']))
{
	$db = new wArLeY_DBMS($pg_admin_db_type, $pg_admin_db_server, $pg_admin_db_db, $pg_admin_db_user, $pg_admin_db_pass, $pg_admin_db_port);
	$dbObj = $db->Cnxn();
	if($dbObj==false) die("500");

	if(($r2=$db->query_single("SELECT intranet_administracion_tokenstring FROM intranet_administracion_token WHERE intranet_administracion_token = '$_GET[ec_token]' "))===false)
	{
		echo "Error al cargar las opciones";
	}
	else
	{
		$arreglo = explode("|", $r2);
		//echo $_REQUEST[G_country];
		
		$sess->set_var('G_nemp', $arreglo[0]);
		//$sess->set_var('G_country', $_REQUEST[G_country]);
		$sess->set_var('G_user', $$arreglo[1]);
		$sess->set_var('G_name', $arreglo[2]);
		$sess->set_var('G_centro', (int)$arreglo[3]);
		//$sess->set_var('G_centrodesc', $arreglo[4]);
		$sess->set_var('G_seccion', (int)$arreglo[5]);
		$sess->set_var('G_puesto', (int)$arreglo[6]);
		//$sess->set_var('G_puestodesc', $arreglo[7]);
		/*$sess->set_var('G_sexo', $G_sexo);
		$sess->set_var('G_idioma', $G_idioma);
		$sess->set_var('G_ipfrom', $_SERVER['REMOTE_ADDR']);
		$sess->set_var('G_timeout', time());	*/	
	}

	if(($r=$db->query_first("SELECT intranet_administracion_menu_titulo,intranet_administracion_menu_icono,intranet_administracion_menu_archivo FROM intranet_administracion_menu WHERE intranet_administracion_menu_id = ".$_GET['menu']))===false){
		//echo "Error al cargar las opciones";
	}else{
		echo "<script>cargaMenu('".$r['intranet_administracion_menu_archivo']."?ec_token=".$_GET['ec_token']."&regreso=".$_GET['regreso']."','#centro','')</script>";
	}
	$db->disconnect();
}else{
	if(trim($G_nemp)=="") die("403");
	//Se establece conexion a la base de datos
	$db = new wArLeY_DBMS($pg_admin_db_type, $pg_admin_db_server, $pg_admin_db_db, $pg_admin_db_user, $pg_admin_db_pass, $pg_admin_db_port);
	$dbObj = $db->Cnxn();
	if($dbObj==false) die("500");

	$menu = new BuildMenu($db);

	//--- Valor i que corresponde al valor entero de los privilegios de cada usuario ---//
	$rs = $db->query("SELECT intranet_administracion_usuarios_menu FROM intranet_administracion_usuarios WHERE intranet_administracion_usuarios_numemp='". $G_nemp ."'");

	foreach($rs as $row){
		$i = $row["intranet_administracion_usuarios_menu"];
	}
	$rs = null;

	$rs = $db->query("SELECT intranet_administracion_menu_id FROM intranet_administracion_menu WHERE intranet_administracion_menu_publica='1' And intranet_administracion_menu_status='A'");

	foreach ($rs as $row){
		$i[$row['intranet_administracion_menu_id']-1] = '1';
	}
	$rs = null;

	$menu_array = "";
	$rs = $db->query("SELECT menu FROM intranet_administracion_puesto WHERE puesto_id=".$G_puesto);

	foreach($rs as $row){
		$menu_array = explode(",",$row["menu"]);
	}
	$rs = null;

	//--- Agregamos al output la estructura del menu ---//
	$output = $menu->inicio();
	$s = 0;
	$bandera = false;
	$makein = "";
	$makeout = "";

	/*--- Descomponemos el entero de privilegios en sus distintos privilegios y los agregamos a output en complejidad lineal, sin gasto de memoria ---*/
	$strleni=strlen($i);
	for ($s=0;$s<$strleni;$s++){
		if ($i[$s]==1){
		
			$existe=0;		
			$rs = $db->query("SELECT count(*) as cositas FROM intranet_administracion_menu WHERE intranet_administracion_menu_id=".($s+1)." And intranet_administracion_menu_status='A'");
			foreach ($rs as $cosita){
				$existe = $cosita["cositas"];
			}
			$rs = null;

			if($makein=="" && $existe==1){ $makein = $s; }else{ $makein .= ",".$s; }

			if($existe == 1){
				$bandera = true;
				$output .= $menu->get_menu($s);
			}
		}
	}
	if($makein!='' && $menu_array!=''){
		$menu_array_result = array_diff($menu_array,explode(",",$makein));
		foreach($menu_array_result as $id){	
			if($makeout==""){ 
				$makeout = $id; 
			}else{ 
				$makeout .= ",".$id; 
			}
		}
	}
	/*$menu_array_result = array_diff($menu_array,explode(",",$makein));
	foreach($menu_array_result as $id){	
		if($makeout==""){ 
			$makeout = $id; 
		}else{ 
			$makeout .= ",".$id; 
		}
	}*/
	if($makeout!=""){
		$bandera = true;
		$output .= $menu->get_appz($makeout); 
	}

	//--- Agregamos el cierre a la estructura del menu ---//
	$output .= $menu->cierre();
	echo $output;
	//echo "<!-- Disponible: $menu_disponible , MakeIn: $makein , MakeOut: $makeout -->";
	if(!$bandera){ 
		echo "<script> toogleAppMenu(false, false); changeSystemTitle('Usted no cuenta con aplicaciones asignadas, intente reiniciando la sesion!'); cargaAjax('main.php','#centro',''); </script>";
	}else{
		echo "";
	}
	$db = null;
}
?>
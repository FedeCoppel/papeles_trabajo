<?php 	
session_start();
if(isset($_SESSION['G_nemp'])){	
	$varopc = $_GET['opc'];
	$varformato = $_GET['formato']; 
	$varpestana = $_GET['pestana'];
	$varnom_columna = $_GET['nom_columna'];
	$varnom_columna = strtoupper($varnom_columna);
	$varnom_columna_conespacio = $varnom_columna;
	$varnom_columna_sinespacio = str_replace(" ","_",$varnom_columna);
	$vartipo_dato = $_GET['tipo_dato'];
	$varcaracteres = $_GET['caracteres']; 
	
	require("../cnfg/pdo_database.class.php");
	require_once "../cnfg/conexiones.php";
	
	$db_papeles_trab = new wArLeY_DBMS ($db_papeles_trab_type, $db_papeles_trab_server, $db_papeles_trab_db, $db_papeles_trab_user, $db_papeles_trab_pass, $db_papeles_trab_port);
	$dbObj = $db_papeles_trab->Cnxn();

	$error2= $db_papeles_trab->getError();
	
	if($dbObj==false){
		echo $error2;
		die("Error en la conexion");
	} 
	
	$separa_pestana =explode("-", $varpestana); 	
	$nom_pestana = $separa_pestana[1];
	$nom_tabla = $separa_pestana[1].'_'.$varformato.'_'.$separa_pestana[0];
	$nom_tabla = str_replace(" ","_",$nom_tabla);	
	
	$query = "select count(idu_columna) from ctl_columnas where idu_formato = $varformato and idu_pestana = $separa_pestana[0]";
	$num_columnas = $db_papeles_trab->query($query);
	
	//**********************
	foreach($num_columnas as $f)
	{
		$columnas = $f[0];
	}
	//**********************
	$columnas +=1;
	
	$query_2 = "INSERT INTO ctl_columnas VALUES($varformato, $separa_pestana[0], $columnas, '$varnom_columna_conespacio', $vartipo_dato, $varcaracteres)";
	$res2 = $db_papeles_trab->query($query_2);
	
	if($res2){
		$resultado=1;	
	}else{		
		$resultado=0;
	}
			
	if($separa_pestana[0] != 1) 
	{
		$varnom_columna_sinespacio = $varnom_columna_sinespacio.'_'.$varformato.'_'.$separa_pestana[0].'_'.$columnas; 
	}
	
	$tipo_dato_columna = "";
	
	switch($vartipo_dato)
	{
		case '1':
			$tipo_dato_columna = "integer NOT NULL DEFAULT 0";
			break;
		case '2':
			$tipo_dato_columna = "character varying(".$varcaracteres.") ";
			break;
		case '3':
			$tipo_dato_columna = "double precision NOT NULL DEFAULT 0";
			break;
		case '4':
			$tipo_dato_columna = "timestamp without time zone";
			break;
		case '5':
			$tipo_dato_columna = "character varying(30)";
			break;
	}	
	
	$insertar = "ALTER TABLE ".$nom_tabla." ADD COLUMN ".$varnom_columna_sinespacio." ".$tipo_dato_columna;
	
	$res_insert=$db_papeles_trab->query($insertar); 	
	
	if($res_insert){
		$resultado=1;	
	}else{		
		$resultado=0;
	}
		
	echo $resultado;

}else{
	echo 'La sesi&oacute;n establecida ya expir&oacute;';
}	

$db_papeles_trab->disconnect();		
?>
<?php 

    require_once("cnfg/conexiones.php");
    session_destroy();
    header("Location: ".$URL_OUT);
?>
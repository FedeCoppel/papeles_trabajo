<?php

if (!isset($_GET["ec_token"])) {

?>

<script>

	console.log(window.location)
	let token = window.location.href.split("?")[1].split("=")[1]
	let url = "index.php?menu=74&ec_token="+token
	window.location=url

</script>

<?php

die();

}



//Agregar en todas las paginas que lleven sesion
//require('cnfg/session_refresh.php');
require('cnfg/sessions.php');


$sess = new Session();
if (!$sess)
	$error_desc = "Ha ocurrido un error al iniciar session!";
$G_nemp = $sess->get_var("G_nemp");
$G_user = $sess->get_var('G_user');
$G_name = $sess->get_var('G_name');
$G_idioma = $sess->get_var('G_idioma');
$_SESSION['EC_regreso']=$_GET['regreso'];
$_SESSION['G_token']= $_GET['ec_token'];
//$_SESSION['G_country']=$_GET['G_country'];
//$_SESSION['pais'] = $_GET['G_country'];
// if($_GET['G_country'] == "MEX"){
// 	$_GET['G_country'] = "MX";
// }else if ($_GET['G_country'] == "ARG"){
// 	$_GET['G_country'] = "AR";
// }
//--------------------------------------------------

switch($G_idioma){
	case "mx":
		$title_close_session = "Cerrar sesion de sistema";
		$lbl_close_session = "Cerrar Sesion";
		$lbl_loading = "cargando";
		break;
	case "us":
		$title_close_session = "End session";
		$lbl_close_session = "Logout";
		$lbl_loading = "loading";
		break;
	case "br":
		$title_close_session = "Fechar do sistema";
		$lbl_close_session = "Fechar";
		$lbl_loading = "cargando";
		break;
}

if( (empty($G_nemp) || trim($G_nemp)=="") && !isset($_GET['menu']) ){ 
    header("Location: login.php"); 
    die; 
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en" style="overflow:hidden;">
<head>
	<title>Intranet Coppel</title>
	<meta http-equiv="content-type" content="text/html; charset=iso-8859-1"/>
	<meta http-equiv="Cache-Control" content="no-store"/>
	<meta http-equiv="Pragma" content="no-cache"/>
	<meta http-equiv="Expires" content="0"/>
	
	<link href="images/key_coppel.ico" rel="shortcut icon" type="image/x-icon"/>
	<link href="images/key_coppel.ico" rel="icon" type="image/x-icon"/>
	
	<!-- Archivos javascript vitales para el desarrollo de cualquier aplicacion -->	
	<!-- by Ernesto Diego Sanchez Tellaeche se manda a comprimir el contenido de los JS -->
<?php
$ms = "&".date("YmdHi");//microtime(true) ;
echo "
	<script src='zip.php?pag=js/jquery.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=js/jquery-ui.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=js/jquery.ui.datepicker-es.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/jquery.timepicker/timepicker.ui.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/jquery.printElement.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=js/live_functions.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/jquery.jqGrid/js/i18n/grid.locale-es.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/jquery.jqGrid/js/jquery.jqGrid.min.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/jquery-layout/jquery.layout.min.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/fullcalendar/fullcalendar.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=js/jWarValidator.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=js/jquery.form.js$ms' type='text/javascript' charset='utf-8'></script>
	<script src='zip.php?pag=plugins/jquery.multiselect/jquery.multiselect.js$ms' type='text/javascript' charset='utf-8'></script>
";
?>

	<link rel="stylesheet" type="text/css" href="plugins/css/redmond/jquery.ui.all.css"/>
	<link rel="stylesheet" type="text/css" href="plugins/jquery.jqGrid/css/ui.jqgrid.css"/>
	<link rel="stylesheet" type="text/css" href="plugins/jquery.jqGrid/src/css/ui.multiselect.css"/>
	<link rel="stylesheet" type="text/css" href="plugins/jquery-vertical-menu/css/vertical-menu.css"/>
	<link rel="stylesheet" type="text/css" href="plugins/fullcalendar/fullcalendar.css"/>
	<link rel="stylesheet" type="text/css" href="css/coppel-template.css"/>
	<link rel="stylesheet" type="text/css" href="css/style_custom.css"/>
	<link rel="stylesheet" type="text/css" href="css/jWarValidator.css"/>
	<link rel="stylesheet" type="text/css" href="plugins/jquery.multiselect/jquery.multiselect.css"/>

	<script type="text/javascript" src="js/json.js"></script>

	<script type="text/javascript">
		//Variables globales bajo metodologia ajax.
		var myLayout;

		$(function(){
			preloadObjectsHide(true);
			setTimeout(function(){
				loadLayout();
			},500);
		});
		
		function loadLayout(){	

			var url = "menu.php<?php echo isset($_GET['menu'])?"?menu=".$_GET['menu']."&ec_token=".$_GET['ec_token']:""; ?>";
			$.when(
				$.ajax({
					type: "GET",
					url: url,
					async: false,
					success: function (data){
						if(data=="403"){
							alert("Es necesario que inicie sesion para continuar.");
							location.href = "login.php";
						}
						if(data=="500"){
							alert("Ha ocurrido un error de conexion, intente mas tarde.. (ip:64)");
							location.href = "login.php";
						}
						document.getElementById("img_closesession").style.visibility = "visible";
						setTimeout(function(){
							changeSystemTitle('Mis Aplicaciones');
							$("#centro").html(data);
						},500);				
					}
				})
			).done(
				function(){					
					myLayout = $('body').layout({ 
						applyDefaultStyles: true
						, enableCursorHotkey: false
						, north__spacing_open: 0 
						, north__minSize: 20
						, south__initClosed: true 	//estado inicial de panel cerrado o abierto segun el estatus
						, south__spacing_open: 0 	//espacio cuando el panel esta abierto para redimencinar y abrir
						, south__spacing_closed: 0  //espacio cuando el panel esta cerrado para redimencinar y abrir
						, south__closable: false
						, south__slidable: false
						, east__initClosed: true
						, east__slideTrigger_open: "click"	
						, east__closable: false
						, east__slidable: false
						, west__initClosed: true
						, west__slideTrigger_open: "click"
						, west__onclose_start: function(){
							changeIcnAppz;
							// STOP the pane from opening
							//return false; // false = Cancel
						}
						, west__closable: false
						, west__slidable: false
						, west__maxSize: 200
						, west__minSize: 200
						, west__spacing_open: 5
						, west__spacing_closed: 5
						, east__spacing_open: 5
						, east__spacing_closed: 5
						, east__maxSize: 50
						, east__minSize: 50
						, contentSelector: ".content" //Para que el div "content" sea el unico que tenga scroll
					});
					//myLayout.addPinBtn("#tbarPinWest", "west");
					//myLayout.addPinBtn("#tbarPinEast", "east");	

					setTimeout(function(){						
						preloadObjectsHide(false);
					},500);

					//Se configuran los idiomas
					$.datepicker.setDefaults($.datepicker.regional["es"]);
					$.timepicker.setDefaults($.timepicker.regional["es"]);
				}
			);
		}
	</script>
</head>
<body id="body-main">
	<div id="background-main" style="display: block; visibility: hidden; top:0px; border: 0px; width:100%; height:2000px; overflow: hidden; background: #FFFFFF;">
		<table border="0" width="100px" align="center" style="margin-top: 250px;"><tr><td align="center"><img src="images/loadinfo_1.gif" border="0"/><br><br><label style="color: #88B6D9; font-weight:bold;"><?php echo $lbl_loading; ?></label></tr></td></table>
	</div>
	<div class="ui-layout-north">
		<a href="http://<?php echo $_GET['regreso'] ?>/intranet" title="Ir al inicio"><img src="images/logo-coppel.png" width="109" height="21" align="absmiddle" border="0"/></a>
		<span class="header_text">Intranet Coppel</span>
		<span id='span_name' style="color:white; margin-left:15px;">&nbsp;<?php echo $G_name; ?></span>
		<span style="color:white; position:absolute; top:7px; right:15px;" title="<?php echo $title_close_session; ?>"><a href="cierrasesion.php<?php echo isset($_GET['menu'])?"?menu=".$_GET['menu']."&regreso=".$_GET['regreso']:""; ?>" style="color:white; text-decoration:none; font-weight:bold; font-size: 12px;"><?php echo $lbl_close_session; ?> <img src="images/exit.png" align="absmiddle" id="img_closesession" border="0" style="visibility:hidden;"/></a></span>
		
	</div>
	<div class="ui-layout-east" style="background:#777777;"> 
		<div class="header" style="padding-left: 10px !important;">Apps <!--<span id="tbarPinEast"></span>--></div>
		<div class="sc_menu_wrapper" id="este"></div>
	</div>
	<div class="ui-layout-center">
		<div id="header_btns" style="z-index: 500; width: 20px; height:20px !important; border-bottom: 1px solid #cee1ef; float:right; padding:0; margin-right:0px; margin-top:1px; background: url(plugins/css/redmond/images/ui-bg_glass_75_d0e5f5_1x400.png) !important;">
			<a id="header_btn_home" title="Cargar mis aplicaciones" href='#' onclick='goToIni(<?php echo isset($_GET['menu'])?"1,\"".$_GET['regreso']."\"":"0,\"".$_GET['regreso']."\""?>);' style="background: url(plugins/css/redmond/images/ui-bg_glass_75_d0e5f5_1x400.png) center !important;"><span id="header_img_home" class="header_img_home_opened"></span></a>
		</div>
		<div class="header" id="div_titulo_sistema"></div>
		<div class="content" id="centro" style="padding:0px !important; margin:0px !important;"></div>
	</div>
	<div class="ui-layout-west"> 
		<div class="header">Menu Sistema <!--<span id="tbarPinWest"></span>--></div>
		<div class="content_west" id="oeste"></div> 
	</div>
	<div class="ui-layout-south">Footer</div>
	<?php print_r($_SESSION); ?>
	<div class="dv_index_js_functions"></div>
</body>
</html>
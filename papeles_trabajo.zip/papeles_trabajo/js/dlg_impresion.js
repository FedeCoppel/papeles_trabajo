// JavaScript Document
//funcion que simula un alert en dialog. [Eleazar Castro]
function dlg_impresion( msj, titulo, div_impresion){  

		$("#"+div_impresion+"").printElement({
			overrideElementCSS: true
		});
		//$(this).dialog('close');
		//$(this).remove();
		// $(".toprint").jqprint();

	/*var div = $("<div title='"+titulo+"' style='font-size:12px; color: #2e6e9e;'>"+msj+"</div>");
	div.dialog({
		modal: true,
		height:600,
		width: 'auto',
		resizable:false,
		closeText: 'hide'
		,buttons:{ 'Imprimir': function(){
			$("#"+div_impresion+"").printElement({
				overrideElementCSS: true
			});
			//$(this).dialog('close');
			//$(this).remove();
			 $('.toprint').jqprint();
			//$(this).dialog('close');
			//$(this).remove();
			}			
		}
		,closeOnEscape: true
		,close:function(){
			$(this).dialog('destroy');
			$(this).remove();
		}
	});*/
} 
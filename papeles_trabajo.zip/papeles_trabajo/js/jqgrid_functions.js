// JavaScript Document
//--------------------------------------------------------------------------------------//
function myGrid(){
	this.obtener_de_registro=obtener_de_registro;	
	this.obtener_nu_total_registros=obtener_nu_total_registros;
	this.obtener_nu_total_paginas=obtener_nu_total_paginas;
	this.obtener_nu_registros_pagina_actual=obtener_nu_registros_pagina_actual;
	this.obtener_nu_pagina_actual=obtener_nu_pagina_actual;
	this.ir_a_primer_pagina=ir_a_primer_pagina;
	this.click_pagina=click_pagina;
	this.seleccionar_checkbox=seleccionar_checkbox;
	this.navegar_a_numero_pagina=navegar_a_numero_pagina;
	this.eliminar_objeto=eliminar_objeto;
	this.crear_objeto=crear_objeto;
	this.ocultar_columna=ocultar_columna;
	this.refrescar_grid=refrescar_grid;
}
//Funcion que obtiene las columnas de un renglon especificado en los parametros del control jqGrid
//Parametros:
//	grid_name='nombre del control jqGrid'
//	id_renglon='numero de renglon'
function obtener_de_registro(grid_name, id_renglon){
	return $("#"+grid_name).jqGrid('getRowData',id_renglon);
}
//--------------------------------------------------------------------------------------//
//Funcion que obtiene y retorna el numero total de registros contenidos en un control jqGrid
function obtener_nu_total_registros(grid_name){
	return $("#"+grid_name).jqGrid('getGridParam','records');
}
//--------------------------------------------------------------------------------------//
//Funcion que obtiene el renglon seleccionado por el usuario en el control jqGrid
function obtener_renglon_seleccionado(grid_name){
	var id_renglon;

	id_renglon=$("#"+grid_name).jqGrid('getGridParam','selrow');
	
	if(id_renglon)
		return obtener_de_registro(grid_name, id_renglon);
	else
		return null;
}
//--------------------------------------------------------------------------------------//
//Funcion que obtiene y retorna el numero total de paginas del control jqGrid
function obtener_nu_total_paginas(grid_name){
	var grid_total_pages;
	var grid_total_row;
	var grid_rows_on_page;
	
	//Numero total de registros
	grid_total_row = obtener_nu_total_registros(grid_name);	
	//Obtener numero de registros por pagina
	grid_rows_on_page = obtener_nu_registros_pagina_actual(grid_name);			
	//Obtener total de paginas
	grid_total_pages = Math.ceil(grid_total_row / grid_rows_on_page);								
	
	return grid_total_pages;
}
//------------------------------------------------------------------------------//
//Funcion para obtener el numero de registros obtenidos en la pagina actual, en el control jqGrid
function obtener_nu_registros_pagina_actual(grid_name){
	 return $("#"+grid_name).jqGrid('getGridParam','rowNum');
}
//------------------------------------------------------------------------------//
function obtener_nu_pagina_actual(grid_name){
	return $("#"+grid_name).jqGrid('getGridParam','page');
}
//--------------------------------------------------------------------------------------//
//Funcion para ir a la primer pagina del control jqGrid
function ir_a_primer_pagina(){
	$("#first").click();
}
//--------------------------------------------------------------------------------------//
//Funcion para simular de manera automatico el evento 'click' en el boton especificado en el parametro
//	de la barra de navegacion del control jqGrid
//Estos son los nombres de los botones de la barra de navegacion del control jqGrid
//	first
//	prev
//	user
//	next
//	last
//	records
function click_pagina(nombre_boton){
	$("#"+nombre_boton).click();
}
//--------------------------------------------------------------------------------------//
//Realizar automaticamente el evento seleccionar checkbox
//Parametros:
//	grid_name='nombre del control jqGrid'
//	id_row='Numero de renglon a seleccionar'
function seleccionar_checkbox(grid_name, id_row){
	$("#"+grid_name).jqGrid('setSelection',id_row);
}
//--------------------------------------------------------------------------------------//
//Funcion que traslada autom�ticamente al usuario a la p�gina especificada como par�metro, en el control jqGrid
function navegar_a_numero_pagina(grid_name, nu_pagina){
	var e='';

	$("#"+grid_name).jqGrid('setGridParam',{page:nu_pagina});//Simular click en siguiente p�gina
	e = $("#"+grid_name).trigger('reloadGrid');	//Pasar el controlador de evento a una variable

	return e;
}
//--------------------------------------------------------------------------------------//
//Funcion para eliminar objetos html de la pagina web dinamicamente.
//Parametros
//	obj_nombre='Nombre del control html a remover del DOM(Document Object Model)'
//Ejemplo
//	$("#txt_descripcion").remove();
function eliminar_objeto(obj_nombre){
	$("#"+obj_nombre).remove();
}
//--------------------------------------------------------------------------------------//
//Funcion para agregar objetos html a la pagina web de manera dinamica.
//Parametros:
//	div_contenedor='nombre del objeto div'
//	de_codigo_html='Codigo HTML a incrustar en la pagina web'
//Ejemplo
//	$("#div_menu_opciones_usuarios_agregar").append($('<input type=textbox name=txt_id_opcion_1 id=txt_id_opcion_1>'));
function crear_objeto(div_contenedor, de_codigo_html){
	$("#"+div_contenedor).append($(de_codigo_html));
	
}
//--------------------------------------------------------------------------------------//
//Funcion para ocultar la columna especificada como parametro en el control jqGrid
//Parametros:
//	grid_name='Nombre del control jqGrid'
//	column_name='Nombre de la columna a ocultar'
function ocultar_columna(grid_name, column_name){
	$("#"+grid_name).jqGrid('hideCol',["'"+column_name+"'"]);
}
//--------------------------------------------------------------------------------------//
//Funcion para refrescar la informacion del control jqGrid
//Parametros:
//	grid_name='Nombre del control jqGrid'
function refrescar_grid(grid_name){
	$("#"+grid_name).trigger('reloadGrid');
}
//--------------------------------------------------------------------------------------//
//Funcion para mostrar un mensaje al usuario en una ventana modal
//Parametros:
//	dialog_name: 'Nombre del dialogo a mostrar'
//	message: 'Mensaje a mostrar'
function mensaje_al_usuario(dialog_name, message){
	fnc_setMessage(dialog_name, message);
	fnc_openDialog(dialog_name);

	return true;
}
//--------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------//
//--------------------------------------------------------------------------------------//
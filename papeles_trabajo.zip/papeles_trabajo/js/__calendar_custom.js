function eliminarevento(id){
	$.ajax({
		type: "POST",
		url: "ajax/ajax_fechas.php",
		cache: false,
		data: "opc=eliminaevento&id="+id,
		success: function(d){
			if(d=="OK")
				actualizacalendario();
			else
				alert(d);
		},
		error: function(xhr,ajaxOptions,thrownError){
			alert(xhr.status);
			alert(thrownError);
		}
	});
}

function actualizacalendario(){
	$("#fullcalendar").html('<div align=\"center\" valign=\"middle\"><img src=\"images/loading.gif\" border=\"0\"></div>');
	$.ajax({
		url: "ajax/ajax_fechas.php",
		cache: false,
		type: "POST",
		data: "opc=actualiza",
		success: function(html){
			$("#fullcalendar").html("<script>"+html+"</script>");
//			$("#fullcalendar").html(html);
		}
	})
}

function actualizafechas(inicio, fin, id){
	alert(inicio + "-" + fin + "-" + id)
	$('#fullcalendar').html('<div align=\"center\" valign=\"middle\"><img src=\"images/loading.gif\" border=\"0\"></div>');
	$.ajax({
		type: 'POST',
		url: 'ajax/ajax_fechas.php',
		cache: false,
		data: 'opc=updatefecha&inicio='+inicio+'&fin='+fin+'&id='+id,
		success: function(h){
			if(h=='OK')
				actualizacalendario();
			else
				alert(h);
		},
		error:function (xhr, ajaxOptions, thrownError){
			alert(xhr.status);
			alert(thrownError);
		}  
	});	
}
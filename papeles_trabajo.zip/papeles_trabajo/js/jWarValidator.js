/* 	--- Creado por ---
	Evert Ulises German Soto 2010 - MIT License
	
	--- Version ---
	v1.7 BETA

	--- Configuracion ---
	mensajes en alert: "alert";
	mensajes en objeto: "objeto"; (para el objeto sera necesario crear un div o un td con id="jWar_Message" en el formulario)
*/
var jWarMessageConfig = "alert";

var msgError = "";
var codError = 0;
var control = "";

function jWarValidation(json_war){
	var objValues = Evaluador(json_war);
	var objMessage = document.getElementById("jWar_Message");
	var obj = objValues.control;
	
	if(objValues.codError==1){
		if(jWarMessageConfig=="alert"){	alert(objValues.msgError); }
		else{
			if(objMessage){	$('#jWar_Message').append('<div class="validacion" title="Click para ocultar este mensaje" onclick="close_message(this)">'+ objValues.msgError +'</div>'); }
			else{ alert(objValues.msgError); }
		}		
		if(obj){ obj.focus(); }		
		return false;
	}
	return true;
}

function Evaluador(json_war){
	var arr = json_war.objetos;
	var objError = "";
		
	if(!arr){ return; }
	for(var i = 0; i <= arr.length - 1; ++i) {
		var error = 0;
		var checkeados = "";
		var obj = "";
		
		var json = arr[i];
		var control_id = json.id;
		var control_desc = json.desc;
		var control_required = json.required;
		var control_tipo = json.tipo;
		var control_minsize = json.minsize;
		var control_maxsize = json.maxsize;
		var control_format = json.format;	
		
		if(document.getElementById(control_id)){ obj = document.getElementById(control_id); }
		else{
			objError = new errHandler("Error[996]: El control a validar aun no esta definido. \nContacte con el administrador del sistema.",1,obj);
			return objError;
		}
		
		// SE VALIDA SI ES REQUERIDO
		if(control_required==1){
			if(control_tipo.toLowerCase() == "checkbox" ){
				//alert("Elementos seleccionados = " + $("#"+control_id+" :checked").size());
				$("#"+control_id+" :checked").each(function() {
					//almacenamos los checks seleccionados usando la propiedad
					if(checkeados==""){ checkeados = $(this).val(); }
					else{ checkeados += "," + $(this).val(); }
				});
				
				if(checkeados==""){
					objError = new errHandler("El contenido del campo [" + control_desc + "] es requerido.",1,obj);
					return objError;
				}				
			}
			else{
				if(obj.value==""){
					objError = new errHandler("El contenido del campo [" + control_desc + "] es requerido.",1,obj);
					return objError;		
				}
			}
		}
		
		//Si es diferente de checkbox;
		if(control_tipo.toLowerCase() != "checkbox" ){
			//alert("Node Name: " + obj.nodeName + "; Type: " + obj.type);
			
			// SE VALIDA LA LONGITUD DEL CAMPO
			if(obj.value.length < control_minsize && obj.value!=""){
				objError = new errHandler("El campo [" + control_desc + "] debe de tener por lo menos [" + control_minsize + "] caracteres.",1,obj);
				return objError;
			}
			if(obj.value.length > control_maxsize){
				objError = new errHandler("El campo [" + control_desc + "] debe de tener maximo [" + control_maxsize + "] caracteres.",1,obj);
				return objError;
				//obj.value = obj.value.substring(0, control_maxsize);
			}
			
			// SE VALIDA EL TIPO DE DATO REQUERIDO
			var tipo = regexNeed(control_tipo);
			if(tipo[0]!=""){
				pattern = eval(tipo[0]);
				if((control_required==0 && obj.value!="") || control_required==1){
					if(!pattern.test(obj.value)){
						objError = new errHandler("El contenido del campo [" + control_desc + "] " + tipo[1],1,obj);
						return objError;
					}
				}
			}
		}
	}
	objError = new errHandler("",0,"");
	return objError;
}

function errHandler(mensaje, codigo, control) {
	this.msgError = mensaje;
	this.codError = codigo;
	this.control = control;
}

function fClear(json_war, persist){
	var arr = json_war.objetos;
	var objError = "";
	var objPersist = persist.split("|");
	var ctrl;
	var salta;
		
	if(!arr){ return; }
	for(var i = 0; i <= arr.length - 1; ++i) {
		var obj = "";
		
		var json = arr[i];
		var control_id = json.id;
		var control_tipo = json.tipo;
		
		//Si es un objeto persistente no lo limpia... se lo salta...
		salta = false;		
		for(var j=0; j<objPersist.length; ++j) {
			ctrl = objPersist[j];
			if(objPersist[j] == control_id){
				salta = true;
				break;
			}
		}

		if(salta==false){
			if(document.getElementById(control_id)){
				if(objPersist!=control_id){}
				obj = document.getElementById(control_id);
				//Si es diferente de checkbox;
				if(control_tipo.toLowerCase() != "checkbox" ){
					obj.value = "";
				}
				else{				
					$("#"+control_id+" :checked").each(function() {
						$(this).attr('checked', false);
					});
				}
			}
		}		
	}
	
	if(document.getElementById("btn_content")){	$("#btn_content").html('<input class="btn_jquery" type="submit" value="guardar" title="click para guardar"/>'); }
	$(".btn_jquery").button();
}

function show_message(obj){
	var rndNum = Math.floor(Math.random()*3);
	var func_appear = "";
	var func_dissapear = "";
	
	if(rndNum==0){
		func_appear = fadeIn();
		func_dissapear = fadeOut();
	}
	if(rndNum==1){
		func_appear = show();
		func_dissapear = hide();
	}
	if(rndNum==2){
		func_appear = slideDown();
		func_dissapear = slideUp();
	}
	$(obj).func_appear.delay(1000).func_dissapear;
}

function close_message(obj){
	if($(obj)){
		var rndNum = Math.floor(Math.random()*3);
		if(rndNum==0){
			$(obj).fadeOut(1000, function (){
				$(obj).remove();
			});
		}
		if(rndNum==1){
			$(obj).hide(1000, function (){
				$(obj).remove();
			});
		}
		if(rndNum==2){
			$(obj).slideUp(1000, function (){
				$(obj).remove();
			});
		}
	}
}

function regexNeed(valor){
	retorno = new Array(2);
	
	switch (valor){
		case "free":
			retorno[0] = "";
			retorno[1] = "";
			break;		
		case "telephone":
			retorno[0] = /([\+][0-9]{1,3}([ \.\-])?)?([\(]{1}[0-9]{3}[\)])?([0-9A-Z \.\-]{1,32})((x|ext|extension)[ ]?[0-9]{1,4})?/;
			retorno[1] = "no es un numero telefonico valido";
			break;
		case "email":
			retorno[0] = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/;
			retorno[1] = "no es un email valido";
			break;
		case "integer":
			retorno[0] = /^[-+]?\d+$/;
			retorno[1] = "no es un campo numerico";
			break;
		case "decimal":
			retorno[0] = /^[-+]?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)$/;
			retorno[1] = "no es un numero decimal";
			break;
		case "date":
			retorno[0] = /^\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4}$/;
			retorno[1] = "no es una fecha valida";
			break;
		case "ip":
			retorno[0] = /^([1-9][0-9]{0,2})+\.([1-9][0-9]{0,2})+\.([1-9][0-9]{0,2})+\.([1-9][0-9]{0,2})+$/;
			retorno[1] = "no es una IP valida";
			break;
		case "url":
			retorno[0] = /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/;
			retorno[1] = "no es una URL valida";
			break;
		case "numeric":
			retorno[0] = /^[0-9\ ]+$/;
			retorno[1] = "debe de ser numerico";
			break;
		case "text":
			retorno[0] = /^[a-zA-Z]+$/;
			retorno[1] = "debe de ser unicamente texto";
			break;
		case "noespecial":
			retorno[0] = /^[0-9a-zA-Z]+$/;
			retorno[1] = "debe de contener unicamente caracteres alfanumericos";
			break;
		default : 
			retorno[0] = "";
			retorno[1] = "";
			break;
	}
	return retorno;
}
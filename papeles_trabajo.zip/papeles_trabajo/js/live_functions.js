//Funcion que da vida al menu principal, lo hace Scrollable
function makeScrollable(wrapper, scrollable){
	// Get jQuery elements
	var wrapper=$(wrapper), scrollable=$(scrollable);
	
	// Hide images until they are not loaded
	scrollable.hide();
	var loading = $('<div class="loading"><img src="images/loader_webpages.gif" border="0" title="Cargando..."/></div>').appendTo(wrapper);
	
	// Set function that will check if all images are loaded
	var interval = setInterval(function(){
		var images = scrollable.find('img');
		var completed = 0;
		
		// Counts number of images that are succesfully loaded
		images.each(function(){
			if (this.complete) completed++;	
		});
		
		if (completed == images.length){
			clearInterval(interval);
			// Timeout added to fix problem with Chrome
			setTimeout(function(){
				loading.hide();
				// Remove scrollbars	
				wrapper.css({overflow: 'hidden'});
				scrollable.slideDown('slow', function(){
					enable();	
				});					
			}, 1000);	
		}
	}, 100);

	function enable(){
		// height of area at the top at bottom, that don't respond to mousemove
		var inactiveMargin = 99; //100					
		// Cache for performance
		var wrapperWidth = wrapper.width();
		var wrapperHeight = wrapper.height();
		// Using outer height to include padding too
		var scrollableHeight = scrollable.outerHeight() + 2*inactiveMargin;
		// Do not cache wrapperOffset, because it can change when user resizes window
		// We could use onresize event, but it's just not worth doing that 
		// var wrapperOffset = wrapper.offset();
		
		// Create a invisible tooltip
		var tooltip = $('<div class="sc_menu_tooltip"></div>').css('opacity', 0).appendTo(wrapper);
	
		// Save menu titles
		scrollable.find('a').each(function(){				
			$(this).data('tooltipText', this.title);				
		});
		
		// Remove default tooltip
		scrollable.find('a').removeAttr('title');		
		// Remove default tooltip in IE
		scrollable.find('img').removeAttr('alt');	
		
		var lastTarget;
		//When user move mouse over menu			
		wrapper.mousemove(function(e){
			// Save target
			lastTarget = e.target;
			var wrapperOffset = wrapper.offset();
			var tooltipLeft = e.pageX - wrapperOffset.left;
			// Do not let tooltip to move out of menu.
			// Because overflow is set to hidden, we will not be able too see it 
			tooltipLeft = Math.min(tooltipLeft, wrapperWidth - 60); //tooltip.outerWidth()); //75
			var tooltipTop = e.pageY - wrapperOffset.top + wrapper.scrollTop() - 40;
			// Move tooltip under the mouse when we are in the higher part of the menu
			if (e.pageY - wrapperOffset.top < wrapperHeight/2)
				tooltipTop += 70; //80
			tooltip.css({top: tooltipTop, left: tooltipLeft});
			// Scroll menu
			var top = (e.pageY -  wrapperOffset.top) * (scrollableHeight - wrapperHeight) / wrapperHeight - inactiveMargin;
			if (top < 0)
				top = 0;
			wrapper.scrollTop(top);
		});
		
		// Setting interval helps solving perfomance problems in IE
		var interval = setInterval(function(){
			if (!lastTarget) return;
			var currentText = tooltip.text();
			if (lastTarget.nodeName == 'IMG'){					
				// We've attached data to a link, not image
				var newText = $(lastTarget).parent().data('tooltipText');
				// Show tooltip with the new text
				if (currentText != newText)
					tooltip.stop(true).css('opacity', 0).text(newText).animate({opacity: 1}, 1000);
			}
		}, 200);
		
		// Hide tooltip when leaving menu
		wrapper.mouseleave(function(){
			lastTarget = false;
			tooltip.stop(true).css('opacity', 0).text('');
		});			
		
		/*
		//Usage of hover event resulted in performance problems
		scrollable.find('a').hover(function(){
			tooltip.stop().css('opacity', 0).text($(this).data('tooltipText')).animate({opacity: 1}, 1000);	
		}, function(){
			tooltip.stop().animate({opacity: 0}, 300);
		});
		*/			
	}
}

function AjaxPostEC(url, idtoloading, msj, datos, async){
		if(idtoloading=='overlay_EC')
			dialog_overlay_EC(msj);
		else
			$('#'+idtoloading).html('<div class=\"loading\" style=\"margin:3px !important; width: 200px; text-align: left;\"><img align=\"absmiddle\" src=\"images/loader_webpages.gif\" border=\"0\" width=\"18px\" style=\"padding-left: 5px;\"/>&nbsp; '+msj+'...&nbsp;</div>');
		setTimeout(function(){	
			$.ajax({
				type: 'POST',
				async: async,
				url: url,
				data: datos,
				cache: false,
				success: function(h){
					$('#'+idtoloading).html(h);
					if(idtoloading=='overlay_EC')
						$('#overlay_EC').dialog('close');

			       },
			       error: function(xhr, ajaxOptions, thrownError){
				      alert(xhr.status+' '+thrownError);
			       }
			      });
		},100);
	}

//Funcion para cargar JS y CSS desde el principio
function loadJSCSS(filename, filetype, media, cb){
	var fileref;
	if(filetype=="js"){
		fileref = document.createElement("script");
		fileref.setAttribute("async", false);
		fileref.setAttribute("type","text/javascript");
		fileref.setAttribute("src", filename);
	}
	else if(filetype=="css"){
		fileref = document.createElement("link");
		fileref.setAttribute("rel", "stylesheet");
		fileref.setAttribute("type", "text/css");
		if(media!=""){ fileref.setAttribute("media", media); }
		fileref.setAttribute("href", filename);
	}
	if(typeof fileref!="undefined"){
		document.getElementsByTagName("head")[0].appendChild(fileref);
	}

	var loaded = false;
	var loadFunction = function(){
		if(loaded)
			return;
		loaded = false;		
		if(isFunction){	cb; }
	}
	
	fileref.onload = loadFunction;
	fileref.onreadystatechange = loadFunction;
	document.getElementsByTagName("head")[0].appendChild(fileref);
}

function preloadObjectsHide(param){
	if(param==true){
		document.body.scroll = "no";
		document.getElementById("img_closesession").style.visibility = "hidden";
		document.getElementById("body-main").style.overflow = "hidden";	
		document.getElementById("background-main").style.visibility = "visible";
		document.getElementById("este").style.overflow = "hidden";
		document.getElementById("este").style.visibility = "hidden";
	}else{
		document.getElementById("body-main").style.overflow = "visible";
		document.getElementById("background-main").style.visibility = "hidden";
		$("#background-main").remove();
		document.getElementById("este").style.overflow = "visible";
		document.getElementById("este").style.visibility = "visible";
	}
}

function cargascripts(URL, apuntador){
	$.getScript(URL, function(){ retornaScript(parseInt(apuntador) + 1); });		
}

function isFunction(name){
	//Por: Evert Ulises German Soto
	//Que hace: Busca segun el parametro si esta como funcion en tiempo real.
	try{
		if (typeof name == 'string' && eval('typeof ' + name) == 'function') {
			return true;
		}
		else{
			return false;
		}
	}
	catch(e){
		return false;
	}
}

function tabsAjax_bck(){
	$("#tabs").tabs({
		async: false,
		cookie: { expires: 1 }, // store cookie for a day, without, it would be a session cookie
		cache: false,
		deselectable: false,
		collapsible: false,
		event: 'click',
		fx: { opacity: 'toggle' },
		selected: 0,
		ajaxOptions: {
			error: function( xhr, status, index, anchor ) {
				$(anchor.hash).html(
					"Couldn't load this tab. We'll try to fix this as soon as possible. " +
					"If this wouldn't be a demo." );
			}
		}
	}).find(".ui-tabs-nav").sortable({ axis: "x" });
}

function tabsAjax(){
	$("#tabs_ajax").tabs({
		async: true,
		cookie: { expires: 1 }, // store cookie for a day, without, it would be a session cookie
		cache: false,
		deselectable: false,
		collapsible: false,
		event: 'click',
		//fx: { opacity: 'toggle' },
		selected: 0,
		ajaxOptions: {
			error: function( xhr, status, index, anchor ) {
				$(anchor.hash).html("No se ha podido cargar este tab. Contacte con el administrador del sistema.");
			}
		}		
	});
	
	destroyDialog("tmp_dialog");
}

function transAccordion(){
	//document.getElementById("centro").innerHTML="";			
	if(document.getElementById("accordion")){			
		var icons = {
			header: "ui-icon-circle-arrow-e",
			headerSelected: "ui-icon-circle-arrow-s"
		/* 	'header': 'ui-icon-plus', 
			'headerSelected': 'ui-icon-minus' 
			'header': 'ui-icon-triangle-1-e', 
			'headerSelected': 'ui-icon-triangle-1-s' */
		};
		
		$(function() {
			var stop = false;
			$("#accordion")
				.accordion({
					header: "> div > h3",
					icons: icons,					
					active: 0,  //La opcion "#" aparecera abierta por defecto
					collapsible: true,
					autoHeight: false,					
					clearStyle: false,
					animated: 'bounceslide', //easeslide-bounceslide-slide
					event: 'click',
					fillSpace: false,
					navigation: true
				});
				/*.sortable({
					axis: "y",
					handle: "h3",
					stop: function() {
						stop = true;
					}
				});*/
			
			$("#accordion h3").click(function(event){
				if (stop) {
					event.stopImmediatePropagation();
					event.preventDefault();
					stop = false;
				}
			});
		});
	}
}

function destroyDialog(objId){
	$("#"+objId).dialog("destroy");
	if(document.getElementById(objId)){
		$("#"+objId).fadeOut(1000, function (){
			$("#"+objId).remove();
		});
	}
}

//funcion para abrir o cerrar los menus segun sus parametros booleanos. [Ulises German]
function toogleAppMenu(east, west){
	if(east===true){ myLayout.open('east'); }
	if(east===false){ myLayout.close('east'); }
	if(west===true){ myLayout.open('west'); }
	if(west===false){ myLayout.close('west'); }
}

function goToIni(){
	toogleAppMenu(true, false);
	changeSystemTitle("");
	document.getElementById("oeste").innerHTML = "";
	cargaAjax('main.php','#centro','');	
}

function changeIcnAppz(){
	var state = myLayout.state;
	if(!state.east.isClosed){
		toogleAppMenu(false,'');
		document.getElementById("header_btn_appz").title="Mostrar Aplicaciones";
	}else{
		toogleAppMenu(true,'');
		document.getElementById("header_btn_appz").title="Ocultar Aplicaciones";				
	}
}

function changeSystemTitle(titulo){
	document.getElementById("div_titulo_sistema").innerHTML = titulo;
	if(titulo!=""){ titulo = " - " + titulo; }
	document.title = "Intranet 2.0" + titulo;
}

function selectTab(seleccionado, tipo, contenedor, parametro){
	switch(tipo){
		case "captura":
			$("#tabs_ajax").tabs("option", "selected", 0);
			getContent(seleccionado, tipo, contenedor, parametro);
			break;
		case "listado":
			$("#tabs_ajax").tabs("option", "selected", 1);
			getContent(seleccionado, tipo, contenedor, parametro);
			break;
		default:
			alert("Error de seleccion");
			break;
	}
}

function getContent(seleccionado, tipo, contenedor, parametro){		
	var toLoad = "ajax/getForms.php?seleccionado="+seleccionado+"&tipo="+tipo+"&contenedor="+contenedor+"&parametro="+parametro;
	$("#"+contenedor).html('<p align="center" style="margin-top:55px; padding-bottom: 55px;"><img src="images/loadinfo_1.gif" width="48"/></p>');
			
	$.ajax({
		type: "GET",
		url: toLoad,
		async: true,
		timeout: 50000,
		success: function (data) {
			$("#"+contenedor).html(data);
		},
		error: function(request, error, thrownError){
			if (error == "timeout") {
				$("#"+contenedor).html("Se ha excedido el tiempo, intente de nuevo.");
			}
			else {
				error = thrownError;
				if(request.status==404){
					error = "La pagina solicitada no ha sido encontrada.";
				}
				error = "["+request.status+"] " + error;
				$("#"+contenedor).html("Error: " + error);
			}
		}
	});
}

//funcion que forza el cierre de sesion si este ya se checo y ha expirado. (para los archivos ajax)
function fnForceCloseSession(ruta){
	alert("Su sesion ha expirado.");
	if(ruta==""){
		location.href = "/intranet/cierrasesion.php";
	}else{
		location.href = "/"+ruta+"/cierrasesion.php";
	}
}

//funcion para recargar y verificar que no se bloquee la sesion. [Ulises German]
function sessionRefresh(){
	$.ajax({
		async: false,
		timeout: 60000, //60 segundos
		type: "GET",
		url: "check_session.php",
		success: function(data){
			if(isNaN(data)){
				if(data=="EXIT"){
					location.href = "cierrasesion.php";
				}
			}
		},
		error: function(request, error, thrownError){
			if (error == "timeout") {
				alert("Se ha excedido el tiempo, intente de nuevo.");
			}
			else {
				error = thrownError;
				if(request.status==404){
					error = "La pagina solicitada no ha sido encontrada.";
				}
				error = "["+request.status+"] " + error;
				alert("Error: " + error);
			}
		}
	});
}

//fuction validarToken v1.0: hace un post proc_fmsessions con un token dado y regresa una promesa con la respuesta [Luis Jesus Maldonado]
function validarToken(token) {

	return new Promise((resolve, reject) => {

		$.ajax({
			async:true,
			type: "POST",
			url: "./ajax/proc_cfmsessions.cfm",
			data: {			
				tkn:token
			},
			success: function(data) {

				resolve(data)
				
			},error:function (xhr, ajaxOptions, thrownError){
				resolve(xhr.status)
			}
			});	

	})
}

//funcion "cargaAjax" v1.2 - Ahora acepta funciones callback y maneja distintos tipos de errores. [Ulises German]
async function cargaAjax(webpage, info, fCallback, token=""){
	$(info).html('<div class="loading" style="margin:3px !important;"><img align="absmiddle" src="images/loader_webpages.gif" border="0" width="18px"/>&nbsp;cargando...&nbsp;</div>');

	if (token != "") {
		let validation = await validarToken(token)
		let arreglo = validation.split("|");
		let status = parseInt(arreglo[0]);
		
		if(status!=13){				
			window.location = "cierrasesion.php"
			return	
		}
	}
	
	$.ajax({
		async:true,
		timeout: 180000,
		type: "GET",
		url: webpage,
		success: function(data){
			$(info).html(data);
			
			var height_calc = ($('#body-main').height() - $('#centro').height()) - 55;
			//setTimeout(function(){
				var new_height = $('#centro').height() + height_calc;
				$('#centro').css('height', new_height+"px");
				//$('#centro').height(new_height);
				//document.getElementById('centro').style.height = new_height+"px";				
			//},100);
	
			if(fCallback){ fCallback(); }
		},
		error: function(request, error, thrownError){
			if (error == "timeout") {
				$(info).html("Se ha excedido el tiempo, intente de nuevo.");
			}
			else {
				error = thrownError;
				if(request.status==404){
					error = "La pagina solicitada no ha sido encontrada.";
				}
				error = "["+request.status+"] " + error;
				$(info).html("Error: " + error);
			}
		}
	});
}

//funcion "cargaMenu" v1.0 - Especial solo para cargar el menu. [Ulises German]
function cargaMenu(webpage, info, fCallback){
	//se agrega por default la ruta solo para realizar pruebas :)
	//webpage = "./index_p.php?ec_token=234554324refrefd&regreso=10.28.114.60";
	$(info).html('<div class="loading" style="margin:3px !important;"><img align="absmiddle" src="images/loader_webpages.gif" border="0" width="18px"/>&nbsp;cargando...&nbsp;</div>');
	$.ajax({
		async:true,
		timeout: 50000,
		type: "GET",
		url: webpage,
		success: function(data){
			$(info).html(data);
			toogleAppMenu(false, true);
			if(fCallback){ fCallback(); }
		},
		error: function(request, error, thrownError){
			if (error == "timeout") {
				$(info).html("Se ha excedido el tiempo, intente de nuevo.");
			}
			else {
				error = thrownError;
				if(request.status==404){
					error = "La pagina solicitada no ha sido encontrada.";
				}
				error = "["+request.status+"] " + error;
				$(info).html("Error: " + error);
			}
		}
	});
}

//funcion especial para eliminacion de rows en html tables. [Ulises German]
function confirmar(parametro, objSupr, objLoad, fnCallback){
	if(confirm("Desea eliminar este registro?")){
		fnCallback(parametro, objSupr, objLoad);
	}
}

//funcion que simula un confirm en dialog. [Eleazar Castro]
function confirma(msj, titulo, fcallback){  
	var div = $("<div title='"+titulo+"' style='font-size:12px; color: #2e6e9e;'>"+msj+"</div>");
	div.dialog({
		modal: true
		,buttons:{ 
			'Aceptar': function(){
				$(this).dialog('close');
				fcallback();
			},
			'Cancelar': function(){
				$(this).dialog('close');
			}
		}
		,closeOnEscape: true
		,close:function(){
			$(this).dialog('destroy');
			$(this).remove();
		}
	});
}


//funcion para eliminar rows en html tables. [Ulises German]
function delRow(parametro, objSupr, objLoad){
	if(parametro!=""){
		$("#"+objLoad).html('<img src="images/loadinfo_1.gif" width="24px"/>');
		$.ajax({
			type: "GET",
			url: "ajax/saveForms.php?hf_unlink="+parametro,
			async: true,
			success: function (data) {
				var retorno = data.split("|");						
				if(retorno[0]==1){						
					$('#'+objSupr).fadeOut(1000, function (){
						$(this).remove();
						tbZebra("table_result1","DEECF9","FFFFFF");								
						$("#messagefromajax").html(retorno[1]);
						toogleInfo('messagefromajax');
					});
				}
				else{
					$("#messagefromajax").html(retorno[1]);
				}
			}
		});
	}
}

//funcion para guardar formularios segun el argumento Json. [Ulises German]
function saveForm(json_selec){
	if(jWarValidation(json_selec)){			
		return true;
	}			
	return false;
}

//funcion que permite capturar numeros solamente. [Eleazar Castro]
function soloenteros(x){
	$(x).val($(x).val().replace(/[^0-9]/g, ''));
}

//funcion que permite capturar letras solamente. [Eleazar Castro]
function sololetras(x){
	$(x).val($(x).val().replace(/[^a-zA-Z]/g, ''));
}

//funcion que simula un alert en dialog. [Eleazar Castro]
function alerta(msj, titulo){  
	var div = $("<div title='"+titulo+"' style='font-size:12px; color: #2e6e9e;'>"+msj+"</div>");
	div.dialog({
		modal: true
		,buttons:{ 'Aceptar': function(){
			$(this).dialog('close');
			$(this).remove();
			}
		}
		,closeOnEscape: true
		,close:function(){
			$(this).dialog('destroy');
			$(this).remove();
		}
	});
}

//funcion para abrir un div overlay (superposicion) recibe el id del div donde se va a cargar y el texto a mostrar junto con el loading.gif. [Eleazar Castro]
function dialog_overlay_EC(txt){
	var div = $("<div id='overlay_EC' style='font-size:12px; color: #2e6e9e;'><center><img src='images/loading.gif'><br><b>"+txt+"</b></center></div>");
	div.dialog({
		modal: true
		,width: 100
		,height: 100
		,closeOnEscape: false
		,create: function(){
			//$("div.ui-dialog-titlebar").css('display','none');
			$.each($('div.ui-dialog-titlebar'), function(i,v){
				if($(v).parent().html().toString().indexOf('overlay_EC')==-1)
					$(v).css('display','block');
				else
					$(v).css('display','none');
			});
		}
		,close:function(){
			//$("div.ui-dialog-titlebar").css('display','block');
			$(this).dialog('destroy');
			$(this).remove();
		}
	});
}
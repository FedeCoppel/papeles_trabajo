// JavaScript Document
var huellas = 
{
	nb_Funcion_: "",
	nb_funcion_falsa: "",
	nu_Empleado_: "",
	huella: function( nu_Empleado,nb_funcion, funcionFalsa )
	{
		this.nb_Funcion_ = nb_funcion;
		this.nb_funcion_falsa = funcionFalsa;
		this.nu_Empleado_ = nu_Empleado;
		var sNombreObjeto = "_huella";
		var sObjeto = '<span id="' + sNombreObjeto + '"></span>';
		
		$( "#" + sNombreObjeto ).remove();
		
		$( "body" ).after(sObjeto);
		
		$( "#" + sNombreObjeto ).load
		(
			"loadApplet.php?Nip="+ nu_Empleado +"&Path=http://intranet.cln"
		);
		
		return nu_Empleado;
	}
}

function finger_result( result )
{
	
	if (result=="AC")
	{
		setTimeout( huellas.nb_Funcion_, 1000 );
	}
	else if (result=="WA")
	{
		setTimeout( huellas.nb_funcion_falsa, 1000 );
	}
}
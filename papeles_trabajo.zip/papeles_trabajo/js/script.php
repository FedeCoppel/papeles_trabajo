<?php
session_start();
header("Cache-Control: no-store, no-cache"); 
header("Content-type: text/javascript"); 

if(isset ($_GET['ruta']) && isset($_GET['posicion']) && isset($_GET['titulo']))
{
	if(isset ($_GET['nameApp']))
	{
		$nameApp=$_GET['nameApp'];

		$_SESSION['aplicacion']=$nameApp;
	}
	else
	{
		$nameApp='myApp';
		$_SESSION['aplicacion']='myApp';
	}
    
	echo '
	//var usr=$("#usr").val();
	//var tkn=$("#tkn").val();
	var tkn="'.$_SESSION['G_token'].'";
    var country ="'.$_SESSION['pais'].'";
	
	$.ajax({
		async:true,
		type: "POST",
		url: "./ajax/proc_cfmsessions.cfm",
		data: {			
			tkn:tkn,
            country:country
		},
		success: function(data){			
			//alert(data);
			var arreglo = data.split("|");
			var status = parseInt(arreglo[0]);
			if(status==13){				
				cargaAjax("'.$_GET['ruta'].'","#'.$_GET['posicion'].'",transAccordion);	
				changeSystemTitle("'.$_GET['titulo'].'");//AGREGO RENAN
				//toogleAppMenu(true, true);//AGREGO RENAN	
			}
			else
			{	
				// esto se tiene que habilitar a huevo para que mande a la intranet en caso de fallo del token			
				window.location = "cierrasesion.php"
			}
		},error:function (xhr, ajaxOptions, thrownError){
					alert(xhr.status);
					alert(thrownError);
                    console.log("error");
		}
	});	
	';
}else{
	echo 'window.location = "cierrasesion.php"';
}
?>

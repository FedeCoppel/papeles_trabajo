/*******************************************************************************************************************
****************** Elaborado por: Ernesto Diego Sanchez Tellaeche
*******************************************************************************************************************/

	/*//Bloqueamos la tecla F5
	$(document).keydown
	(
		function(e)
		{
			var iTecla = (e.keyCode ? e.keyCode : e.which);
			if ( iTecla == 116 )
			{
				return false;
				
			}
			
			if(iTecla == 114)
			{
				cargaAjax(com.pathDir() + '/tickets_consultar_busqueda.cfm?tipoGrid=1', '#centro');	
			}
		}
	);*/
	//*********** COM , contiene las direcciones basicas del sitio
	var com =
	{
		pathCom: function()
		{
			return "aps/componentes";
		},
		pathDir: function()
		{
			return "aps/ajax";
		},
		imgDir: function()
		{
			return "aps/images";	
		}
	};
	
	//*********** WIN , contiene funciones para las ventanas
	var win = 
	{
		index: function()
		{
			document.location.href = "index.php";
		},
		controlPanel: function()
		{
			cargaAjax('aps/index.cfm?cargarOpciones=false', '#centro');
		},		
		ctrl: function(key, callback, args)
		{
			$(document).keydown
			(
				function(e)
				{
					var iTecla = (e.keyCode ? e.keyCode : e.which);
					if( !args ) args=[];
					if( iTecla == key.charCodeAt(0) && e.ctrlKey)
					{
						callback.apply(this, args);
						return false;
					}
				}
			);
		},
		load: function()
		{
			this.styles();
			//this.nopaste();
			$(document).bind
			(
				"contextmenu",
				function(e)
				{
					e.preventDefault();
				}
			);
		},
		nopaste: function(e)
		{
			this.ctrl( "v",function (){} );
			this.ctrl( "V",function (){} );
		},
		styles: function()
		{
			//Aplicar Estilos a Cajas de Texto
			$( "[type=text]" ).addClass( "ui-widget-content" );
			
			//Aplicar Estilos a File
			//$( "[type=file]" ).addClass( "ui-widget-content" ).css( {border:"1px solid 002255"} );
			
			//Aplicar Estilos a TextArea
			$( "textarea" ).addClass( "ui-widget-content" );
			
			//Aplicar Estilos a Combos
			$( "select" ).addClass( "ui-widget-content" );
			
			//Aplicar Estilos a Radios
			$( "[type=radio]" ).css( "border-color","#00CC99" );
		},
		getFields: function( contenedor )
		{
			var sCamposRegresar = "";
			
			$( "textarea,input[type=text],input[type=hidden],select","#" + contenedor ).each
			(
				function(i)
				{
					var id_Campo = new String($(this).attr("id"));
					if ( id_Campo !="" && id_Campo.indexOf("gs_") == -1 )
					{
						sCamposRegresar = sCamposRegresar + "&" + $(this).attr("id") + "=" + $( "#" + $(this).attr("id") ).val();
					}
				}
			);
			
			return sCamposRegresar;
		},
		clearFields: function( contenedor )
		{
			$( "textarea,[type=text],input[type=hidden]","#" + contenedor ).each
			(
				function()
				{
					var id_Campo = new String($(this).attr("id"));
					if ( id_Campo !="" && id_Campo.indexOf("gs_") == -1 )
					{
						$( "#" + $(this).attr("id") ).val("");
					}
				}
			);
		},
		validate: function()
		{
			var bRegresa = false;
			var bContinuar = true;
			var sMensaje = "";
			var sCampo = "";
			var oCampo = "";
			
			if ( bContinuar )
			{
				$( ".texto" ).each
				(
					function()
					{
						sCampo = $(this).val();
						oCampo =  $(this).attr( "data-titulo" );
						
						if ( $(this).hasClass("requerido") )
						{
							if ( sCampo.length<1 || sCampo == "" )
							{
								bContinuar = false;
							}
						}
						
						for( var i=0; (i<sCampo.length) && bContinuar; i++ )
						{
							
							var caracter = sCampo.charCodeAt(i);
							if ( !((sCampo.charCodeAt(i)>=32 && sCampo.charCodeAt(i)<=173) && (sCampo.charCodeAt(i)!=39)) )
							{
								if(caracter != 225 && caracter != 233 && caracter != 237 &&caracter != 243 && caracter != 250 && caracter != 232 && caracter != 224 && caracter != 236 && caracter != 241 && caracter != 242 && caracter != 249 && caracter != 39&& caracter != 10)
								{
									bContinuar = false;
									sMensaje = "Tipo de Dato ingresado no valido para " + oCampo;
								}
							}
						}
						
						if ( bContinuar == false && sMensaje=="" )
						{
							sMensaje = $(this).attr( "data-msg" );
						}
						
						return bContinuar;
					}
				);
			}
			
			if ( bContinuar )
			{
				$( ".nombre" ).each
				(
					function()
					{
						sCampo = $(this).val();
						oCampo =  $(this).attr( "data-titulo" );
						
						if ( $(this).hasClass("requerido") )
						{
							if ( sCampo.length<1 || sCampo == "" )
							{
								bContinuar = false;
							}
						}
						
						for( var i=0; (i<sCampo.length) && bContinuar; i++ )
						{
							
							var caracter = sCampo.charCodeAt(i);
							if ( !((sCampo.charCodeAt(i)>=65 && sCampo.charCodeAt(i)<=90) && (sCampo.charCodeAt(i)>=97 && sCampo.charCodeAt(i)<=122) && (sCampo.charCodeAt(i)==32)) )
							{
								if(caracter != 225 && caracter != 233 && caracter != 237 &&caracter != 243 && caracter != 250 && caracter != 232 && caracter != 224 && caracter != 236 && caracter != 241 && caracter != 242 && caracter != 249 && caracter != 39&& caracter != 10)
								{
									bContinuar = false;
									sMensaje = "Tipo de Dato ingresado no valido para " + oCampo;
								}
							}
						}
						
						if ( bContinuar == false && sMensaje=="" )
						{
							sMensaje = $(this).attr( "data-msg" );
						}
						
						return bContinuar;
					}
				);
			}
			
			if ( bContinuar )
			{
				$( ".numerico" ).each
				(
					function()
					{
						sCampo = $(this).val();
						oCampo =  $(this).attr( "data-titulo" );
						
						if ( $(this).hasClass("requerido") )
						{
							if ( sCampo.length<1 || sCampo == "" )
							{
								bContinuar = false;
							}
						}
						
						for( var i=0; (i<sCampo.length) && bContinuar; i++ )
						{
							
							var caracter = sCampo.charCodeAt(i);
							if ( !((sCampo.charCodeAt(i)>=48 && sCampo.charCodeAt(i)<=57)) )
							{
								if(caracter != 225 && caracter != 233 && caracter != 237 &&caracter != 243 && caracter != 250 && caracter != 232 && caracter != 224 && caracter != 236 && caracter != 241 && caracter != 242 && caracter != 249 && caracter != 39&& caracter != 10)
								{
									bContinuar = false;
									sMensaje = "Tipo de Dato ingresado no valido para " + oCampo;
								}
							}
						}
						
						if ( bContinuar == false && sMensaje=="" )
						{
							sMensaje = $(this).attr( "data-msg" );
						}
						
						return bContinuar;
					}
				);
			}
			
			bRegresa = bContinuar;
			
			if ( bContinuar == false )
			{
				dialogo.dialogo( "span_respuesta" );
				dialogo.msg( sMensaje );
			}
			
			
			return bRegresa;
		}
	};
	
	var validates =
	{
		sAttr_TitleField: "validate-titlefield",
		sAttr_MsgField: "validate-msgfield",
		msg_invalid_data: "Tipo de Dato ingresado no valido para ",
		oDlgValidatesForm: "dialogo_validatesform",
		validates: function()
		{
			var args = arguments[0];
			var oObjectValidatesForm = '<span id="dlg_' + this.oDlgValidatesForm + '"></span>';
			
			if ( args )
			{
				if ( args['msg_invalid_data'] )
				{
					this.msg_invalid_data = args['msg_invalid_data'];
				}
			}
			
			$( "#dlg_" + this.oDlgValidatesForm ).remove();
			$( "body" ).after( oObjectValidatesForm );
			
		},
		keys_types: function( keyAscii,type )
		{
			var bRegresa = false;
			
			if ( type == "text" )
			{
				if ( (keyAscii>=32 && keyAscii<=173) || (keyAscii!=39) || ( keyAscii==13 || keyAscii==8 || keyAscii==9 || keyAscii==37 || keyAscii==38 ) )
				{
					bRegresa = true;
				}
			}
			
			if ( type == "numeric" )
			{
				if ( (keyAscii>=48 && keyAscii<=57) || ( keyAscii==13 || keyAscii==8 || keyAscii==9 || keyAscii==37 || keyAscii==38 ) )
				{
					bRegresa = true;
				}
			}
			
			return bRegresa;
		},
		keyspress: function( name_field, type )
		{
			$( name_field ).keydown
			(
				function(e)
				{
					var iTecla = (e.keyCode ? e.keyCode : e.which);
					var bRegresa = validates.keys_types(iTecla, type);

					return bRegresa;
				}
			);
		},
		add: function()
		{
			var args = arguments[0];
			var name_field = args['name_field'];
			var type = args['type'] ? args['type']: "text";
			var required = args['required'] ? args['required']: false;
			var title_field = args['title_field'] ? args['title_field']: name_field;
			var msg_field = args['msg_field'] ? args['msg_field']: "Favor de Ingresar la informaci&oacute;n";
			var keypress = args['keypress'] ? args['keypress']: false;
			
			$( name_field ).attr( validates.sAttr_MsgField,msg_field );
			$( name_field ).attr( validates.sAttr_TitleField,title_field );

			$( name_field ).addClass( type );
			if ( required == true )
			{
				$( name_field ).addClass( "required" );
			}
			
			//Validas teclas presionadas de acuerdo al tipo de dato
			if ( keypress == true )
			{
				this.keyspress( name_field,type );
			}

		},
		fields: function()
		{
			var bRegresa = false;
			var bContinuar = true;
			var args = arguments[0];
			var show_msg = true;
			
			if ( args )
			{
				show_msg = args['show_msg'] ? args['show_msg']: false;
			}
			
			$( "textarea,input,select" ) .each
			(
			 	function()
				{
					if ( bContinuar )
					{
						bContinuar = validates.field( {name_field: this, show_msg: show_msg} );
					}
					
					return bContinuar;
				}
			);

			return bRegresa;
		},
		field: function()
		{
			var args = arguments[0];
			var name_field = args['name_field'];
			var show_msg = args['show_msg'] ? args['show_msg']: false;
			var bRegresa = false;
			var bContinuar = true;
			var sMensaje = "";
			var sCampo = "";
			var oCampo = "";
			var sMsgInvalidData = this.msg_invalid_data;
			
			sCampo = $(name_field).val();
			oCampo =  $(name_field).attr( validates.sAttr_TitleField );
			
			if ( $(name_field).hasClass("required") )
			{
				if ( sCampo.length<1 || sCampo == "" )
				{
					bContinuar = false;
				}
			}
			
			//Validamos los tipos texto
			if ( bContinuar )
			{
				if ( $(name_field).hasClass("text") )
				{	
					for( var i=0; (i<sCampo.length) && bContinuar; i++ )
					{
						if ( !((sCampo.charCodeAt(i)>=32 && sCampo.charCodeAt(i)<=173) && (sCampo.charCodeAt(i)!=39)) )
						{
							bContinuar = false;
							sMensaje = sMsgInvalidData + oCampo;
						}
					}
				}
			}
			
			//Validamos los tipos numericos
			if ( bContinuar )
			{
				if ( $(name_field).hasClass("numeric") )
				{
					
					for( var i=0; (i<sCampo.length) && bContinuar; i++ )
					{
						if ( !((sCampo.charCodeAt(i)>=48 && sCampo.charCodeAt(i)<=57)) )
						{
							bContinuar = false;
							sMensaje = sMsgInvalidData + oCampo;
						}
					}
				}
			}
			
			if ( bContinuar == false && sMensaje=="" )
			{
				sMensaje = $(name_field).attr( validates.sAttr_MsgField );
			}
			
			bRegresa = bContinuar;
			
			if ( show_msg == true )
			{
				if ( bContinuar == false )
				{
					dialogo.dialogo( this.oDlgValidatesForm );
					dialogo.msg( sMensaje );
				}
			}

			return bRegresa;
		}
	};
	
	var huellas = 
	{
		nb_Funcion_: "",
		nb_funcion_falsa: "",
		nu_Empleado_: "",
		huella: function( nu_Empleado,nb_funcion, funcionFalsa )
		{
			this.nb_Funcion_ = nb_funcion;
			this.nb_funcion_falsa = funcionFalsa;
			this.nu_Empleado_ = nu_Empleado;
			var sNombreObjeto = "_huella";
			var sObjeto = '<span id="' + sNombreObjeto + '"></span>';
			
			$( "#" + sNombreObjeto ).remove();
			
			$( "body" ).after(sObjeto);
			
			$( "#" + sNombreObjeto ).load
			(
				"loadApplet.php?Nip="+ nu_Empleado +"&Path=http://10.44.1.81"
			);
			
			return nu_Empleado;
		}
	}
	
	function finger_result( result )
	{
		
		if (result=="AC")
		{
			setTimeout( huellas.nb_Funcion_, 1000 );
		}
		else if (result=="WA")
		{
			setTimeout( huellas.nb_funcion_falsa, 1000 );						
		}
	}
	
	//*********** CHECKBOX , contiene funciones para los checks
	var checkbox =
	{
		checkall: function( idCheck,bCheck )
		{
			$( idCheck ).each
			(
			 	function ()
				{
					$( this ).attr( 'checked', bCheck );
				}
			 );
		},
		uncheck: function( idCheck )
		{
			$( idCheck ).attr( 'checked', false );
		},
		check: function( idCheck )
		{
			$( idCheck ).attr( 'checked', true );
		},
		yesno: function ( idCheck, bCheck )
		{
			this.uncheck( idCheck );
			$( idCheck ).each
			(
			 	function ()
				{
					var sCheck = new String( bCheck );

					if ( $(this).val() == sCheck )
					{
						$( this ).attr( 'checked', true );
					}
				}
			 );
		}
	};
	
	//*********** DIR , contiene funciones para la gesti�n de archivos
	var dir = 
	{
		div_listado_files: "",
		ruta_listado_files: "",
		dir_listado_files: "",
		ruta_modulo		: "",
		dir: function( div_contenedor,ruta_listado,dir_listado,ruta )
		{
			this.div_listado_files  = div_contenedor;
			this.ruta_listado_files = ruta_listado;
			this.dir_listado_files  = dir_listado;
			this.ruta_modulo = ruta;
		},
		listFiles: function()
		{
			cargaAjax
			(
				this.ruta_modulo + "/directorios_listar.cfm?sRuta=" + this.ruta_listado_files + "&sDirectorio=" + this.dir_listado_files,
				this.div_listado_files
			);
		},
		uploadFiles: function( sDirectorio, sSubDirectorio, contenedor)
		{
			var sUrl = this.ruta_modulo + "/subir_archivos.cfm?sDirectorio=" + sDirectorio + "&sSubDirectorio=" + sSubDirectorio;
			
			cargaAjax
			(
				sUrl,
				contenedor
			);
		}
	};
	
	//*********** jJSON , contiene funciones para el control de JSON
	var jJSON =
	{
		get: function( objJSON )
		{
			var aRespuesta = new Array();
			var jsonRespuesta = jQuery.parseJSON( objJSON );

			if ( jsonRespuesta['DATA'] )
			{
				aRespuesta = jsonRespuesta['DATA'];
				aRespuesta["ROWCOUNT"] = jsonRespuesta['ROWCOUNT'];
				aRespuesta["COLUMNS"] = jsonRespuesta['COLUMNS'];
				aRespuesta["ERROR"] = null;
				
			}
			else
			{
				aRespuesta["ERROR"] = jsonRespuesta['ERROR'];
			}

			if ( aRespuesta["ROWCOUNT"] == 1 )
			{
				for( llave in aRespuesta )
				{
					if ( aRespuesta[llave] )
					{
						aRespuesta[llave] =  aRespuesta[llave].toString();
					}
				}
			}
			
			return aRespuesta;
		}
	};

	function fun_CrearObjetoMaximoCaracteres( idCampoOrigen,numMaxCaracteres )
	{
		var sObjeto = '<div style="text-align:right; padding-right: 8px;">'
					+ '   <span id="' + idCampoOrigen +'_caracteres">' + numMaxCaracteres + ' Caracteres</span>'
					+ '</div>';
		$( "#" + idCampoOrigen + "_caracteres" ).remove();
		$( "#"+ idCampoOrigen ).after(sObjeto);
		
		setInterval
		(
		 	function()
			{
				fun_MaximoCaracteres("#"+ idCampoOrigen,numMaxCaracteres);
			},
			100
		 );
					
		/*$( "#"+ idCampoOrigen ).keypress
		(
			function(e)
			{
				var iTecla = (e.keyCode ? e.keyCode : e.which);

				//alert( "valor de la tecla:" + iTecla );
				if ( !(iTecla >= 35 && iTecla <= 40) )
				{
					if ( !fun_MaximoCaracteres("#"+ idCampoOrigen,numMaxCaracteres) && iTecla!= 8 )
					{
						return false;
					}
				}
			}
		);*/
	}
	
	function fun_MaximoCaracteres( idCampoOrigen,numMaxCaracteres )
	{
		var bRegresa = false;
		var iLenTexto = 0;
		var sTexto = new String( $( idCampoOrigen ).val() );
		iLenTexto = sTexto.length;
		
		if ( iLenTexto == 0 || iLenTexto == 1 ) iLenTexto++;
		if ( iLenTexto<=numMaxCaracteres )
		{
			$( idCampoOrigen + "_caracteres" ).text( (numMaxCaracteres - iLenTexto) + " Caracteres" );
			bRegresa = true;
		}
		else
		{
			sTexto = sTexto.substring( 0,numMaxCaracteres );
			$( idCampoOrigen ).val( sTexto );
		}
		
		return bRegresa;
	}

	//*********** GRID , contiene funciones para el manejo de los grids
	var grid = 
	{
		refresh: function( idGrid )
		{
			$( "#grid_"+idGrid ).trigger('reloadGrid');
		},
		gotoLastPage: function( idGrid )
		{
			this.gotoPage( idGrid, this.getPages(idGrid) );
		},
		gotoPage: function( idGrid, nu_pagina )
		{
			$( "#grid_"+idGrid ).jqGrid( 'setGridParam',{page:nu_pagina} );
			this.refresh( idGrid );
		},
		getRows: function( idGrid )
		{
			return $( "#grid_"+idGrid ).jqGrid('getGridParam','records');
		},
		getPages: function( idGrid )
		{
			return $( "#grid_"+idGrid ).jqGrid( 'getGridParam','lastpage' );
		},
		getRowData: function( idGrid,idRenglon )
		{
			return $( "#grid_" + idGrid ).jqGrid( 'getRowData',idRenglon );
		},
		getSelRow: function( idGrid )
		{
			return $( "#grid_" + idGrid ).jqGrid( 'getGridParam','selrow' );
		},
		getSelRowData: function( idGrid )
		{
			var iRenglon = this.getSelRow(idGrid);
			
			if ( iRenglon )
			{
				return this.getRowData( idGrid,iRenglon );
			}
			else
			{
				return false;
			}
		},
		cellColor : function()
		{
			var bRegresa = true;
			var args = arguments[0];
			var idGrid = args['grid'];
			var idRenglon = args['row'];
			var textColumna = new String(args['textFind']).toLowerCase();
			var idColumna = args['colname'];
			
			if ( !args['textFind'] )
			{
				if ( args['color'] )
				{
					$( "#grid_" + idGrid ).setCell( idRenglon,idColumna,'',{color: args['color']} );
				}
				if ( args['background'] )
				{
					$( "#grid_" + idGrid ).setCell( idRenglon,idColumna,'',{background: args['background']} );
				}
			}
			else if ( args['textFind'] )
			{
				bRegresa = false;
				for ( var i=1; i<=this.getRows(idGrid); i++ )
				{
					var Rs = this.getRowData(idGrid,i);
					if ( new String(Rs[idColumna]).toLowerCase() == textColumna )
					{
						bRegresa = true;
						if ( args['color'] )
						{
							$( "#grid_" + idGrid ).setCell( i,idColumna,'',{color: args['color']} );
						}
						if ( args['background'] )
						{
							$( "#grid_" + idGrid ).setCell( i,idColumna,'',{background: args['background']} );
						}
					}
				}
			}
			
			return bRegresa;
		},
		rowColor : function()
		{
			var bRegresa = true;
			var args = arguments[0];
			var idGrid = args['grid'];
			var idRenglon = args['row'];
			var textColumna = new String(args['textFind']).toLowerCase();
			var idColumna = args['colname'];
			
			if ( !args['textFind'] )
			{
				if ( args['color'] )
				{
					$( "#" + idRenglon, "#grid_" + idGrid).css({color: args['color']});
				}
				if ( args['background'] )
				{
					$( "#" + idRenglon, "#grid_" + idGrid).css({background: args['background']});
				}
			}
			else if ( args['textFind'] )
			{
				bRegresa = false;
				for ( var i=1; i<=this.getRows(idGrid); i++ )
				{
					var Rs = this.getRowData(idGrid,i);
					
					if ( new String(Rs[idColumna]).toLowerCase() ==  textColumna )
					{
						bRegresa = true;
						if ( args['color'] )
						{
							$( "#" + i, "#grid_" + idGrid).css({color: args['color']});
						}
						if ( args['background'] )
						{
							$( "#" + i, "#grid_" + idGrid).css({background: args['background']});
						}
					}
				}
			}
			
			return bRegresa;
		},
		replaceText: function()
		{
			var args = arguments[0];
			var idGrid = args['grid'];
			var textColumna = new String(args['textFind']).toLowerCase();
			var textReemplazar = args['textReplace']
			var idColumna = args['colname'];
			
			if ( args['textFind'] )
			{
				bRegresa = false;
				for ( var i=1; i<=this.getRows(idGrid); i++ )
				{
					var Rs = this.getRowData(idGrid,i);
					if ( new String(Rs[idColumna]).toLowerCase() == textColumna )
					{
						bRegresa = true;
						$( "#grid_" + idGrid ).setCell( i,idColumna,textReemplazar,'' );
					}
				}
			}
			
		},
		buttonText: function( textoAnterior, textoNuevo )
		{
			$( ".ui-icon" ).next("span:contains('" + textoAnterior + "')" ).text( textoNuevo );
		},
		hideCol: function( idGrid )
		{
			for( var i=1; i<arguments.length; i++ )
			{
				sCampo = arguments[i];
				$( "#grid_"+idGrid ).jqGrid( 'hideCol',sCampo );
			}
		}
	};
	
	//*********** COMBO , contiene funciones para los combos
	var combo =
	{
		convertToRadio : function( idCombo,idRadio,funcion )
		{
			
			$( "#" + idCombo + " option" ).each
			(
				function(i, e)
				{
					var sEtiqueta = "<label for='"+ idRadio +  "_" + i + "'>"
					var sObjeto = sEtiqueta + "<input type='radio' "
					                        + "class='" + idRadio + "' "
					                        + "name='" + idRadio + "' "
											+ "id='" + idRadio + "_" + i + "' "
											+ "value='" + $(this).val() + "' /> " 
											+ $(this).text() + "<br>"
								            + "</label>";
					$( "#" + idCombo ).before( sObjeto );
					$( "." + idRadio + ":first" ).attr( "checked", true );
				}
			);
			$( "#"+ idCombo ).remove();
			
			if(typeof funcion == 'function')
			{
				funcion.call(this);
			}
		},
		convertToCheckbox : function( idCombo,idCheckBox )
		{
			$( "#" + idCombo + " option" ).each
			(
				function(i, e)
				{
					var sEtiqueta = "<label for='"+ idCheckBox +  "_" + i + "'>"
					var sObjeto = sEtiqueta + "<input type='checkbox' "
					                        + "class='" + idCheckBox + "' "
					                        + "name='" + idCheckBox + "' "
											+ "id='" + idCheckBox + "_" + i + "' "
											+ "value='" + $(this).val() + "' /> " 
											+ $(this).text() + "<br>"
								            + "</label>";
					$( "#" + idCombo ).before( sObjeto );
				}
			);
			$( "#"+ idCombo ).remove();
		},
		getValue : function( objCombo )
		{
			return $("#"+objCombo).val();
		}
	};
	
	//*********** DIALOGO , contiene funciones para el control de dialogos
	var dialogo = 
	{
		nombreDialogo : "",
		dialogo : function( sNombre )
		{
			this.nombreDialogo = sNombre
		},
		open : function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}

			this.clearFields(nomDialogo);
			$( "#dlg_" + nomDialogo ).dialog( "open" );
		},
		close : function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			$( "#dlg_" + nomDialogo ).dialog( "close" );
			this.clearFields(nomDialogo);
		},
		destroy : function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			$( "#dlg_" + nomDialogo ).dialog( "destroy" );
		},
		isOpen : function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			return $( "#dlg_" + nomDialogo ).dialog( "isOpen" );
		},
		msg: function(sMensaje)
		{
			var nomDialogo = this.nombreDialogo;
			
			this.destroy( "dialogo_mensajes" );
			$( "#dlg_" + nomDialogo ).after('<div id="dlg_dialogo_mensajes"></div>');
			
			$( "#dlg_dialogo_mensajes" )
			.html( sMensaje )
			.dialog
			({
				 modal:			true
				,autoOpen:		true
				,resizable:		false
				,draggable:		true
				,closeText:		'Cerrar'
				,closeOnEscape:	false
				,show: 			'scale'
				,hide: 			'scale'
				,buttons:
				{
					"Cerrar":    function() { $(this).dialog( "destroy" ); },
				}
			});
		},
		error: function(sMensaje)
		{
			var nomDialogo = this.nombreDialogo;
			
			this.destroy( "dialogo_mensajes_error" );
			$( "#dlg_" + nomDialogo ).after('<div id="dialogo_mensajes_error"></div>');
			
			$( "#dialogo_mensajes_error" )
			.html( sMensaje )
			.dialog
			({
				 modal:			true
				,autoOpen:		true
				,resizable:		false
				,draggable:		true
				,closeText:		'Cerrar'
				,closeOnEscape:	false
				,show: 			'scale'
				,hide: 			'scale'
				,buttons:
				{
					"Cerrar":    function() { $(this).dialog( "destroy" ); },
				}
			});
			
			this.msg
			(
			 	mensajes.mostrar(2,'',sMensaje, '')
			);			
		},
		clearFields: function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			$( "textarea,[type=text]","#dlg_" + nomDialogo ).each
			(
				function()
				{
					if ( $(this).attr("id") !="" )
					{
						$( "#" + $(this).attr("id") ).val("");
					}
				}
			);
		},
		getFields: function()
		{
			var nomDialogo = this.nombreDialogo;
			var sCamposRegresar = "";
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			
			$( "textarea,input,select","#dlg_" + nomDialogo ).each
			(
				function(i)
				{
					var id_Campo = new String($(this).attr("id"));
					if ( id_Campo !="" && id_Campo.indexOf("gs_") == -1 )
					{
						sCamposRegresar = sCamposRegresar + "&" + $(this).attr("id") + "=" + $( "#" + $(this).attr("id") ).val();
					}
				}
			);
			
			return sCamposRegresar;
		},
		focusFirst: function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			
			$( "textarea,input,select","#dlg_" + nomDialogo ).eq(0).focus();
		},
		hideButtonClose: function()
		{
			var nomDialogo = this.nombreDialogo;
			if ( (arguments.length)==1 )
			{
				nomDialogo = arguments[0];
			}
			$( "#dlg_" + nomDialogo ).parent().children().children(".ui-dialog-titlebar-close").hide();
		}		
	};
	
	var mensajes = 
	{
		mostrar : function (tipo,operacion,personalizado,cfcatch)	
				{
					var cadenaModal='';
		
					cadenaModal += '<table><tr><td><img src="'; 
					
					//concatenando la imagen que se desplegar� en el modal
					
					if(tipo == 1) //operacion exitosa
					{
						cadenaModal += 'aps/images/check.png';
					}
					else if(tipo == 2) //error
					{
						cadenaModal += 'aps/images/delete.png';
					}
					else if(tipo == 3) //advertencia
					{ 
						cadenaModal +=  '';
					}
					else if(tipo == 4) //Pregunta
					{
						cadenaModal +=  'aps/images/question.png';
					}
					
					//concatenando el resto de la sentencia de imagen y de la celda que contendr� la misma
					cadenaModal += '" height="35" width="35"></td><td><p style="color:';
					
					//determinando el color del mensaje dependiendo si es mensaje de confirmaci�n o de error
					
					if(tipo == 1)
					{
						cadenaModal += new String('green');
					}
					else if(tipo == 2)
					{
						cadenaModal += new String('red');
					}
					else if(tipo == 3)
					{
						cadenaModal += new String('orange');
					}
					else if(tipo == 4)
					{
						cadenaModal += new String('navy');
					}
					
					//Termando la etiqueta incial de la celda donde se desplegar� el mensaje	
					cadenaModal += '; font-weight:bolder;">';
					
					//concatenando el mensaje personalizado del usuario (Si se provee), en caso contrario evaluar el tipo del mensaje
					//y concatenar mensaje por default
					
					if(personalizado == '')
					{
						if(tipo == 1)
						{
							if(operacion == 'guardar')
							{
								cadenaModal += 'Se guard&oacute; el registro correctamente.';
							}
							else if(operacion == 'actualizar')
							{
								cadenaModal += 'Se actualiz&oacute; el registro correctamente.';
							}
							else if(operacion == 'eliminar')
							{
								cadenaModal += 'Se elimin&oacute; el registro correctamente.';
							}
							else if (operacion == 'datos')
							{
								cadenaModal += 'Se realiz&oacute; la operaci&oacute;n correctamente.';
							}
						}
						else if(tipo == 2)
						{
							if(operacion == 'guardar')
							{
								cadenaModal += 'Error al guardar!!! [' + cfcatch + '].';
							}
							else if(operacion == 'actualizar')
							{
								cadenaModal += 'Error al actualizar!!! [' + cfcatch + '].';
							}
							else if(operacion == 'eliminar')
							{
								cadenaModal += 'Error al eliminar!!! [' + cfcatch + '].';
							}
							else if (operacion == 'datos')
							{
								cadenaModal += 'Error en acceso a datos!!! [' + cfcatch + '].';
							}
						}						
						
					}
					else
					{
						cadenaModal += personalizado;
					}					
					//completando la setencia de la celda del mensaje del modal
					
					cadenaModal+= '</p></td></tr></table>';
										
					return cadenaModal;	
					
				},
		//Muestra un cuadro de dialogo con un �cono de LOADING, seguido de un mensaje personalizado				
		mostrarDialogoEspera : function(mensajeEspera)
		{
			$("#mensajeEspera").html(mensajeEspera);
			dialogo.open("modalEsperaSistema");	
		},
		
		//Cierra el dialogo de espera
		cerrarDialogoEspera: function()
		{
			dialogo.close("modalEsperaSistema");	
		},
		
		//Muestra un �cono de carga, seguido de un mensaje personalizado, a lado del elemento proporcionado como selector
		mostrarCargando: function(selectorElemento, textoMensaje, funcionCallBack)
		{
			$(selectorElemento).attr("disabled", "disabled");
			var cadenaContenido = '<div style="display:none;" class="mensajeAdjunto"><img src="' + com.imgDir() + '/cargando.gif" height="25" width="25">';
			if(textoMensaje)
			{
				cadenaContenido+= '<span><strong>' + textoMensaje + '</strong></span>';					
			}
			
			//cierre del div que contendr� el �cono y el mensaje de espera
			cadenaContenido+= '</div>';
			
			//agregando al DOM el div con el mensaje, hasta este momento, invisible
			$(selectorElemento).after(cadenaContenido);
			
			//$(selectorElemento).after('<div style="display:none;"><img src="' + com.imgDir() + '/cargando.gif" height="25" width="25"></div>');
			//animando el mensaje para que aparezca con fadeIn
			$(selectorElemento).next().fadeIn("500", function(){if(funcionCallBack){funcionCallBack();}});
		},
		
		//oculta con animaci�n el mensaje de carga mostrado...
		ocultarCargando: function(selectorElemento, funcionCallBack)
		{
			//$(selectorElemento).next().slideUp("slow", function(){$(selectorElemento).next().remove();if(funcionCallBack){funcionCallBack();}; });
			$(selectorElemento).removeAttr("disabled");
			var divMensaje = $(selectorElemento).next();
			if( divMensaje.attr('class') == 'mensajeAdjunto' )
			{
				divMensaje.slideUp
							(
							 	"slow",
								function ()
								{
									divMensaje.remove();
									if(funcionCallBack)
									{
										funcionCallBack();
									}
								}
							);	
			}
				
		},
		mostrarMensajeIcono: function(opcion,selectorElemento, textoMensaje, funcionCallBack)
		{
			var cadenaContenido= '<div style="display:none;" class="mensajeAdjunto"><img src="' + com.imgDir() + '/';
			//adjuntando palomita si es mensaje de confirmaci�n
			if(opcion==1)
			{
				cadenaContenido += 'check.png';
			}
			//ajuntando tachita si es mensaje de error
			else if(opcion == 2)
			{
				cadenaContenido += 'delete.png';
			}
			
			//completando la sentencia de imagen
			cadenaContenido+= '" height="25" width="25">';
			
			//concatenando el mensaje
			if(textoMensaje)
			{
				cadenaContenido+= '<span><strong>' + textoMensaje + '</strong></span>';					
			}
			
			//cerrando el div que contendr� e, mensaje
			cadenaContenido+= '</div>';
			
			//adjuntando el contenido al lado del elemento seleccionado, primero de forma invisible
			$(selectorElemento).after(cadenaContenido);
			//mostrando con efecto fade el elemento del mensaje oculto
			$(selectorElemento).next().fadeIn("500", function(){if(funcionCallBack){funcionCallBack();}});
		},
		
		//ocultar el mensaje mostrado al lado del elemento seleccionado
		ocultarMensajeIcono: function(selectorElemento, funcionCallBack)
		{
			mensajes.ocultarCargando(selectorElemento,funcionCallBack);			
		}		
		
	};
	
	
	function loadPageAjax()
	{
		//Creado por Ernesto Diego Sanchez Tellaeche
		var args = arguments[0];
		var sUrlAjax = args['webpage'];
		var sDivAjax = args['content'];
		var sFunAjax = args['webfunction'];
		var sParamsX = args['parameters'];

		$( sDivAjax ).html('<div class="loading" style="margin:3px !important;"><img align="absmiddle" src="images/loader_webpages.gif" border="0" width="18px"/>&nbsp;cargando...&nbsp;</div>');
		
		$.ajax
		(
			{
				type: "POST",
				url: sUrlAjax,
				data: sParamsX,
				async:true,
				timeout: 180000,
				success: function( postData )
				{
					$( sDivAjax ).html( postData );

					var height_calc = ($('#body-main').height() - $('#centro').height()) - 55;
					var new_height = $('#centro').height() + height_calc;
					$('#centro').css('height', new_height+"px");
			
					if( sFunAjax ){ sFunAjax(); }
				},
				error: function(request, error, thrownError)
				{
					if (error == "timeout")
					{
						$( sDivAjax ).html( "Se ha excedido el tiempo, intente de nuevo." );
					}
					else
					{
						error = thrownError;
						if(request.status==404)
						{
							error = "La pagina solicitada no ha sido encontrada.";
						}
						error = "["+request.status+"] " + error;
						$( sDivAjax ).html( "Error: " + error );
					}
				}
			}
		);
	}
//Función para hacer peticiones por Ajax.
//Elaborado por: Gil Verduzco.
function fnc_peticionAjax(p_url, p_parametros, p_get_post, p_div_success, p_div_error, p_fCallback)
{
	$.ajax({
		url: p_url,
		async: false,
		type: p_get_post,
		data: p_parametros,
		cache: false,
		success: function(data){
			$("#" + p_div_success).html( data );
			
			if( p_fCallback )
				p_fCallback();
		},
		error: function(){
			fnc_ocultar_espera();
			fnc_mostrar_aviso( p_div_error, "Error al interactuar con el servidor.", 4 );
			
		}
	});
}

//Función para hacer peticiones por Ajax.
//Elaborado por: Gil Verduzco.
function fnc_peticionAjax2( p_obj_opciones )
{		
	//Validar si tenemos que mostramos la espera.
	if( !( p_obj_opciones.mostrar_espera == false ) )
	{	
		//Validamos si debemos bloquear la pantalla.
		var bloquear_pantalla = false;
		
		var array_url = p_obj_opciones.url.split("guardar");
		if( array_url.length > 1 )
			bloquear_pantalla = true;
		
		array_url = p_obj_opciones.url.split("insertar");
		if( array_url.length > 1 )
			bloquear_pantalla = true;
		
		array_url = p_obj_opciones.url.split("editar");
		if( array_url.length > 1 )
			bloquear_pantalla = true;
		
		array_url = p_obj_opciones.url.split("actualizar");
		if( array_url.length > 1 )
			bloquear_pantalla = true;
		
		array_url = p_obj_opciones.url.split("eliminar");
		if( array_url.length > 1 )
			bloquear_pantalla = true;
		
		array_url = p_obj_opciones.url.split("borrar");
		if( array_url.length > 1 )
			bloquear_pantalla = true;
			
		//Mostramos la espera.
		fnc_mostrar_espera( bloquear_pantalla );
	}
	
	$.ajax({
		url: p_obj_opciones.url,
		async: p_obj_opciones.async,
		type: ( ( p_obj_opciones.get_post ) ? p_obj_opciones.get_post.toUpperCase() : "GET" ),
		data: ( ( p_obj_opciones.parametros ) ? p_obj_opciones.parametros : "" ),
		cache: p_obj_opciones.cache,
		success: function(data){
			//Ocultamos la espera.
			fnc_ocultar_espera();
			
			$("#" + p_obj_opciones.div_success).html( data );
			
			if( p_obj_opciones.f_callback )
				p_obj_opciones.f_callback();
		},
		error: function(){
			fnc_ocultar_espera();
			fnc_mostrar_aviso( p_obj_opciones.div_error, "Error al interactuar con el servidor.", 4 );
		}
	});
}


//Función para mostrar avisos al usuario.
//Elaborado por: Gil Verduzco.
function fnc_mostrar_aviso(p_nombre_dialogo, p_mensaje, p_tipo_mensaje)
{
	//Tipos de mensajes
	/*
		Tipo 1: Informativo.
		Tipo 2: Confirmación.
		Tipo 3: Éxito.
		Tipo 4: Error.
		Tipo 5: Adverntencia
	*/
	
	var nombre_imagen = "";
	switch( p_tipo_mensaje )
	{
		case 1: nombre_imagen = "informativo.png";
				break;
		case 2: nombre_imagen = "confirmacion.png";
				break;
		case 3: nombre_imagen = "exito.png";
				break;
		case 4: nombre_imagen = "error.png";
				break;
		case 5: nombre_imagen = "advertencia.png";
				break;
		default: break;
	}
	
	var estructura_mensaje = '<table style="width: 100%;">' +
							  	'<tr>' +
									'<td>' +
										'<img src="images/' + nombre_imagen + '" width="60" height="60" />' +
									'</td>' +
									'<td>' +
										'<span style="font-size: 12px;">' + p_mensaje + '</span>' + 
									'</td>'
								'</tr>' +
						     '</table>';
	fnc_setMessage(p_nombre_dialogo, estructura_mensaje);
	fnc_openDialog(p_nombre_dialogo);
}

//Función para bloquear la pantalla.
//Elaborado por: Gil Verduzco.
function fnc_mostrar_espera(p_bloquear_pantalla)
{		
	if( p_bloquear_pantalla )
		$("<div>").attr("class", "blocker").appendTo("body");
		
	$("<div>").attr("class", "espera")
		.html( '<div class="ui-state-highlight border" style="padding: 3px;">' +
					'<table>' +
						'<tr>' +
							'<td>' +
								'<img src="./images/cargando_1.gif" width="20" height="20" />' +
							'</td>' +
							'<td>' +
								'<span>&nbsp;Espere, por favor...</span>' +
							'</td>' +
						'</tr>' +
					'</table>' +
        	   '</div>' 
			 ).appendTo("body");
}

//Función para desbloquear la pantalla.
//Elaborado por: Gil Verduzco.
function fnc_ocultar_espera()
{
	$(".blocker").remove();
	$(".espera").remove();
}

//Función para mostrar notificaciones.
//Elaborado por: Gil Verduzco.
function fnc_mostrar_notificacion(p_mensaje, p_color_mensaje, p_tipo_mensaje)
{
	//Tipos de mensajes
	/*
		Tipo 1: Informativo.
		Tipo 2: Confirmación.
		Tipo 3: Éxito.
		Tipo 4: Error.
		Tipo 5: Adverntencia.
	*/
	
	var nombre_imagen = "";
	switch( p_tipo_mensaje )
	{
		case 1: nombre_imagen = "informativo.png";
				break;
		case 2: nombre_imagen = "confirmacion.png";
				break;
		case 3: nombre_imagen = "exito.png";
				break;
		case 4: nombre_imagen = "error.png";
				break;
		case 5: nombre_imagen = "advertencia.png";
				break;
		default: break;
	}
	
	$(".notificacion").remove();
	
	var estructura_mensaje = '<table style="width: 100%;">' +
								 '<tr>' +
									 '<td>' +
										 '<img src="./aps/images/adm_proy_imagenes/' + nombre_imagen + '" width="60" height="60" />' +
									 '</td>' +
									 '<td>' +
										 '<span style="font-weight: bold; color: ' + p_color_mensaje + '">' + p_mensaje + '</span>' + 
									 '</td>'
								 '</tr>' +
							 '</table>';
	
	$("<div>").attr("class", "ui-state-highlight notificacion")
		.html( '<div>' +
					'<span style="float: right; cursor: pointer;" class="ui-icon ui-icon-circle-close" title="Cerrar"' +
						'onClick="' + "$('.notificacion').remove();" + '">' +
					'</span>' +
				'</div>' +
				'<div>' + estructura_mensaje + '</div>'
			  ).appendTo("body");
	
	var notificacion = $(".notificacion");
	
 	notificacion.fadeIn(100).animate({width: 300}, 500).find("img").delay(500).fadeOut(300).fadeIn(300);
	
	if( p_tipo_mensaje != 4 )
	{	
		notificacion.delay(2000);
		notificacion.animate({height: 4}, 500).animate({width: 0}, 500).hide(function(){ $(".notificacion").remove() });
	}
}

//Función para acompletar con ceros a la izquierda.
//Elaborado por: Gil Verduzco.
function fnc_poner_ceros_izq( p_numero, p_cantidad_digitos )
{
	if( !isNaN( p_numero * 1 ) )
	{
		var numero = p_numero.toString();
		while( numero.length < p_cantidad_digitos )
		{
			numero = "0" + numero;
		}
	}
	else
		return null;
	
	return numero;
}

//Función para crear la agenda.
//Elaborado por: Gil Verduzco.
function fnc_crear_agenda( p_div_agenda, p_year_actual, p_month_actual, p_date_actual, p_idu_empleado, p_disableResizing )
{
	$("#" + p_div_agenda).fullCalendar({
		header:              { left: "title", center: "today", right: "month, agendaWeek, agendaDay, prev, next" }
		,theme:               true
		,firstDay:            1
		,isRTL:               false
		,weekends:            true
		,weekMode:            "fixed"
		,displayweeksnum:	  true
		,height:              "90%"
		,contentHeight:       "400"
		,aspectRatio:         "1.35"
		,defaultView:         "month"
		,allDaySlot:          true
		,allDayText:          "Todo el d&iacute;a"
		,axisFormat:          "h(:mm)tt"
		,slotMinutes:         "60"
		,defaultEventMinutes: "120"
		,firstHour:           "7"
		,minTime:             "7"
		,maxTime:             "22"
		,timeFormat:          "H:mm{ - H:mm}"
		,columnFormat:        { month: "ddd", week: "ddd M/d", day: "dddd M/d" }
		,titleFormat:         { month: "MMMM yyyy", week: "MMM d[ yyyy]", day: "dddd, MMM d, yyyy" }
		,buttonText:          {
				today:    "D&iacute;a de hoy"
				,month:    "Mes"
				,week:     "Semana"
				,day:      "D&iacute;a"
		  }
		,monthNames:          ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']
		,monthNamesShort:     ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic']
		,dayNames:            ['Domingo', 'Lunes', 'Martes', 'Mi&eacute;rcoles', 'Jueves', 'Viernes', 'S&aacute;bado']
		,dayNamesShort:       ['Dom', 'Lun', 'Mar', 'Mie', 'Jue', 'Vie', 'Sab']
		,selectable:          false
		,selectHelper:        true
		,unselectAuto:        true
		,unselectCancel:      ""
		,events:              "./aps/ajax/proc/proc_adm_proy_mis_actividades_listar.cfm?idu_empleado_asignado=" + p_idu_empleado
		,eventSources:        ""
		,allDayDefault:       true
		,ignoreTimezone:      true
		,startParam:          "start"
		,endParam:            "end"
		,lazyFetching:        true
		,editable:            true
		,disableDragging:     false
		,disableResizing:     p_disableResizing
		,dragRevertDuration:  "500"
		,dragOpacity:         { agenda: ".5", "": "1.0" }
		,year:                p_year_actual
		,month:               p_month_actual
		,date:                p_date_actual
		,droppable:           true
		,dropAccept:          "*"
		,viewDisplay:         function(view) { void(0); }
		,windowResize:        function(view) { void(0); }
		,dayClick:            function(date, allDay, jsEvent, view) { void(0); }
		,eventClick:          function(calEvent, jsEvent, view) { fnc_eventClick(calEvent, jsEvent, view); }
		,eventMouseover:      function(event, jsEvent, view) { fnc_eventMouseover(event, jsEvent, view); }
		,eventMouseout:       function(event, jsEvent, view) { fnc_eventMouseout(event, jsEvent, view); }
		,select:              function(startDate, endDate, allDay, jsEvent, view) {  }
		,unselect:            function(view, jsEvent ) { void(0); }
		,loading:             function(isLoading, view) { if( isLoading ){ fnc_mostrar_espera(false); $("#div_eventMouseover").remove(); }else{ fnc_ocultar_espera(); $("#div_eventMouseover").remove(); } }
		,eventDragStart:      function(event, jsEvent, ui, view) { g_dragging = true; $("#div_eventMouseover").remove(); }
		,eventDragStop:       function(event, jsEvent, ui, view) { g_dragging = false; }
		,eventDrop:           function(event, dayDelta, minuteDelta, allDay, revertFunc, jsEvent, ui, view) { fnc_eventDrop(event, dayDelta, minuteDelta, allDay, revertFunc, jsEvent, ui, view); }
		,eventResizeStart:    function(event, jsEvent, ui, view) { g_resizing = true; $("#div_eventMouseover").remove(); }
		,eventResizeStop:     function(event, jsEvent, ui, view) { g_resizing = false; }
		,eventResize:         function(event, dayDelta, minuteDelta, revertFunc, jsEvent, ui, view) { fnc_eventDrop(event, dayDelta, minuteDelta, false, revertFunc, jsEvent, ui, view); }
		,drop:                function(date, allDay, jsEvent, ui) { void(0); }
	});
}

//Función para reemplazar caracteres.
//Elaborado por: Gil Verduzco.
function replaceAll( txt, rep, with_this )
{
	return txt.replace( new RegExp( rep, 'g' ), with_this );
}

//Función que recibe una fecha string y la convierte a un objeto fecha.
//Elaborado por: Gil Verduzco.
function fnc_fecha_objeto(p_fecha, p_restar_mes)
{
	if( p_fecha )
	{
		//Nos aseguramos de que la fecha venga separada por guiones.
		var fecha = replaceAll( p_fecha, "/", "-" );
		
		//Quitamos los espacios en blanco.
		fecha = fecha.trim();
		
		//Validamos el formato de la fecha.
		if( fecha.split("-")[0].length == 4 ) //Formato: yyyy-mm-dd
		{
			var anio = fecha.split("-")[0] * 1;
			var mes = (p_restar_mes) ? fecha.split("-")[1] * 1 - 1 : fecha.split("-")[1] * 1;
			var dia = fecha.split("-")[2].split(" ")[0] * 1;
		}
		else //Formato: dd-mm-yyyyy
		{
			var anio = fecha.split("-")[2].split(" ")[0] * 1;
			var mes = (p_restar_mes) ? fecha.split("-")[1] * 1 - 1 : fecha.split("-")[1] * 1;
			var dia = fecha.split("-")[0] * 1;
		}
		
		//Validar si la fecha trae horas, minutos, segundos.
		var hora = 0;
		var minutos = 0;
		var segundos = 0;
		if( fecha.split(" ")[1] )
		{
			hora = fecha.split(" ")[1].split(":")[0] * 1;
			
			if( fecha.split(" ")[1].split(":")[1] )
				minutos = fecha.split(" ")[1].split(":")[1] * 1;
				
			if( fecha.split(" ")[1].split(":")[2] )
				segundos = fecha.split(" ")[1].split(":")[2] * 1;
		}
		
		//Creamos un objeto fecha.
		return new Date( anio, mes, dia, hora, minutos, segundos );
	}
	
	return null;
}

//Función que recibe un objeto fecha y la regresa en un string.
//Elaborado por: Gil Verduzco.
function fnc_fecha_string( p_obj_fecha, p_formato, p_sumar_mes )
{
	if( typeof( p_obj_fecha ) == "object" && p_formato )
	{	
		//Validar el formato de la fecha a regresar.
		var fecha_array = ( p_formato ? p_formato : "yyyy-mm-dd HH:mm:ss" ).split("-");
		var separador = "-";
		
		if( fecha_array.length == 1 )
		{
			fecha_array = p_formato.split("/");
			separador = "/";
		}
		
		if( fecha_array.length > 0 )
		{
			var anio = p_obj_fecha.getFullYear();
			var mes = fnc_poner_ceros_izq( ( (p_sumar_mes) ? ( p_obj_fecha.getMonth() + 1 ) : p_obj_fecha.getMonth() ), 2 );
			var dia = fnc_poner_ceros_izq( p_obj_fecha.getDate(), 2 );
			var hora = "";
			var minutos = "";
			var segundos = "";

			//Validar si el formato trae horas, minutos, segundos.
			if( p_formato.split(" ")[1] )
			{
				hora = " " + fnc_poner_ceros_izq( p_obj_fecha.getHours(), 2 );
				
				if( p_formato.split(" ")[1].split(":")[1] )
					minutos = ":" + fnc_poner_ceros_izq( p_obj_fecha.getMinutes(), 2 );
				
				if( p_formato.split(" ")[1].split(":")[2] )
					segundos = ":" + fnc_poner_ceros_izq( p_obj_fecha.getSeconds(), 2 );
			}
			
			//Regresamos la fecha formateada.
			if( fecha_array[0] == "yyyy" ) //Formato "yyyy[/, -]mm[/, -]dd [HH:mm:ss]".
				return ( anio + separador + mes + separador + dia + hora + minutos + segundos );
			else
				if( fecha_array[0] == "dd" ) //Formato "dd[/, -]mm[/, -]yyyy [HH:mm:ss]".
					return ( dia + separador + mes + separador + anio + hora + minutos + segundos );
		}
	}
	
	return null;
}

//Función para respetar los caracteres especiales.
//Elaborado por: Gil Verduzco.
function fnc_codificar(p_string)
{
	return encodeURIComponent( p_string );
}

//Función para formatear números.
function fnc_formatear_numeros(value, decimals, separators, simbolo_moneda)
{
    decimals = decimals >= 0 ? parseInt(decimals, 0) : 2;
    separators = separators || ['.', "'", ','];
	
    var number = (parseFloat(value) || 0).toFixed(decimals);
    if (number.length <= (4 + decimals))
        return simbolo_moneda + ( number.replace('.', separators[separators.length - 1]) );
    
	var parts = number.split(/[-.]/);
    value = parts[parts.length > 1 ? parts.length - 2 : 0];
    var result = value.substr(value.length - 3, 3) + (parts.length > 1 ?
        separators[separators.length - 1] + parts[parts.length - 1] : '');
    
	var start = value.length - 6;
    var idx = 0;
    while (start > -3)
	{
        result = (start > 0 ? value.substr(start, 3) : value.substr(0, 3 + start))
            + separators[idx] + result;
        idx = (++idx) % 2;
        start -= 3;
    }
    return simbolo_moneda + ( (parts.length == 3 ? '-' : '') + result );
}
// funcion para introducir solo numeros 
function fnc_solo_numeros(p_evt)
{
		
	var expresion_regular_numeros = /\d+/;
	var charCode = (p_evt.which) ? p_evt.which : p_evt.keyCode;
	var entrada = parseInt( String.fromCharCode(charCode) );
	return expresion_regular_numeros.test(entrada) || charCode == 8 || charCode == 9;
}
// funcion que permite introducir los valors numericos
function validarNro(e) {
	var key;
	if(window.event){
		key = e.keyCode;
	}
	else if(e.which){
		key = e.which;
	}	
	// validar que permita backspace o tabulador
	if (key == 8 || key == 9)    {
		return true;
    }
	if (key < 48 || key > 57)    {
		return false;
    }	
	return true;
}

//Función para hacer elemetnos draggables.
function fnc_elementos_draggables(p_elementos, p_start_drag, p_stop_drag)
{
	$(p_elementos).draggable({
		cursor: "move",
		revert: "invalid",
		helper: "clone",
		cursorAt: { top: -5, left: -5 },
		zIndex: 3000,
		start: function(){ if( p_start_drag ){ p_start_drag(); } },
		stop: function(){ if( p_stop_drag ){ p_stop_drag(); } }
	});
}


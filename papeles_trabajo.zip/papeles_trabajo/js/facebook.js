/*******************************************************************************************************************
****************** Elaborado por: Ernesto Diego Sanchez Tellaeche
*******************************************************************************************************************/


//********** OBJETO DE LAS NOTIFICACINES HTML 5 (JERRY) ***************

var notifications = window.webkitNotifications;
var totalActualNotificaciones = -1;
var facebook =
{
	inicializado: false,
	page_notificacion: "",
	page_notificacions: "",
	lEmpleado:   0,
	div_facebook: "facebook_ajax",
	dlg_facebook: "dlg_" + this.div_facebook,
	conteoInicios : 0,
	conteoSesiones : 0,
	funcionNotificaciones : function()
	{
		var sUrl = this.page_notificacion;
		var sContenedorFacebook = "#" + this.div_facebook;
		cargaAjax
		(
			sUrl,
			sContenedorFacebook,
			function ()
			{
				var sRespuesta = $( sContenedorFacebook ).text();
				var jsonRespuesta = jJSON.get( sRespuesta );
				
				if( !jsonRespuesta['ERROR'] )
				{
					facebook.setCountMessage( jsonRespuesta['TOTAL'] );
					
					//------JERRY!!!----------------									
					if( totalActualNotificaciones == -1 && facebook.conteoSesiones == 2 )
					{
						//facebook.mostrarNotificacionesIniciales(jsonRespuesta['TOTAL']);
						conteoSesiones++;	
					}
					else
					{
						facebook.mostrarNuevaNotificacion(	jsonRespuesta['TOTAL'] );
					}
				}
				else
				{
					facebook.setCountMessage( 0 );
				}
				this.inicializado = true;
			}
		);
	},
	
	//----------------variables para el mnejo del moitor de CP
	/*
	totalNotificacionesMonitor : -1,
	totalTicketsNuevos : -1,
	totalTicketsSeguimiento : -1,
	*/
	
	facebook: function( div_main )
	{
		$( "#blueBarHolder" ).remove();
		$( "#" + this.div_facebook ).remove();
		$( "#" + this.div_facebook + "_notify" ).remove();
		$( "#" + this.div_facebook + "_save" ).remove();		
		
		var sStyle = "position: fixed; left: 155px; top: 30px; width: 30px;";
		
		var oBarraContenido = ''
			+ '<div id="blueBarHolder" class="slim" style="' + sStyle + '">'
			+ '		<div id="blueBar">'
			+ '			<div class="clearfix" id="pageHead" role="banner">'
			+ '				<div id="jewelContainer">'
			+ '				</div>'
			+ '			</div>'
			+ '		</div>'
			+ '</div>'
			+ '<span id="' + this.div_facebook + '" style="display:none"></span>'
			+ '<span id="' + this.div_facebook + '_notify" style="display:none"></span>'
			+ '<span id="' + this.div_facebook + '_save" style="display:none"></span>';
		
		$( div_main ).append( oBarraContenido );
		
		//Se ejecuta la actualizacion de la fecha de la notificacion
		if(!window.intervalNotification)
		{
			window.intervalNotification = setInterval
			(
				function()
				{
					facebook.updateDateNotification();
				},
				60000
			);
		}
		
	},
	borrarTodasNotificaciones  : function()
	{
		url = com.pathCom() + '/ctl_notificaciones.cfc?method=EliminarTodasNotificaciones';
		cargaAjax
		(
			url,
			"#respuesta", 
			function()
			{
				var res = $("#respuesta").html().trim();
				if(res == 'session')
				{
					location.href = 'cierrasesion.php';
					return;	
				}
				facebook.CloseNotification();
			}
		);
		
	},
	add_button : function()
	{
		var sUrl = this.page_notificacions;

		var sFunctionClick = "facebook.lEmpleado=" + facebook.lEmpleado +";facebook.show_notification('" + sUrl + "');"
		var oBoton = ''
			+ '					<div class="fbJewel" id="fbMessagesJewel">'
			+ '						<a class="jewelButton" name="messages" onclick="' + sFunctionClick + '">'
			+ '							<span class="jewelCount" id="messagesCountWrapper">'
			+ '								<span id="messagesCountValue">0</span>'
			+ '							</span>'
			+ '						</a>'
			+ '					</div>';
			
		$( "#jewelContainer" ).append( oBoton );
	},
	add_notification: function()
	{
		var args = arguments[0];
		var titulo_notificacion     = args['titulo'] ? args['titulo']: "";
		var texto_enlace_head       = args['sub_titulo'] ? args['sub_titulo']: "";
		var link_head               = args['link_subtitulo'] ? args['link_subtitulo']: "";
		var texto_enlace_foot       = args['texto_footer'] ? args['texto_footer']: "";
		var link_foot               = args['link_footer'] ? args['link_footer']: "";
		this.page_notificacion      = args['page_notificacion'] ? args['page_notificacion']: "";
		this.page_notificacions     = args['page_notificacions'] ? args['page_notificacions']: "";
		this.lEmpleado              = args['empleado'] ? args['empleado']: 0;

		var area_enlace_subtitulo = "";
		area_enlace_subtitulo = '<span class="uiHeaderActions rfloat"> ' + texto_enlace_head + '</span>';
		if ( link_head != "" )
		{
			area_enlace_subtitulo = '<a class="uiHeaderActions rfloat" href="' + link_head + '">' + texto_enlace_head + '</a>';
		}

		
		var oNotificacion = ''
			+ '				<div class="fbJewelCaseFlyoutContainer" id="jewelFlyoutContainer" style="left: 140px;">'
			+ '					<div class="fbJewelFlyout toggleTargetClosed" id="fbMessagesFlyout">'
			+ '						<div class="uiHeader uiHeaderBottomBorder jewelHeader">'
			+ '							<div class="clearfix uiHeaderTop">'
			+ '								' + area_enlace_subtitulo
			+ '								<div>'
			+ '									<h3 class="uiHeaderTitle">' + titulo_notificacion + '</h3><button name="btn_reporte" onclick="facebook.borrarTodasNotificaciones();" style="float:left;" title="Eliminar Todas las Notificaciones"><img src="'+ com.imgDir() +'/delete.png" height="10" width="10"></button>'
			+ '								</div>'
			
			
			+ '								<div style="color:#FF0000; font-weight:bold;">'
			+ '									Debe dar clic en la notificaci&oacute;n para finalizar el pendiente y marcarlo con buen seguimiento.'
			+ '								</div>'
			
			
			+ '							</div>'
			+ '						</div>'
			+ '						<ul class="jewelItemList jewelHighlight" id="fbMessagesItemList">'
			+ '						</ul>'
			+ '						<div class="jewelFooter">'
			+ '							<a class="seeMore" href="' + link_foot + '">'
			+ '								<span>' + texto_enlace_foot + '</span>'
			+ '							</a>'
			+ '						</div>'
			+ '					</div>'
			+ '				</div>';

		this.add_button();

		$( ".fbJewel" ).after( oNotificacion );
		this.showLoadingImage();
		this.get_notificacion(args['conteoSesiones']);
		//this.inicializarSeguimiento(args['conteoSesiones']);	
	},
	show_notification: function( sUrl_Notification )
	{	
		$( "#fbMessagesJewel" ).toggleClass( "openToggler" );
		$( "#fbMessagesFlyout" ).toggleClass( "toggleTargetClosed" );
		
		this.page_notificacions = sUrl_Notification;
		
		
		//Preguntamos si la notificacion se encuentra abierta o no
		if ( this.isOpenNotification() )
		{
			this.hideCountMessage();
			this.setCountMessage( 0 );
			this.get_notifications();
		}
		
	},
	setCountMessage: function( iContador )
	{
		$( "#messagesCountValue" ).text( iContador );
		
		this.hideLoadingImage();
		this.hideCountMessage();

		if ( iContador>0 )
		{
			/*
			//agregar vibracion
			alert("vibrar");
			$('#contenedor_facebook').jrumble({
				x: 10,
				y: 10,
				rotation: 4
			});
			
			var demoTimeout;			
			
			clearTimeout(demoTimeout);
			$('#contenedor_facebook').trigger('startRumble');
			demoTimeout = setTimeout(function(){$('#contenedor_facebook').trigger('stopRumble');}, 1500);	
			
			//fin de agregar vibraci�n
			*/

			$( "#fbMessagesJewel" ).addClass( "hasNew" );
			
			if ( this.isOpenNotification() == false )
			{
				this.showLoadingImage();
			}
		}
	},
	showLoadingImage: function()
	{
		$( "#fbMessagesItemList" ).append
		(
			'							<li id="fbMessagesItemList_loading_indicator">' +
			'								<img class="jewelLoading img" src="aps/images/MiVDw0H5WyN.gif" alt="" width="16" height="11">' +
			'							</li>'
		);
	},
	hideLoadingImage: function()
	{
		$( "#fbMessagesItemList_loading_indicator" ).remove();
	},
	hideCountMessage: function()
	{
		$( "#fbMessagesJewel" ).removeClass( "hasNew" );
		$( "#fbMessagesJewel" ).addClass( "hidden_elem" );
	},
	get_notificacion: function(conteoSessiones)
	{
		facebook.conteoSesiones = conteoSessiones;
		
		var sUrl = this.page_notificacion;
		var sContenedorFacebook = "#" + this.div_facebook;
		
		facebook.funcionNotificaciones();
				
		if ( sUrl!="" || this.inicializado == false )
		{
			if(!window.intervalComentario)
			{
				window.intervalComentario = setInterval
				(
					'facebook.funcionNotificaciones()',
					30000
				);
			}
		}
	},
	get_notifications: function()
	{
		var args                = arguments[0];
		var div_content         = "#fbMessagesItemList";
		var bLimite             = "TRUE";
		var sUrl                = this.page_notificacions;
		
		if ( args )
		{
			div_content         = args['div_content'] ? args['div_content']: "#fbMessagesItemList";
			bLimite             = args['bLimite'] ? args['bLimite']: "TRUE";
			sUrl                = sUrl + "&bLimite=" + bLimite;
		}
		var sContenedorFacebook = "#" + this.div_facebook + '_notify';
		var lEmpleado           = this.lEmpleado;

		if ( sUrl!="" )
		{
			$( "#fbMessagesItemList" ).html("");
			this.showLoadingImage();
			cargaAjax
			(
				sUrl,
				sContenedorFacebook,
				function ()
				{
					var sRespuesta = $( sContenedorFacebook ).text();
					var jsonRespuesta = jJSON.get( sRespuesta );
					
					if( !jsonRespuesta['ERROR'] )
					{
						if ( jsonRespuesta['ROWCOUNT'] == 1 )
						{
							facebook.lEmpleado = lEmpleado;
							facebook.add_item
							(
								{
									num_notification: jsonRespuesta['NumNotificacion'],
									author_notification: jsonRespuesta['nomempleado'],
									text_notification: jsonRespuesta['TextoComentario'],
									date_notification: jsonRespuesta['FechaComentario'],
									type_notification: jsonRespuesta['TipoNotificacion'],
									date_server: jsonRespuesta['FechaServidor'],
									//ticket_notification: jsonRespuesta['NUMTICKET'],
									
									 id_peticion 		  : jsonRespuesta['id_peticion'],
									 id_version	 		  : jsonRespuesta['id_version'],
									 id_fase 		  	  : jsonRespuesta['id_fase'],
									 id_subfase 		  : jsonRespuesta['id_subfase'],
									 id_sistema 		  : jsonRespuesta['id_sistema'],
									 id_modulo 		      : jsonRespuesta['id_sistema_modulo'],
									 id_opcion 		      : jsonRespuesta['id_sistema_modulo_opcion'],
									
									emps_notification: jsonRespuesta['EmpHanLeeido'],
									div_content: div_content
								}
							);
							facebook.hideLoadingImage();
						}
						else
						{
							if ( jsonRespuesta['ROWCOUNT'] > 1 )
							{
								var lRegistro = 0;

								while ( lRegistro < jsonRespuesta['ROWCOUNT'] )
								{
									facebook.lEmpleado = lEmpleado;
									facebook.add_item
									(
										{
											num_notification: jsonRespuesta['NumNotificacion'][lRegistro],
											author_notification: jsonRespuesta['nomempleado'][lRegistro],
											text_notification: jsonRespuesta['TextoComentario'][lRegistro],
											date_notification: jsonRespuesta['FechaComentario'][lRegistro],
											type_notification: jsonRespuesta['TipoNotificacion'][lRegistro],
											date_server: jsonRespuesta['FechaServidor'][lRegistro],
											//ticket_notification: jsonRespuesta['NUMTICKET'][lRegistro],
											
											id_peticion 		  : jsonRespuesta['id_peticion'][lRegistro],
											 id_version	 		  : jsonRespuesta['id_version'][lRegistro],
											 id_fase 		  	  : jsonRespuesta['id_fase'][lRegistro],
											 id_subfase 		  : jsonRespuesta['id_subfase'][lRegistro],
											 id_sistema 		  : jsonRespuesta['id_sistema'][lRegistro],
											 id_modulo 		      : jsonRespuesta['id_sistema_modulo'][lRegistro],
											 id_opcion 		      : jsonRespuesta['id_sistema_modulo_opcion'][lRegistro],
											
											emps_notification: jsonRespuesta['EmpHanLeeido'][lRegistro],
											div_content: div_content
										}
									);
									lRegistro++;
									facebook.updateDateNotification();
								}
								facebook.hideLoadingImage();
							}
						}
					}
					else
					{
						facebook.setCountMessage( 0 );
					}
				}
			);
		}
	},
	get_all_notifications: function(divContenedor)
	{
		facebook.get_notifications
		(
			{
				bLimite: "FALSE",
				div_content: divContenedor
			}
		);
	},
	add_item: function()
	{
		var args = arguments[0];
		var num_notification      = args['num_notification'];
		var author_notification   = args['author_notification'];
		var text_notification     = args['text_notification'];
		var date_notification     = args['date_notification'];
		var type_notification     = args['type_notification'];
		var date_server           = args['date_server'];
		//var ticket_notification   = args['ticket_notification'];
		
		var id_peticion 		  = args['id_peticion'];
		var id_version	 		  = args['id_version'];
		var id_fase 		  	  = args['id_fase'];
		var id_subfase 		  	  = args['id_subfase'];
		var id_sistema 		      = args['id_sistema'];
		var id_modulo 		      = args['id_sistema_modulo'];
		var id_opcion 		      = args['id_sistema_modulo_opcion'];
		
		var emps_notification     = new String(args['emps_notification']);
		var div_content           = args['div_content'] ? args['div_content']: "#fbMessagesItemList";
		
		
		var sUrlClickNotification = this.get_urlNotification( args );
			
		var sNewNotificacion      = "jewelItemNew";
		
		if ( emps_notification.indexOf(this.lEmpleado) >=0 )
		{
			sNewNotificacion = "";
		}
		
		var sStyleBtnCerrar = ' style="float: right; margin-right: 0.8em; margin-top: 0.8em;" ';
		var sClicBtnCerrar  = ' onclick="facebook.marcar_leido(' + this.lEmpleado + ',' + num_notification + ' );" ';
		var sImgBtnCerrar   = ' src="aps/images/delete_close.png" ';
		var sSizeBtnCerrar  = ' width="12px" height="12px" ';
		var sBotonCerrar    = '<span '+ sStyleBtnCerrar + sClicBtnCerrar + '><img '+ sImgBtnCerrar + sSizeBtnCerrar + '></span>';
		
		
		var oElemento = ''
			+ '<li class="' + sNewNotificacion + '" id="notify_' + this.lEmpleado + '_iNum_' + num_notification + '" >'
			+ '		<div class="UIImageBlock clearfix">'
			+ sBotonCerrar
			+ '			<a href="#" onclick="' + sUrlClickNotification + '" title="'+ text_notification + '" >'
			+ '			<div class="content UIImageBlock_Content UIImageBlock_SMALL_Content fsm fwn fcg" style="padding-left: 10px;">'
			+ '				<div class="author">'
			+ '					<strong>' + author_notification + '</strong>'
			+ '				</div>'
			+ '				<div class="snippet preview fsm fwn fcg">'
			+ '                 <img src="' + facebook.get_imgNotification(type_notification) + '" width="18" height="18">'
			+ '					<span>' + text_notification + '</span>'
			+ '				</div>'
			+ '				<div class="time">'
			+ '					<abbr data-date="' + date_notification + '" data-date_server="' + date_server + '"  class="timestamp"></abbr>'
			+ '				</div>'
			+ '			</div>'
			+ '			</a>'
			+ '		</div>'
			+ '</li>';
			
		$( div_content ).prepend( oElemento );
	},
	marcar_leido: function( lEmpleadoNotificacion, iNotificacion )
	{
		var sRutaComponentes      = "aps/componentes";
		var contenedor            = "#" + this.div_facebook + "_save";
		var notificacion          = "#notify_" + lEmpleadoNotificacion + "_iNum_" + iNotificacion
		
		
		
		var sUrlNotificacionLeida = sRutaComponentes + "/ctl_notificaciones.cfc?method=funAgregaCtlNotificaciones"
		                          + "&cOpcion=M"
								  + "&sUsuariosLeidos=" + lEmpleadoNotificacion
								  + "&iNumNotificacion=" + iNotificacion;
		cargaAjax
		(
		 	sUrlNotificacionLeida ,
			contenedor,
			function()
			{
				$( notificacion ).removeClass( "jewelItemNew" );
				$( notificacion ).fadeOut( 500 );
			}
		);
		
		/*
		var url = com.pathDir() + "/postdata.cfm?opcion=marcar_leido_notificacion";
		loadPageAjax
		(
			{
				webpage: url,
				content: contenedor,
				parameters: 
				{
					method             : "funAgregaCtlNotificaciones",
					component          : "ctl_notificaciones",
					
					sUsuariosLeidos    : lEmpleadoNotificacion,
					iNumNotificacion   : iNotificacion
				},
				webfunction: function()
				{
					$( notificacion ).removeClass( "jewelItemNew" );
				}
			}
		);
		*/
	},
	isOpenNotification: function()
	{
		return $( "#fbMessagesJewel" ).hasClass("openToggler");
	},
	CloseNotification: function()
	{
		$( "#fbMessagesJewel" ).toggleClass( "openToggler" );
		$( "#fbMessagesFlyout" ).toggleClass( "toggleTargetClosed" );
		//cerrarModalTodasNotificaciones();
		
	},
	get_imgNotification: function( type_notification )
	{
		var sRegresa = "";
		var url_imgs = "aps/images";
		var img_notificacion = new Array
								(
								 	url_imgs + "/add_ticket.png",         //Agregar
									url_imgs + "/delete_ticket.png",      //Finiquitar
									url_imgs + "/chat.png",               //Comentarios
									url_imgs + "/question.png",           //Pregunta
									url_imgs + "/idea.png",               //Sugerencia
									url_imgs + "/check_comentarios.png"   //Solucion Final
								);
		
		if ( type_notification>=0 && type_notification<=5 )
		{
			sRegresa = img_notificacion[ type_notification ];
		}
		else if ( type_notification>=6 && type_notification<=11 )
		{
			sRegresa = img_notificacion[ type_notification-6 ];
		}
								
		return sRegresa;
	},
	get_urlNotification: function()
	{
		var args = arguments[0];
		var num_notification      = args['num_notification'];
		var author_notification   = args['author_notification'];
		var text_notification     = args['text_notification'];
		var date_notification     = args['date_notification'];
		var type_notification     = args['type_notification'];
		var date_server           = args['date_server'];
		var ticket_notification   = args['ticket_notification'];
		var emps_notification     = new String(args['emps_notification']);;
		var sRegresa              = "";
		var sUrl                  = "";
		var sRutaPaginas          = "aps/ajax";
		var sRutaComponentes      = "aps/componentes";
		var contenedor            = "#" + this.div_facebook + "_save";
		var sFuncionGotoPage      = "";
				
		//Cadena que representar� la llave completa de la petici�n (petici�n, version, fase, subfase, sistema, modulo, opcion)
		var pvfssmo = 'id_peticion=' + args['id_peticion'] + '&id_version=' + args['id_version'] + '&id_fase=' + args['id_fase'] + '&id_subfase=' + args['id_subfase'] + '&id_sistema=' + args['id_sistema'] + '&id_sistema_modulo=' + args['id_modulo'] + '&id_sistema_modulo_opcion=' + args['id_opcion'];	
							
		switch(parseInt(type_notification))
		{
			case 1: sUrl = sRutaPaginas + '/asignacion_analistas_agregar_lider.cfm?' + pvfssmo;
			break;
			
			case 2: sUrl =  sRutaPaginas + '/solicitante_en_analisis_comentarios.cfm?' + pvfssmo;
			break;
			
			case 3: sUrl =  sRutaPaginas + '/consulta_prioridades_por_peticion.cfm?' + pvfssmo;
			break;
			
			case 4: sUrl =  sRutaPaginas + '/peticiones_listado_detalle_arquitecto.cfm?' + pvfssmo;
			break;
			
			case 5: sUrl =  sRutaPaginas + '/solicitante_en_analisis_comentarios.cfm?' + pvfssmo;
			break;
			
			case 6: sUrl =  sRutaPaginas + '/peticiones_por_analizar_comentarios.cfm?' + pvfssmo;
			break;
			
			case 7: sUrl =  sRutaPaginas + '/solicitante_autoriza_rechaza_ern.cfm?' + pvfssmo;
			break;
			
			case 8: sUrl =  sRutaPaginas + '/solicitante_autoriza_rechaza_ern.cfm?' + pvfssmo;
			break;
			
			case 9: sUrl =  sRutaPaginas + '/comentarios_solicitante_analista.cfm?' + pvfssmo + '&mostrarBlog=S';
			break;
			
			case 10: sUrl =  sRutaPaginas + '/solicitante_por_analizar_comentarios.cfm?' + pvfssmo + '&mostrarBlog=S';
			break;
			
			case 11: sUrl =  sRutaPaginas + '/solicitante_por_analizar_comentarios.cfm?' + pvfssmo + '&mostrarBlog=S';
			break;
			
			case 12: sUrl =  sRutaPaginas + '/peticiones_por_analizar_comentarios.cfm?' + pvfssmo;
			break;		
		}
		
				
		//Definiremos a qu� pantalla va a llevar cada uno de los tipos de notificaciones
		var sUrlNotificacionLeida = sRutaComponentes + "/ctl_notificaciones.cfc?method=funAgregaCtlNotificaciones"
								  + "&cOpcion=M"
								  + "&sUsuariosLeidos=" + this.lEmpleado
								  + "&iNumNotificacion=" + num_notification;
								  
		sFuncionGotoPage = "cargaAjax( '" + sUrl + "','#centro', function(){ facebook.CloseNotification(); } );";
		sRegresa = "cargaAjax( '" + sUrlNotificacionLeida + "','" + contenedor + "',function(){ " + sFuncionGotoPage + " } );";

		//Si el Empleado ya leeyo el comentario no se manda llamar la funcion para marcarlo como leido 
		if ( emps_notification.indexOf(this.lEmpleado) >=0 )
		{
			sRegresa = sFuncionGotoPage;
		}
		
		return sRegresa;
		
		
	},
	updateDateNotification: function()
	{
		//Funcion que se encarga de colocar el tiempo transcurrido a las notificaciones
		var timestring;
		var timeserverstring;
		var diff;
		var now = new Date();
		var newstring = "";
		var datestringname = "";
		
		
		$( 'abbr.timestamp' ).each
		(
			function()
			{
				datestring = new Date( $(this).attr("data-date") );
				timestring = new Date( $(this).attr("data-date") );
				timestring = timestring.getTime();
				timeserverstring =   new Date( $(this).attr("data-date_server") );
				
				diff = Math.ceil(timeserverstring.getTime() - timestring);

				newstring = facebook.diffTimeString(diff);
				
				if( newstring != null )
				{
					$(this).html( newstring );
				}
				
				datestringname = facebook.setTimeNameString( datestring );
				if ( datestringname!= null )
				{
					$(this).attr( "title", datestringname );
				}
			}
		);
	},
	setTimeNameString: function( time )
	{
		//Funcion que se encargara de colocar el formato de la fecha en el tooltip
		var sMeses = new Array
						(
						 	"Enero",
							"Febrero",
							"Marzo",
							"Abril",
							"Mayo",
							"Junio",
							"Julio",
							"Agosto",
							"Septiembre",
							"Octubre",
							"Noviembre",
							"Diciembre"
						);
		var sSemana = new Array
						 (
						  	"Domingo",
							"Lunes",
							"Martes",
							"Mi�rcoles",
							"Jueves",
							"Viernes",
							"S�bado"
						 );
		var sRespuesta = "";
		var sDia = time.getDate();
		var sHrs = time.getHours();
		var sMins = time.getMinutes();
		var sHora = "";
		
		if ( sDia < 9 ) sDia = "0" + sDia;
		if ( sHrs < 9 ) sHrs = "0" + sHrs;
		if ( sMins < 9 ) sMins = "0" + sMins;
		
		sHora = sHrs + ":" + sMins;
		
		sRespuesta = sSemana[ time.getDay() ] + ", " + sDia + " de " + sMeses[ time.getMonth() ] + " de " + time.getFullYear() + ", " + sHora;
		
		return sRespuesta;
	},
	diffTimeString: function( time )
	{
		// Funcion que se encarga de colocar el tiempo en un formato entendible para el humano
		var result = null;
		var one_milisegundo = 1000;
		var one_segundo     = 1;
		var one_minuto      = 60 * one_segundo;
		var one_hora        = 60 * one_minuto;
		var one_dia         = 24 * one_hora;
		var one_semana      = 7  * one_dia;
		var one_mes         = 4  * one_semana;
		var one_year        = 12 * one_mes;
		
		time = Math.ceil( time/one_milisegundo );

		
		if( time > (one_segundo + 1) ) // minimo 2 segundos
		{
			if( time < one_minuto )
			{
				result = 'Hace ' + time + ' segundos';
			}
			else if( time >= one_minuto && time < one_hora )
			{
				time = Math.round( time/one_minuto );
				
				if( time == 1 )
					result = 'Hace ' + time + ' minuto';
				else
					result = 'Hace ' + time + ' minutos';
			}
			else if( time >= one_hora && time < one_dia )
			{
				time = Math.round( time/one_hora );
				
				if( time == 1 )
					result = 'Hace ' + time + ' hora';
				else
					result = 'Hace ' + time + ' horas';
			}
			else if( time >= one_dia && time < one_semana )
			{
				time = Math.round( time/one_dia );

				if( time == 1 )
					result = 'Ayer';
				else
					result = 'Hace ' + time + ' d&iacute;as';
			}
			else if( time >= one_semana && time < one_mes )
			{
				time = Math.round( time/one_semana );
				
				if( time == 1 )
					result = 'Hace ' + time + ' semana';
				else
					result = 'Hace ' + time + ' semanas';
			}
			else if( time >= one_mes && time < one_year )
			{
				time = Math.round( time/one_mes );
				
				if( time == 1 )
					result = 'Hace ' + time + ' mes';
				else
					result = 'Hace ' + time + ' meses';
			}
			else if( time >= one_year )
			{
				time = Math.round( time/one_year );
				
				if( time == 1 )
					result = 'Hace ' + time + ' a&ntilde;o';
				else
					result = 'Hace ' + time + ' a&ntilde;os';
			}
			else
			{
				result = null;
			}
		}

		return result;
	},
	//JERRY!!!
	mostrarNuevaNotificacion : function(totalNotificaciones)
	{
		/*Si el numero de notificaciones devuelto por la actualizacion de cada dos segundos es mayor que el numero de notificaciones
		almacenado, entonces consultaremos los datos de la �ltima notificaci�n y los mostraremos en la nueva ventana modal...*/
		if(totalNotificaciones > totalActualNotificaciones && totalActualNotificaciones != -1)
		{
			//llamamos por Ajax a la funci�n que nos traer� los datos de la �ltima notificacion...
			url= com.pathCom() + '/ctl_notificaciones.cfc?method=funConsultaCtlNotificaciones&blimite=false&primera=1&ordenacion=desc&lEmpleado=' + this.lEmpleado;
			cargaAjax
			(
				url,
				'#facebook_ajax',
				function()
				{
					var resultdo = $("#facebook_ajax").text();
					var jsonRespuesta = jJSON.get( resultdo );
					
					if( !jsonRespuesta['ERROR'] )
					{
						//dependiendo del tipo de notificaci�n, se construirpa la cadena del titulo de la ventana de notificaci�n
						var tituloNotificacion = '';
						var iconoNotificacion = 0;						
						
						switch(parseInt(jsonRespuesta['TIPONOTIFICACION']))
						{
							case 0:
								tituloNotificacion = 'AGREG\u00d3  NUEVO TICKET';
								iconoNotificacion = 6;
								break;
							case 1: 
								tituloNotificacion = 'FINIQUIT\u00d3 UN TICKET';
								iconoNotificacion = 7;
								break;
							case 2: 
								tituloNotificacion = 'AGREG\u00d3 COMENTARIO EN TICKET';
								iconoNotificacion = 8;
								break;
							case 3: 
								tituloNotificacion = 'REALIZ\u00d3 UN PREGUNTA';
								iconoNotificacion = 9;
								break;
							case 5: 
								tituloNotificacion = 'DI\u00d3 SOLUCI\u00d3N FINAL';
								iconoNotificacion = 10;
								break;
							case 7: 
								tituloNotificacion = 'FINIQUIT\u00d3 TICKET EN PROGRAMACI\u00d3N';
								iconoNotificacion = 10;
								break;
							case 8: 
								tituloNotificacion = 'COMENT\u00d3 TICKET EN PROGRAMACI\u00d3N';
								iconoNotificacion = 8;
								break;
							case 12:
								tituloNotificacion = 'TICKET CON PRIORIDAD PARA CONTROL PROGRAMACI\u00d3N';
								iconoNotificacion = 12;
								break;
															
						}
									
						tituloNotificacion = jsonRespuesta['NOMEMPLEADO'] + " " +tituloNotificacion
						textoNotificacion = "Ticket: " + jsonRespuesta['NUMTICKET'] + ", " + jsonRespuesta['TEXTOCOMENTARIO'].split(',')[1];
						//Ahora si, generando la ventanita de notificaci�n
						
						notify.ensurePermission(  function(){  notify.simpleNotify(   iconoNotificacion , tituloNotificacion , textoNotificacion   );  }  );					
					}						
				}
			);
			
		}
		totalActualNotificaciones = totalNotificaciones;		
	},
	
	mostrarNotificacionesIniciales : function(total)
	{			
		notify.ensurePermission(  function(){  notify.simpleNotify(   5 , "BIENVENIDO A CONTROL INCIDENCIAS!!!" , "Tiene " + total + " notificaciones sin leer."   );  }  );						
		totalActualNotificaciones = total;
	},
	
	
};

//-------------------------------------------------------------------------
var notify = 
	{
		simpleNotify: function(icon, title,content)
		{
					
			var urlicon = notify.getUrlIcon(icon);
				
			notifications.createNotification(urlicon,title,content).show();	
					
		},		
		
		 ensurePermission: function (callback) 
		 {
				if (notifications.checkPermission() == 0) 
				{
				  callback();
				} 
				else 
				{
					  notifications.requestPermission
					 (
						function() 
						{
							if (notifications.checkPermission() == 0) callback();
						}
					 );
				}
		  },
		  
		  getUrlIcon: function(icon)
		  {
				if(icon == 1) //check
				{
					urlicon = com.imgDir() + '/add_ticket.png';
				}
				else if(icon == 2)//delete
				{
					urlicon = com.imgDir() + '/delete.png';
				}
				else if(icon == 3)//question
				{
					urlicon = com.imgDir() + '/question.png';
				}
				else if(icon== 4)//warning
				{
					urlicon = com.imgDir() + '/calendar.png';	
				}
				else if(icon== 5)//Smiley
				{
					urlicon = com.imgDir() + '/smile_notify.jpg';	
				}
				
				//--------------------------------ICONOS PAR LAS NOTIFICACIONES VIEJAS------
				else if(icon== 6)//agregar ticket
				{
					urlicon = com.imgDir() + '/add_ticket.png';	
				}
				else if(icon== 7)//finiquitar ticket
				{
					urlicon = com.imgDir() + '/delete_ticket.png';	
				}
				else if(icon== 8)//comentario / comentario en programacion
				{
					urlicon = com.imgDir() + '/add_comentario.png';	
				}
				else if(icon== 9)//pregunta
				{
					urlicon = com.imgDir() + '/question.png';	
				}
				else if(icon== 10)//solucion final / finiquito en programaci�n
				{
					urlicon = com.imgDir() + '/check.png';	
				}
				else if(icon== 11)//solucion final / finiquito en programaci�n
				{
					urlicon = com.imgDir() + '/warning_notify.png';	
				}
				else if(icon== 12)//PRIORIAD MAS-CP
				{
					urlicon = com.imgDir() + '/torreta.png';	
				}
				return urlicon;										  
		  }  		  
	};
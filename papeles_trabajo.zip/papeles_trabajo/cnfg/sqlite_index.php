<?php
//First you need include the class file
require_once "pdo_database.class.php";

//Tipos de Datos
//INTEGER - TEXT - REAL - BLOB
//Cuando no se especifica el INTEGER lo toma como autonumerico, o tambien cuando se especifica el campo y se le da valor NULL.

//Intance the class
$db = new wArLeY_DBMS("sqlite2", "database.sqlite2", "", "", "", "");
$db = $db->Cnxn();
if($db==false){
	echo "Error: Cant connect to database.";
	die;
}

/*
//Se crea la tabla de usuarios y se le graba la informacion que le corresponde
$db->query('DROP TABLE TB_USERS;');
$query_create_table = <<< EOD
CREATE TABLE TB_USERS (
  TB_USERS_ID INTEGER PRIMARY KEY,
  TB_USERS_NUM_EMPLEADO TEXT(8) NOT NULL UNIQUE,
  TB_USERS_PRIVILEGIOS TEXT(10) NOT NULL,
  TB_USERS_ESTATUS TEXT(1) NOT NULL
);
EOD;
$db->query($query_create_table);

$db->query("INSERT INTO TB_USERS (TB_USERS_NUM_EMPLEADO, TB_USERS_PRIVILEGIOS, TB_USERS_ESTATUS) VALUES ('93858132', '511', 'A');");
$db->query("INSERT INTO TB_USERS (TB_USERS_NUM_EMPLEADO, TB_USERS_PRIVILEGIOS, TB_USERS_ESTATUS) VALUES ('93842007', '511', 'A');");
$db->query("INSERT INTO TB_USERS (TB_USERS_NUM_EMPLEADO, TB_USERS_PRIVILEGIOS, TB_USERS_ESTATUS) VALUES ('91680727', '511', 'A');");
$db->query("INSERT INTO TB_USERS (TB_USERS_NUM_EMPLEADO, TB_USERS_PRIVILEGIOS, TB_USERS_ESTATUS) VALUES ('93857004', '511', 'A');");
$db->query("INSERT INTO TB_USERS (TB_USERS_NUM_EMPLEADO, TB_USERS_PRIVILEGIOS, TB_USERS_ESTATUS) VALUES ('94059985', '511', 'A');");

$rs = $db->query("SELECT * FROM TB_USERS");
foreach($rs as $row){
	$tmp_id = $row["TB_USERS_ID"];
	$tmp_name = $row["TB_USERS_NUM_EMPLEADO"];
	
	echo "The user ($tmp_id) is named: $tmp_name<br>";
}
$rs = null;
*/



/*
//Se crea la tabla de opciones y se le graba la informacion que le corresponde
$db->query('DROP TABLE TB_MENU;');
$query_create_table = <<< EOD
CREATE TABLE TB_MENU (
  TB_MENU_ID INTEGER PRIMARY KEY,
  TB_MENU_TITULO TEXT(50) NOT NULL UNIQUE,
  TB_MENU_ICONO TEXT(100) NOT NULL DEFAULT "",
  TB_MENU_ARCHIVO TEXT(100) NOT NULL DEFAULT "",
  TB_MENU_ORDEN INTEGER
);
EOD;
$db->query($query_create_table);

$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Tareas','tareas.png','tabla2.php',1);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Correo Micro','CorreoMicro.png','doble_tabla.php',2);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Calendario','Calendario.png','ajax_calendario.php',3);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Indicadores','Indicadores.png','ajax_indicadores.php',4);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Mensajero','Mensajero.png','',5);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Personal','Perfil.png','',6);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Avisos','Avisos.png','',7);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Herramientas','Herramientas.png','',8);");
$db->query("INSERT INTO TB_MENU (TB_MENU_TITULO,TB_MENU_ICONO,TB_MENU_ARCHIVO,TB_MENU_ORDEN) VALUES ('Aplicaciones','aplicaciones.png','ajax_appz.php',0);");

$rs = $db->query("SELECT * FROM TB_MENU");
foreach($rs as $row){
	$tmp_id = $row["TB_MENU_ID"];
	$tmp_name = $row["TB_MENU_TITULO"];
	$tmp_icon = $row["TB_MENU_ICONO"];
	
	echo "The user ($tmp_id) is named: $tmp_name . $tmp_icon <br>";
}
$rs = null;
*/


/*
//Se crea la tabla de tiempos para el calendario del eleazar
$db->query('DROP TABLE TB_TIEMPOS;');
$query_create_table = <<< EOD
CREATE TABLE TB_TIEMPOS (
  TB_TIEMPOS_ID INTEGER PRIMARY KEY,
  TB_TIEMPOS_EVENTO TEXT(50) NOT NULL DEFAULT "",
  TB_TIEMPOS_INICIO TEXT(10) NOT NULL DEFAULT "",
  TB_TIEMPOS_FIN TEXT(10) NOT NULL DEFAULT ""
);
EOD;
$db->query($query_create_table);

$db->query("INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO,TB_TIEMPOS_INICIO,TB_TIEMPOS_FIN) VALUES ('Baby Shower Amy', '2011-03-05', '2011-03-05');");
$db->query("INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO,TB_TIEMPOS_INICIO,TB_TIEMPOS_FIN) VALUES ('Entrenamiento Softball', '2011-03-03', '2011-03-03');");
$db->query("INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO,TB_TIEMPOS_INICIO,TB_TIEMPOS_FIN) VALUES ('Partido de Softball', '2011-03-06', '2011-03-06');");
$db->query("INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO,TB_TIEMPOS_INICIO,TB_TIEMPOS_FIN) VALUES ('Fiesta Anual', '2011-03-05', '2011-03-05');");
$db->query("INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO,TB_TIEMPOS_INICIO,TB_TIEMPOS_FIN) VALUES ('Presentacion de Standar', '2011-03-04, '2011-03-04');");
$db->query("INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO,TB_TIEMPOS_INICIO,TB_TIEMPOS_FIN) VALUES ('Quincena xD', '2011-03-15', '2011-03-15');");

$rs = $db->query("SELECT * FROM TB_TIEMPOS");
foreach($rs as $row){
	$tmp_event = $row["TB_TIEMPOS_EVENTO"];
	$tmp_ini = $row["TB_TIEMPOS_INICIO"];
	$tmp_fin = $row["TB_TIEMPOS_FIN"];
	
	echo "The event ($tmp_event) in range: $tmp_ini to $tmp_fin <br>";
}
$rs = null;
*/
?>
<?php
function LiveSession($sess, $refresh){
	$inactive_limit = 900;  //15 minutos
	$G_timeout = $sess->get_var('G_timeout');
	
	if(trim($_SERVER['REMOTE_ADDR']!="127.0.0.1")){
		//Omitimos la sesion.
		return 1; 
		die;
		
		if(isset($G_timeout)){
			//Verificamos la sesion para ver si ya expiro, caso contrario la actualizamos.
			$session_life = time_to_sec(time()) - time_to_sec($G_timeout);
			if($session_life > $inactive_limit){
				return 0;
				die;
			}
		}
		else{
			return 0;
			die;
		}
	}

	if($refresh==1){
		//Se actualiza la sesion
		$sess->set_var('G_timeout', time());
	}
	return 1;
}

function time_to_sec($time) {
	$hours = substr($time, 0, -6);
	$minutes = substr($time, -5, 2);
	$seconds = substr($time, -2);
	return $hours * 3600 + $minutes * 60 + $seconds;
}
?>
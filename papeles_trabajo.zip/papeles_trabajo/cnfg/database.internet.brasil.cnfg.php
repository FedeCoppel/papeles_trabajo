<?php

define("DB_TYPE_PG","pg");
define("DB_USUARIO_PROCON","postgres");
define("DB_PASS_PASSWORD_PROCON","postgres");
define("DB_SERVER_PROCON","10.45.225.56");
define("DB_SAJ","procon");

//conexion a la base de datos dentro del servidor pruebas sudamerica
define("DB_tmpadministrativo","Tmp_Administrativo ");

//Conexion en el servidor de brasil
define("DB_SERVER_Brasil","10.44.210.32");
define("DB_Brasil","Tmp_Administrativo");
define("DB_USUARIO_Brasil","postgres");
define("DB_PASS_PASSWORD_Brasil","postgres");
?>
<?php
$mysql_db_type = "mysql";
$mysql_db_server = "10.33.128.27";
$mysql_db_user = "irving";
$mysql_db_pass = "123";
$mysql_db_db = "gpsgate";

$sqlsrv_db_type = "sqlsrv";
$sqlsrv_db_server = "10.44.1.4";
$sqlsrv_db_user = "internet";
$sqlsrv_db_pass = "internet";
$sqlsrv_db_db = "MaestroMuebles";

$mssql_db_type = "mssql";
$mssql_db_server = "10.33.128.18";
$mssql_db_user = "irving";
$mssql_db_pass = "pelaez";
$mssql_db_db = "cartas";

$mssql_db_type = "mssql";
$mssql_db_server = "10.0.31.129";
$mssql_db_user = "230114";
$mssql_db_pass = "c5e42e962d51f6dbf9e8521f6a652be3";
$mssql_db_db = "GestionBD";

/*
$pg_admin_db_type = "pg";
$pg_admin_db_server = "10.44.1.7";
$pg_admin_db_user = "postgres";
$pg_admin_db_pass = "Zahuate99";
$pg_admin_db_db = "intranet_administracion";
$pg_admin_db_port   = "5432";
*/

/*if($_SERVER["SERVER_NAME"]=="intranet.br"){ # Intranet BR - Brazil
	$pg_admin_db_type = "pg";
	$pg_admin_db_server = "intranet.br";
	$pg_admin_db_user = "postgres";
	$pg_admin_db_pass = "postgres";
	$pg_admin_db_db = "intranet_administracion";
	$pg_admin_db_port   = "5432";
}else if($_SERVER["SERVER_NAME"]=="intranet.ar"){*/ # Intranet AR - Argentina
	$pg_admin_db_type = "pg";
	//$pg_admin_db_server = "10.45.225.35";
	$pg_admin_db_server = "10.44.74.130";
	// original
	// $pg_admin_db_server = "bdinternet.ar";
	// $pg_admin_db_user = "syspersonalinternet";	
	// $pg_admin_db_pass = "2d348ed7d899b5e7046f9337d6c76d58";
	// termina original
	$pg_admin_db_user = "syspersonal";
	$pg_admin_db_pass = "d894dab691238a6b66b73b2a94abd3f5";
	$pg_admin_db_db = "intranet_administracion";
	$pg_admin_db_port   = "5432";
/*}else{ #Default Intranet MX - Mexico
	$pg_admin_db_type = "pg";
	$pg_admin_db_server = "intranet.cln";
	$pg_admin_db_user = "postgres";
	$pg_admin_db_pass = "Zahuate99";
	$pg_admin_db_db = "intranet_administracion";
	$pg_admin_db_port   = "5432";
}*/

$pg_db_type = "pg";
$pg_db_server = "10.33.128.141";
$pg_db_user = "postgres";
$pg_db_pass = "postgres";
$pg_db_db = "coppel_canada";

$fbd_db_type = "fbd";
$fbd_db_server = "localhost";
$fbd_db_user = "SYSDBA";
$fbd_db_pass = "masterkey";
$fbd_db_db = "C:\TEST.FDB";
?>
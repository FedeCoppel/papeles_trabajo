<?php
/******************************************
 *
 * PDO Database class manual for v1.9
 *
 * @author:    	Evert Ulises German Soto
 * @copyright: 	wArLeY996 2011
 *
 ******************************************/

/*************************************************************************************************************************************************
 * DEFINICION DE WIKIPEDIA:
 * La extensi�n PHP Data Objects (PDO) define un interfaz ligera, para tener acceso a bases de datos en PHP. 
 * Cada controlador de base de datos que implementa la interfaz PDO puede exponer base de datos espec�ficas como funciones de extensi�n regular. 
 * Tenga en cuenta que no puede realizar las funciones de base de datos utilizando la extensi�n PDO por s� mismo, 
 * debe utilizar un controlador PDO de base de datos espec�fica para tener acceso a un servidor de base de datos.
 * PDO proporciona una capa de abstracci�n acceso a datos, que significa que, independientemente de la base de datos que est� utilizando, 
 * se utiliza las mismas funciones para realizar consultas y obtener datos. PDO no proporciona una abstracci�n base de datos; 
 * esto no reescribe SQL o emular caracter�sticas faltantes. Debe usar una capa de abstracci�n en toda regla, si necesita esto.
 * PDO con PHP 5.1, est� disponible como una extensi�n PECL para PHP 5.0; PDO requiere las caracter�sticas nuevas de OO en el n�cleo de PHP 5, 
 * y as� no correr con versiones anteriores de PHP. 
 ************************************************************************************************************************************************/

//First you need include the class file
require("pdo_database.class.php");

//Intance the class
$db = new wArLeY_DBMS("mysql", "10.33.133.133", "test", "root", "", "");
$dbCN = $db->Cnxn(); //This step is neccesary for create connection to database, and getting the errors in methods.
if($dbCN==false){
	die("Error: Cant connect to database.");
}

//Each instruction that you execute you can try print this line, for get the latest error
echo $db->getError(); //Show error description.

//You can create tables and execute all sql statements
//Examples:

//Droping tables
$db->query('DROP TABLE TB_USERS;');

//Create tables
$query_create_table = <<< EOD
CREATE TABLE TB_USERS (
  ID INTEGER NOT NULL,
  NAME VARCHAR(100) NOT NULL,
  ADDRESS VARCHAR(100) NOT NULL,
  COMPANY VARCHAR(100) NOT NULL
);
EOD;
$db->query($query_create_table);

//Alter tables
$db->query('ALTER TABLE TB_USERS ADD CONSTRAINT INTEG_13 PRIMARY KEY (ID);');

//You can insert data in table with two methods...
//Method 1
$db->query("INSERT INTO TB_USERS (ID, NAME, ADDRESS, COMPANY) VALUES (0, 'Evert Ulises', 'Tetameche #3035 Culiacan Sinaloa', 'Freelancer');");
//Method 2					table			new data [field=data]
$getInsertedId = $db->insert("TB_USERS", "ID=0, NAME='German Soto', 'Tetameche #3035 Culiacan Sin. Mexico', 'Freelancer'");
//IMPORTANT: For getting the currently id inserted is neccessary define the id field how autoincrement.

//If you need get rows from query...
$rs = $db->query("SELECT * FROM TB_USERS");
foreach($rs as $row){
	$tmp_id = $row["ID"];
	$tmp_name = $row["NAME"];
	
	echo "The user ($tmp_id) is named: $tmp_name<br>";
}
//Once that you have execute any query, you can get total rows.
echo "Total rows: " . $db->rowcount() . "<br>";
$rs = null;

//You can delete rows from table with two methods...
//Method 1
$db->query("DELETE FROM TB_USERS WHERE ID=1;");
//Method 2						table		condition without "WHERE"
$getAffectedRows = $db->delete("TB_USERS", "ID=1");
$getAffectedRows = $db->delete("TB_USERS"); //This works too, must be careful!

//You can update rows from table with two methods...
//Method 1
$db->query("UPDATE TB_USERS SET COMPANY='Freelancer MX' WHERE ID=2;");
//Method 2						table		set new data [field=data]				condition without "WHERE"
$getAffectedRows = $db->update("TB_USERS", "NAME='wArLeY996',COMPANY='Freelancer MX'", "ID=2");
$getAffectedRows = $db->update("TB_USERS", "NAME='wArLeY996',COMPANY='Freelancer MX'"); //This works too, must be careful!

//You can get the latest id inserted in your table...
$latestInserted = $db->getLatestId("pruebas","id");
//IMPORTANT: For getting the latest id inserted is neccessary define the id field how autoincrement.


#------------------------------------------ METHODS ANTI SQL INJECTIONS -----------------------------------------------------------------------
#IMPORTANT: the delimiter is "@", is neccessary apply htmlentities to strings parameters or replace this character.
#METHOD: query_secure, "first_param": Query statement, "second_param": array with params, "third_param": if you specify true, you can get the recordset, else you get true.
#The "second_param": this array must be contain: [Parameter in the sql statement]@[Value]@[Type value (STR->string or INT->integers)]
#The "third_param": this isnot required, default value is false, you need switch to true value for get the recordset
#----------------------------------------------------------------------------------------------------------------------------------------------
//Insert Anti SQL Injections (prevent sql injections from advanced users!)
$params = array(":id@0@INT", ":nombre@Hola Mundo@STR");
$getId = $db->query_secure("INSERT INTO pruebas (id,name) VALUES(:id,:nombre);", $params, false);
echo "Insertado -> " .$getId . "<br />";
echo $db->getError();

//Update & Delete works fine but not return the affected rows, just return false if fails.
$params = array(":id@10@INT", ":nombre@MACP@STR");
$affected = $db->query_secure("UPDATE pruebas SET name=:nombre WHERE id>:id;", $params, false);
var_dump($affected);
echo "Afectados -> " . $result = (($affected===false) ? "NO" : "YES") . "<br />";
echo $db->getError();

//Querys Anti SQL Injections (prevent sql injections from advanced users!)
$params = array(":id@2@INT");
$rows = $db->query_secure("SELECT id,name FROM pruebas WHERE id > :id;", $params, true);
if($rows!=false){
	foreach($rows as $row){
		$name = $row["name"];
		echo $name . "<br />";
		$count++;
	}
}
$rows = null;
echo $db->getError();


//If you need get columns name, you can do it...
$column_array = $db->columns("TB_USERS");
if($column_array!=false){
	foreach($column_array as $column){
		echo "$column<br>";
	}
}
else{
	echo "ERROR";
}
$column_array = null;

//If you need get all tables from you database...
$rs = $db->ShowTables("DB_NAME");  //Depending of your type database you can specify the database
foreach($rs as $row){
	$tmp_table = $row[0];
	
	echo "The table from database is: ($tmp_table)<br>";
}

//If you need get all databases...
$rs = $db->ShowDBS();  //Depending of your type database you can get results
foreach($rs as $row){
	$tmp_table = $row[0];
	
	echo "Database named: ($tmp_table)<br>";
}

//Disconnect from database
$db->disconnect();



/******************************************
 * 
 *		INSTRUCTIONS
 *
 ******************************************/

 #Just in spanish because my english is so poor... :$
 
 
/*******************************************/
#		CONFIGURANDO "mssql" EN WINDOWS		/
/*******************************************/
# Si "php_pdo_mssql" no esta corriendo... 
# Abrir el directorio: C:\xampp\php\ext\php_pdo_mssql_new.dll
# Renombrar el archivo: php_pdo_mssql.dll a php_pdo_mssql_new.dll 
# Abrir el php.ini y agregar la extension:
# extension=php_pdo_mssql_new.dll
# Copiar el archivo "ntwdblib.dll" en el mismo directorio de extensiones y en el system32
# Reiniciar el webserver y listo!

/*******************************************/
#		CONFIGURANDO "sqlsrv" EN WINDOWS	/
/*******************************************/
# Si "php_pdo_sqlsrv" no esta corriendo... abrir el php.ini y agregar la extension:
# extension=php_pdo_sqlsrv_53_ts_vc6.dll
# Agregar el dll del mismo nombre en el directorio: "php/ext/"
# Reiniciar el webserver y listo!
?>
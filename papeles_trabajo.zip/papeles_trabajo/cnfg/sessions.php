<?php
class Session {
	/**********************************************
	* Author..: leapinglangoor
	* Date....: 30th May 2005
	* Ver.....: v1.00
	**********************************************/

    public function Session(){
        session_start();
    }

    public function set_var($var_name, $var_val){
        if(!$var_name || !$var_val){
            return false;
        }
        $_SESSION[$var_name] = $var_val;
    }

    public function get_var($var_name){
        return $_SESSION[$var_name];
    }

    public function del_var($var_name){
        unset($_SESSION[$var_name]);
    }

    public function del_vars($arr){
        if( !is_array($arr)){
            return false;
        }
        foreach($arr as $element){
            unset($_SESSION[$element]);
        }
        return true;
    }

    public function del_all_vars(){
        del_all_vars();
    }

    public function end_session(){
        $_SESSION = array();
        session_destroy();
    }
}
?>
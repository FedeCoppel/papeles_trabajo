<?php
//papeles de trabajo
/*
$db_papeles_trab_type = "pg";
$db_papeles_trab_server = "10.44.1.198";
$db_papeles_trab_db = "papeles_trabajo_auditoria";
$db_papeles_trab_user="sysinternet";
$db_papeles_trab_pass="82f96084e26db6299f73e442410e8557";
$db_papeles_trab_port="5432";
*/
$db_papeles_trab_type = "pg";
$db_papeles_trab_server = "10.45.225.7";
$db_papeles_trab_db = "papeles_trabajo_auditoria";
$db_papeles_trab_user="syspersonal";
$db_papeles_trab_pass="d894dab691238a6b66b73b2a94abd3f5";
$db_papeles_trab_port="5432";

// Tmp_Administrativo
/*
$db_type="pg";
$db_server="bdinternet.coppel.com";
$db_db="Tmp_Administrativo";
$db_user="sysinternet";
$db_pass="82f96084e26db6299f73e442410e8557";
$db_port="5432";
*/

$db_type="pg";
$db_server="10.45.225.55";
$db_db="Tmp_Administrativo";
$db_user="syspersonalinternet";
$db_pass="2d348ed7d899b5e7046f9337d6c76d58";
$db_port="5432";

$URL_VERIFY="https://authentication-test.coppel.io:8443/api/sso/v2/verify";
$URL_ME = "https://authentication-test.coppel.io:8443/api/sso/v1/me";
$URL_OUT = "http://127.0.0.1:5555/#/login";
?>
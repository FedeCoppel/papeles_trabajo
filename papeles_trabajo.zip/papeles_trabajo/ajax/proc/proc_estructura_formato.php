<?php
	session_start();
	if(isset($_SESSION['G_nemp'])){	 
	
	require("../../cnfg/pdo_database.class.php");
	require_once "../../cnfg/conexiones.php";
	
	$db_papeles_trab = new wArLeY_DBMS ($db_papeles_trab_type, $db_papeles_trab_server, $db_papeles_trab_db, $db_papeles_trab_user, $db_papeles_trab_pass, $db_papeles_trab_port);
	$dbObj = $db_papeles_trab->Cnxn();

	$error2= $db_papeles_trab->getError();

	if($dbObj==false){
		echo $error2;
		die("Error en la conexion");
	} 

	$varformato = $_GET['pformato'];
	$varpestana = $_GET['ppestana'];
	$separa_pestana =explode("-", $varpestana); 	
	$id_pestana = $separa_pestana[0];

//************************************************************	
	$page = $_GET['page']; // obtiene el numero de paginas
	$sidx = $_GET['sidx']; // get index row - i.e. user click to sort
	$sord = $_GET['sord']; // get the direction
	if(!$sidx) $sidx =1;   // connect to the database
	
	$limit = $_GET['rows']==0 ? $count : $_GET['rows']; // get how many rows we want to have into the grid
	if( $count >0 ) { $total_pages = ceil($count/$limit); } else { $total_pages = 0; }
	if ($page > $total_pages) $page=$total_pages;
	$start = $limit*$page - $limit; // do not put $limit*($page - 1)
	
	
	//$sql = "SELECT nom_columna FROM fun_obtener_columnas($varformato, $id_pestana)";
	
	$sql = "select nom_columna
            from ctl_columnas
            where idu_formato=$varformato AND
            idu_pestana=$id_pestana order by idu_columna";
	
	$result = $dbObj->query($sql);

	$responce->page = $page;
	$responce->total = $total_pages;
	$responce->records = $count; $i=0;
	
//************************************************************	
	
	foreach($result as $row){
		$responce->rows[$i]['cell']=array($row['nom_columna']);
		$i++;
	}
	echo json_encode($responce);
}
else
{
	echo 'La sesi&oacute;n establecida ya expir&oacute;';
}

$db_papeles_trab->disconnect();			
?>

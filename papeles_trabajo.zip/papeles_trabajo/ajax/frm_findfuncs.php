<?php
header("Expires: Tue, 11 Feb 1985 22:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");	
header("Content-Type: text/html; charset=iso-8859-1");
//header("Content-Type: text/html; charset=UTF-8");
?>
<table width="350px" border="1" align="left" style="border: 1px solid #000000; border-collapse: collapse;"
cellspacing="0" cellpadding="0" class="ui-widget ui-widget-content">
	<tr class="ui-layout-north tbHeader">
		<td valign="center" align="center" colspan="3">Busqueda de Funciones JS</td>
	</tr>
	<tr>
		<td valign="center" align="left" colspan="3" style="padding: 5px;">
			Nombre de Funci�n: <input type="text" id="txt_nfunc" class="text_rc" name="txt_nfunc" onkeypress="fnLoadingClean();" value=""/>
		</td>
	</tr>
	<tr>
		<td valign="top" align="center" colspan="3" style="padding: 15px;" id="loading"></td>
	</tr>
	<tr>
		<td valign="center" align="right" colspan="3" style="padding: 10px;">
			<input type="button" id="btn_busqueda" onclick="getFunctionExist();" class="botonsito" value="Busqueda"/>
		</td>
	</tr>
</table>
<script>
$(".botonsito").button();

function fnLoadingClean(){
	var object = document.getElementById("loading");
	if(object.innerHTML!="")
		object.innerHTML = "";
}

function getFunctionExist(){
	var funcion = document.getElementById("txt_nfunc").value;
	if(funcion==""){
		alert("Por favor escriba el nombre de su funcion.");
		return;
	}
	
	var object = document.getElementById("loading");
	object.innerHTML="";
	
	if(isFunction(funcion)){
		object.innerHTML = "<img src='images/icons/icn_error.png' border='0'/>&nbsp;<b>Funcion actualmente en uso.</b><br>";
	}
	else{
		object.innerHTML = "<img src='images/icons/icn_ok.png' border='0'/>&nbsp;<b>Disponible para su implementaci�n.</b><br>";
	}
}

function isFunction(name){
	//Funcion hecha por: Evert Ulises German Soto
	//Que hace: Busca segun el parametro si esta como funcion en tiempo real.
	try{
		if (typeof name == 'string' && eval('typeof ' + name) == 'function') {
			return true;
		}
		else{
			return false;
		}
	}
	catch(e){
		return false;
	}
}
</script>
<script>
	$(function() {
		$("#fecha_calendar").datepicker({ 
			dateFormat: 'dd/mm/yy', 
			changeMonth: true, 
			changeYear: true,
			dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','Sa'],
			monthNames: ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
			monthNamesShort: ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'],
			onSelect: function(dateText, inst){ 
				document.getElementById("txt_date_rpt").value = dateText;
			}
		});
	});
	
	function sendParams(){
		var fecha_selec = document.getElementById("txt_date_rpt").value;
		if(fecha_selec==""){
			alert("Seleccione una fecha, para visualizar el reporte.");
			return;
		}
		cargaAjax('ajax/reportes.php?selec=rpinfrac&date='+fecha_selec+'&titulo=Reporte de Infracciones de Ruta','#centro','');
	}
</script>
<table border="0" align="center" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
	<tr>
		<td align="left"><label style="color: #88B6D9; font-weight:bold;"> Seleccione una fecha:</label></td>
	</tr>
	<tr>
		<td align="center" style="padding-top: 10px;">
			<div id='fecha_calendar'></div>
		</td>
	</tr>
	<tr>
		<td align="right" style="padding-top: 10px;">
			<input type='button' class='btn_jquery' id='btn_busqueda' name='btn_busqueda' value=' Buscar ' onClick="sendParams();"/>
		</td>
	</tr>
</table>
<input type='hidden' name='txt_date_rpt' id='txt_date_rpt' value=''/>
<script>
	$(".btn_jquery").button();
</script>
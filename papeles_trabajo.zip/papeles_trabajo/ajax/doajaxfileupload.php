<?php
/*
	$error = "";

	$msg = "";
	$llave= "";
	$fileElementName = 'fileToUpload';
	$ciclo = $_REQUEST['i'];
	
	if(!empty($_FILES[$fileElementName]['error']))
	{
		switch($_FILES[$fileElementName]['error'])
		{

			case '1':
				$error = 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
				break;
			case '2':
				$error = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
				break;
			case '3':
				$error = 'The uploaded file was only partially uploaded';
				break;
			case '4':
				$error = 'No file was uploaded.';
				break;

			case '6':
				$error = 'Missing a temporary folder';
				break;
			case '7':
				$error = 'Failed to write file to disk';
				break;
			case '8':
				$error = 'File upload stopped by extension';
				break;
			case '999':
			default:
				$error = 'No error code avaiable';
		}
	}else 
	{
		if($_REQUEST['i']!=''){
			$llave= $_POST['ar_nombrearchivo_'.$ciclo];
			//$archivo= limpiar_nb_archivo($_FILES['fileToUpload']['name']);//.$archivo
			$ext= obtener_extension($_FILES['fileToUpload_'.$ciclo]['name']);//.$archivo
			$archivo= $_FILES['fileToUpload_'.$ciclo]['name'];
			//chmod('./peticiones_documentos/'.$llave.'.'.$ext, 0766);
			if(move_uploaded_file($_FILES['fileToUpload_'.$ciclo]['tmp_name'], "./archivos_excel/".$llave.'.'.$ext))
				$msg.=$llave.$archivo;
			else
				$error.="Ocurrio Un Problema Al Subir El Archivo Intente De Nuevo --->".$_FILES['fileToUpload_'.$ciclo]['tmp_name'].'----->'.$llave.'.'.$ext;
		}else{
			$error = 'Intente de Nuevo';

		}
	}		
	echo "{";
	echo				"error: '" . $error . "',\n";
	echo				"msg: '" . $msg . "'\n";
	echo "}";
	
	function obtener_extension($nombre_fichero){
	
	  $ext = substr($nombre_fichero, strrpos($nombre_fichero,".") + 1);
	
		return $ext;
	
	}	
	
	function obtener_sin_extension($nombre_fichero){
	
	  $s_ext = substr($nombre_fichero,0,strrpos($nombre_fichero,".") );
	
		return $s_ext;
	
	}	
*/

	$error = "";

	$msg = "";
	$llave= "";
	$fileElementName = 'fileToUpload_'.$_POST['ciclo'];
	$ciclo = $_POST['ciclo'];
	
	if(!empty($_FILES[$fileElementName]['error']))
	{
		switch($_FILES[$fileElementName]['error'])
		{

			case '1':
				$error = 'The uploaded file exceeds the upload_max_filesize directive in php.ini';
				break;
			case '2':
				$error = 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form';
				break;
			case '3':
				$error = 'The uploaded file was only partially uploaded';
				break;
			case '4':
				$error = 'No file was uploaded.';
				break;

			case '6':
				$error = 'Missing a temporary folder';
				break;
			case '7':
				$error = 'Failed to write file to disk';
				break;
			case '8':
				$error = 'File upload stopped by extension';
				break;
			case '999':
			default:
				$error = 'No error code avaiable';
		}
	}else 
	{
		
			//$llave= $_POST['ar_nombrearchivo'];
			//$archivo= limpiar_nb_archivo($_FILES['fileToUpload']['name']);//.$archivo
			//$ext= obtener_extension($_FILES['fileToUpload']['name']);//.$archivo
			$archivo= $_FILES['fileToUpload_'.$ciclo]['name'];
			//chmod('./peticiones_documentos/'.$llave.'.'.$ext, 0766);
			if(move_uploaded_file($_FILES['fileToUpload_'.$ciclo]['tmp_name'], "./archivos_excel/".$archivo))
				$msg.=obtener_sin_extension($archivo).'|'.$ciclo;
			else
				$error.="Ocurrio Un Problema Al Subir El Archivo Intente De Nuevo --->".$_FILES['fileToUpload_'.$ciclo]['tmp_name'].'----->'.$llave.'.'.$ext;
		
	}		
	echo "{";
	echo				"error: '" . $error . "',\n";
	echo				"msg: '" . $msg . "'\n";
	echo "}";
	
	function obtener_extension($nombre_fichero){
	
	  $ext = substr($nombre_fichero, strrpos($nombre_fichero,".") + 1);
	
		return $ext;
	
	}	
	
	function obtener_sin_extension($nombre_fichero){
	
	  $s_ext = substr($nombre_fichero,0,strrpos($nombre_fichero,".") );
	
		return $s_ext;
	
	}	
	
?>
<style>
	/*.ui-progressbar-value { background-image: url(images/pg_bar01.png); }*/
</style>
<script>
	$(function() {
		$( "#datepicker" ).datepicker();

		$( "#progressbarR" ).progressbar({value: 11 });
		//$("#progressbarR").css({ 'background': 'LightYellow'}); //Fondo del progressbar
		$("#progressbarR > div").css({ 'background': 'url(images/progressbar_red.png) center' }); //Color Principal
		//$("#progressbarR > div").css({ 'background': 'url(images/progressbar_red.png)' });
		
		$( "#progressbarG" ).progressbar({value: 59 });
		$("#progressbarG").css({ 'background': 'LightYellow'}); //Fondo del progressbar
		$("#progressbarG > div").css({ 'background': 'url(images/progressbar_green.png) center' }); //Color Principal
		
		$( "#progressbarB" ).progressbar({value: 40 });
		$("#progressbarB").css({ 'background': 'LightYellow'}); //Fondo del progressbar
		$("#progressbarB > div").css({ 'background': 'url(images/progressbar_blue.png) center' }); //Color Principal

		$('#timepickerej').timepicker({
		
		})
	
	});
</script>
<div id="ejemplo">
<p>Fecha: <input id="datepicker" type="text"></p>
</div>

<!--  <div class="ui-progressbar ui-widget-bar ui-widget-content-bar ui-corner-all">
   <div style="width:45%;" class="ui-progressbar-value ui-widget-header-bar ui-corner-left"></div>
</div>-->
<br/>
<div id="progressbarR"></div>
<div id="progressbarG"></div>
<div id="progressbarB"></div>
<div style="margin-top:10px;">
Time Picker
<br/>
<input type="text" id="timepickerej" />
</div>
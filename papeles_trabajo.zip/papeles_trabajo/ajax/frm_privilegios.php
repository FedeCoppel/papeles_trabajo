<table width="100%" border="1" align="left" style="border: 1px solid #000000; border-collapse: collapse;">
<?php
include("../cnfg/pdo_database.class.php");
$db = new wArLeY_DBMS("sqlite2", "../cnfg/database.sqlite2", "", "", "", "");
$dbObj = $db->Cnxn();
if($dbObj==false){
	echo "Error de Conexion";
	die;
}

$nemp = $_GET['nemp'];
$cade = "";
$count = 0;
$i = 0;

$rs = $db->query("SELECT TB_USERS_PRIVILEGIOS FROM TB_USERS WHERE TB_USERS_NUM_EMPLEADO='$nemp'");
foreach($rs as $row){	
	$privs = $row["TB_USERS_PRIVILEGIOS"];
}

while (floor($privs)>0){
	if($privs%2==1){ if($cade==""){ $cade = "1"; }else{ $cade = $cade ."1"; } }
	else{ if($cade==""){ $cade = "0"; }else{ $cade = $cade ."0"; } }
	$privs = floor($privs/2);
}

$rs = $db->query("SELECT * FROM TB_MENU ORDER BY TB_MENU_ORDEN");
foreach($rs as $row){			
	$orden = $row["TB_MENU_ORDEN"];
	$titulo = $row["TB_MENU_TITULO"];
	$icono = $row["TB_MENU_ICONO"];
	$archivo = $row["TB_MENU_ARCHIVO"];
	
	$selec = substr($cade, $count, 1);
	if($selec==1){ $checked=" checked"; }else{ $checked=""; }
	if(($i % 2)==0){ $bg="#DEECF9"; }else{ $bg="#FFFFFF"; }
?>
	<tr class="table_result" bgcolor="<?php echo $bg; ?>">
		<td valign="center" align="center" width="30px">
			<input type="checkbox" name="chk_privilegios" <?php echo $checked; ?> value="<?php echo $orden; ?>" />
		</td>
		<td valign="center" align="left" width="270px" style="padding: 5px;">
			<?php echo $titulo; ?>
		</td>
		<td valign="center" align="center" width="50px">
			<img src="plugins/jquery-vertical-menu/icons/<?php echo $icono; ?>" title="<?php echo $titulo; ?>" width="36px" height="36px" border="0"/>
		</td>
	</tr>
<?php
	$count++;
	$i++;
}
$rs = null;
$db = null;
?>
</table>
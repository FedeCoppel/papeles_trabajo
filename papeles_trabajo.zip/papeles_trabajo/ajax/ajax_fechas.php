<?php
include("../cnfg/pdo_database.class.php");
$db = new wArLeY_DBMS("sqlite2", "../cnfg/database.sqlite2", "", "", "", "");
$dbObj = $db->Cnxn();
if($dbObj==false){
	echo "Error de Conexion";
	die;
}

switch($_POST['opc']){
	case "insert":
		insertaevento($db, $_POST['evento'],$_POST['inicio'],$_POST['fin']);
		break;
/*	case "actualiza":
		actualizacalendario($db);
		break;*/
	case "updatefecha":
		updatefecha($db, $_POST['id'],$_POST['inicio'],$_POST['fin']);
		break;
	case "eliminaevento":
		eliminaevento($db, $_POST['id']);
		break;
}

function fnFormatDate($strDate){
	$strDate_array = explode("-",$strDate);
	
	$ano = "" . $strDate_array[0];
	$mes = "" . $strDate_array[1];
	$dia = "" . $strDate_array[2];
	
	if(strlen($dia)==1){ $dia="0".$dia;}
	if(strlen($mes)==1){ $mes="0".$mes;}
	if(strlen($ano)==3){ $ano="0".$ano;}
	if(strlen($ano)==2){ $ano="00".$ano;}
	if(strlen($ano)==1){ $ano="000".$ano;}
	
	return $ano . "-" . $mes . "-" . $dia;
}

function insertaevento($db, $evento, $inicio, $fin){
	$sql = "INSERT INTO TB_TIEMPOS (TB_TIEMPOS_EVENTO, TB_TIEMPOS_INICIO, TB_TIEMPOS_FIN) VALUES ('".$evento."', '".fnFormatDate($inicio)."', '".fnFormatDate($fin)."')";
	$db->query($sql);
	echo "OK";
}

function eliminaevento($db, $id){
	$sql = "DELETE FROM TB_TIEMPOS WHERE TB_TIEMPOS_ID='$id'";
	$affected = $db->query($sql);
	echo "OK";
}

function updatefecha($db, $id, $inicio, $fin){
	$inicio = fnFormatDate($inicio);
	$fin = fnFormatDate($fin);
	$sql = "UPDATE TB_TIEMPOS SET TB_TIEMPOS_INICIO='$inicio', TB_TIEMPOS_FIN='$fin' WHERE TB_TIEMPOS_ID='$id'";
	$affected = $db->query($sql);
	echo "OK";
}


?>
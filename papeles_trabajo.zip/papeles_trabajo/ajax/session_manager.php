<?php
header("Expires: Tue, 11 Feb 1985 22:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");	
header("Content-Type: text/html; charset=UTF-8");

$G_nemp = $_GET["nemp"];
$force = $_GET["force"];

$desarrollo = ($_SERVER["SERVER_NAME"]=="localhost" || $_SERVER["SERVER_NAME"]=="127.0.0.1") ? "1" : "0";

function make_token($NumEmp){
	return sha1( md5 ( microtime() . $NumEmp ));
}

function graba_nuevo_empleado($db,$NumEmp,$centro,$puesto){
	$rs_aux = $db->query("SELECT count(*) as cuenta FROM intranet_administracion_usuarios where intranet_administracion_usuarios_numemp=$NumEmp");
	$existencia_persona = 0;
	foreach($rs_aux as $row_aux){
		$existencia_persona = $row_aux['cuenta'];				
	}

	if ($existencia_persona==0){
		$db->query("INSERT INTO intranet_administracion_usuarios (intranet_administracion_usuarios_id,intranet_administracion_usuarios_numemp,intranet_administracion_usuarios_centro,intranet_administracion_usuarios_puesto) VALUES ((SELECT max(intranet_administracion_usuarios_id)+1 FROM intranet_administracion_usuarios),$NumEmp,$centro,$puesto)");
	}
}
	
if($force=="yes" && $G_nemp!=""){
	//Agregar en todas las paginas que lleven sesion
	include('../cnfg/sessions.php');
	$sess = new Session();
	if (!$sess)
		$error_desc = "Ha ocurrido un error al iniciar session!";
	//--------------------------------------------------
	
	include("../cnfg/database.cnfg.php");
	require_once("../cnfg/pdo_database.class.php");
	
	$db = new wArLeY_DBMS($pg_admin_db_type, $pg_admin_db_server, $pg_admin_db_db, $pg_admin_db_user, $pg_admin_db_pass, $pg_admin_db_port);
	$dbObj = $db->Cnxn();
	if($dbObj==false){
		echo "501";
		die;
	}
	
	$db->query("Delete from intranet_administracion_sesiones where intranet_administracion_usuarios_numemp='". $G_nemp ."'");
	$db->query("Delete from intranet_administracion_token where intranet_administracion_usuarios_numemp='". $G_nemp ."'");
	
	if(phpversion()>=5.2){
		//Se consulta el webservice			
		$client = new SoapClient("http://intranet.cln/webservices/personal/wsEmpleadosPb.php?wsdl",array('empleado' => $G_nemp));

		//Envio de parametros al WS
		if($client->Consulta($G_nemp)){
			$funcRet = $client->Consulta($G_nemp);
		}else{
			//Error al Invocar WS
			echo "501";
			die;
		}

		$sess->set_var('G_nemp', $G_nemp);
		$sess->set_var('G_user', ucwords(strtolower($funcRet->Listado->nombre)));
		$sess->set_var('G_name', ucwords(strtolower($funcRet->Listado->nombre . " " . $funcRet->Listado->apellidopaterno . " " . $funcRet->Listado->apellidomaterno)));
		$sess->set_var('G_centro', $funcRet->Listado->numerocentro);
		$sess->set_var('G_centrodesc', ucwords(strtolower($funcRet->Listado->descripcioncentro)));
		$sess->set_var('G_seccion', $funcRet->Listado->seccioncentro);
		$sess->set_var('G_puesto', $funcRet->Listado->numeropuesto);
		$sess->set_var('G_puestodesc', ucwords(strtolower($funcRet->Listado->descripcionpuesto)));
		$sess->set_var('G_sexo', $funcRet->Listado->sexo);
		$sess->set_var('G_ipfrom', $_SERVER['REMOTE_ADDR']);
		$sess->set_var('G_timeout', time());
		$tkn = make_token($G_nemp);
		$sess->set_var('G_token',$tkn);
		
		graba_nuevo_empleado($db,$G_nemp,$funcRet->Listado->numerocentro,$funcRet->Listado->numeropuesto);	
		$tks=$G_nemp."|".ucwords(strtolower($funcRet->Listado->nombre)) ."|".ucwords(strtolower($funcRet->Listado->nombre . " " . $funcRet->Listado->apellidopaterno . " " . $funcRet->Listado->apellidomaterno)) ."|".$funcRet->Listado->numerocentro ."|".ucwords(strtolower($funcRet->Listado->descripcioncentro)) ."|".$funcRet->Listado->seccioncentro ."|".$funcRet->Listado->numeropuesto ."|".ucwords(strtolower($funcRet->Listado->descripcionpuesto)) ."|".$funcRet->Listado->sexo ."|".$_SERVER['REMOTE_ADDR']."|".time();

		$db->query("Insert Into intranet_administracion_sesiones (intranet_administracion_usuarios_numemp, intranet_administracion_sesiones_tiempo, intranet_administracion_sesiones_macip, intranet_administracion_sesiones_desarrollo) Values('". $G_nemp ."',now(),'".trim($_SERVER['REMOTE_ADDR'])."','".$desarrollo."')");
		$db->query("Insert Into intranet_administracion_token (intranet_administracion_usuarios_numemp, intranet_administracion_token, intranet_administracion_tokenstring) Values('". $G_nemp ."','".$tkn."','".$tks."')");

		echo "996";
	}else{
		require_once('../cnfg/nusoap.php');

		$proxyhost = '';
		$proxyport = '';
		$proxyusername = '';
		$proxypassword = '';
		
		$client = null;
		//URL de webservice
		$soapUrl = 'http://intranet.cln/webservices/personal/wsEmpleadosPb.php?wsdl';

		$client = new nusoap_client($soapUrl, true, $proxyhost, $proxyport, $proxyusername, $proxypassword);
		if ($client->fault) {
			//Error al Invocar WS
			echo "501";
			die;
		}else{
			$err = $client->getError();
			if ($err) {
				//Error al crear Cliente de WS
				echo "502";
				die;
			}
		}
		
		//Envio de parametros al WS
		$funcRet = $client->call('Consulta', array('empleado' => $G_nemp));
		
		$sess->set_var('G_nemp', $G_nemp);
		$sess->set_var('G_user', ucwords(strtolower($funcRet["Listado"]["nombre"])));
		$sess->set_var('G_name', ucwords(strtolower($funcRet["Listado"]["nombre"] . " " . $funcRet["Listado"]["apellidopaterno"] . " " . $funcRet["Listado"]["apellidomaterno"])));
		$sess->set_var('G_centro', $funcRet["Listado"]["numerocentro"]);
		$sess->set_var('G_centrodesc', ucwords(strtolower($funcRet["Listado"]["descripcioncentro"])));
		$sess->set_var('G_seccion', $funcRet["Listado"]["seccioncentro"]);
		$sess->set_var('G_puesto', $funcRet["Listado"]["numeropuesto"]);
		$sess->set_var('G_puestodesc', ucwords(strtolower($funcRet["Listado"]["descripcionpuesto"])));
		$sess->set_var('G_sexo', $funcRet["Listado"]["sexo"]);
		$sess->set_var('G_ipfrom', $_SERVER['REMOTE_ADDR']);
		$sess->set_var('G_timeout', time());
		$tkn = make_token($G_nemp);
		$sess->set_var('G_token',$tkn);

		graba_nuevo_empleado($db,$G_nemp,$funcRet["Listado"]["numerocentro"],$funcRet["Listado"]["numeropuesto"]);	
		$tks=$G_nemp."|". ucwords(strtolower($funcRet["Listado"]["nombre"])) ."|".ucwords(strtolower($funcRet["Listado"]["nombre"] . " " . $funcRet["Listado"]["apellidopaterno"] . " " . $funcRet["Listado"]["apellidomaterno"])) ."|".$funcRet["Listado"]["numerocentro"] ."|".ucwords(strtolower($funcRet["Listado"]["descripcioncentro"])) ."|".$funcRet["Listado"]["seccioncentro"] ."|".$funcRet["Listado"]["numeropuesto"] ."|".ucwords(strtolower($funcRet["Listado"]["descripcionpuesto"])) ."|".$funcRet["Listado"]["sexo"] ."|".$_SERVER['REMOTE_ADDR']."|".time();
		
		$db->query("Insert Into intranet_administracion_sesiones (intranet_administracion_usuarios_numemp, intranet_administracion_sesiones_tiempo, intranet_administracion_sesiones_macip, intranet_administracion_sesiones_desarrollo) Values('". $G_nemp ."',now(),'".trim($_SERVER['REMOTE_ADDR'])."','".$desarrollo."')");
		$db->query("Insert Into intranet_administracion_token (intranet_administracion_usuarios_numemp, intranet_administracion_token, intranet_administracion_tokenstring) Values('". $G_nemp ."','".$tkn."','".$tks."')");

		echo "996";
	}
	$db->disconnect();
	die;
}

if($G_nemp!=""){
?>
	<h4>Usuario logueado en otro equipo</h4>
	
	<p>Para iniciar sesion en este equipo y cerrar su sesion activa haga click en "Aceptar" de lo contrario haga click en "Cancelar".</p>
	<div id="spinner_session" style="float:right; padding-right:10px;">
		<input type="button" class="botonsito" id="btn_aceptar" onclick="fnForceCloseSession('<?php echo $G_nemp; ?>');" value="Aceptar"/>
		&nbsp;&nbsp;
		<input type="button" class="botonsito" id="btn_cancelar" onclick="fnCancelActionSession();" value="Cancelar"/>
	</div>
	<script> 
		$(".botonsito").button(); 
		
		function fnForceCloseSession(nemp){
			$("#spinner_session").html("<img src='images/loading.gif' border='0' align='absmiddle' width='24px' style='vertical-align:middle;margin-bottom: .25em;'/>&nbsp;<b>Iniciando nueva sesion...</b>");
			$.ajax({
				type: "GET",
				url: "ajax/session_manager.php?force=yes&nemp="+nemp,
				async: true,
				success: function (data){
					var encryptado = parseInt(data);
					if(encryptado==996){
						location.href = "index.php";
					}else{
						$("#spinner_session").html('<a style=\'color:#FF0000;\'><b>Ha ocurrido un error.</b>&nbsp;</a><input type="button" class="botonsito" id="btn_aceptar" onclick="fnForceCloseSession(\'<?php echo $G_nemp; ?>\');" value="Aceptar"/>&nbsp;&nbsp;<input type="button" class="botonsito" id="btn_cancelar" onclick="fnCancelActionSession();" value="Cancelar"/>');
						$(".botonsito").button();
					}
				}
			});
		}
		
		function fnCancelActionSession(){
			$("#tmp_file").dialog('close');			
		}
	</script>
<?php 
}else{
?>
	<h4 style='color:#FF0000;'>Ha ocurrido un error inesperado.</h4>
	<div id="spinner_session" style="float:right; padding-right:10px;">
		<input type="button" class="botonsito" id="btn_cancelar" onclick="fnCancelActionSession();" value="Salir"/>
	</div>
	<script>
		$(".botonsito").button();
		function fnCancelActionSession(){
			$("#tmp_file").dialog('close');			
		}
	</script>
<?php 
}
?>
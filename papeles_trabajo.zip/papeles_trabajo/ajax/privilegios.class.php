<?php
Class BuildMenu{	
	//--- Iniciamos estructura del menu ---//
	function inicio(){
		$aux = "<div class='sc_menu'>";
		return $aux;
	}
	
	//--- Cada uno de las opciones del menu es agregado aqui, solo continue la secuencia ---//
	function get_menu($index){
		$db = new wArLeY_DBMS("sqlite2", "cnfg/database.sqlite2", "", "", "", "");
		$dbObj = $db->Cnxn();
		if($dbObj==false){
			echo "Error de Conexion";
			die;
		}
		
		$count = 0;
		$rs = $db->query("SELECT * FROM TB_MENU");
		foreach($rs as $row){
			$a[$count] = $this->option($row["TB_MENU_TITULO"],$row["TB_MENU_ICONO"],$row["TB_MENU_ARCHIVO"]);
			$count++;
		}
		$rs = null;
		return $a[$index];
	}

	//--- Cerramos estructura del menu ---//
	function cierre(){
		$aux = " </div>";
		return $aux;
	}
	
	//--- Construye la opcion segun el titulo, icono y archivo ---//
	function option($title, $icon, $file){
		if($file!=""){ $file = " onclick=cargaAjax('$file','#centro','')"; }
		return "<a title='$title' href='javascript:;' $file >
					<img src='plugins/jquery-vertical-menu/icons/$icon' alt='$title' width='48' height='48' />
					<div class='titulo-menu'>$title</div>
				</a>";
	}
}
?>
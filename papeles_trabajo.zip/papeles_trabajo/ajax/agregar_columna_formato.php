<?php
session_start();

//if(isset($_SESSION['G_nemp'])){	
 
require("../cnfg/pdo_database.class.php");
require_once "../cnfg/conexiones.php";

$db_papeles_trab = new wArLeY_DBMS ($db_papeles_trab_type, $db_papeles_trab_server, $db_papeles_trab_db, $db_papeles_trab_user, $db_papeles_trab_pass, $db_papeles_trab_port);
$dbObj = $db_papeles_trab->Cnxn();

$error2= $db_papeles_trab->getError();

if($dbObj==false){
	echo $error2;
	die("Error en la conexion");
} 

switch($_REQUEST['opc']){	
	case "carga_formato":
		carga_formato($db_papeles_trab, $_GET['formato']);
		$db_papeles_trab->disconnect();			
		die;
		break;
	case "Insertar_columna":
		
		break;
}

	$selec_formato = "SELECT * FROM fun_obtenerformato(NULL,NULL)";
	$res_formato = $db_papeles_trab->query($selec_formato);	
	
	foreach($res_formato as $f)
	{
		$slt_formato.= "<option value='".$f['idu_formato']."' >".$f['nom_formato']."</option>";
	}
			
	function carga_formato($db_papeles_trab, $formato){
		$select_pestana = "select idu_pestana, nom_pestana from ctl_pestanas where idu_formato = ".$formato;
		
		$res_formato_id= $db_papeles_trab->query($select_pestana);
		
		foreach ($res_formato_id as $resp) //llena el combo formatos
		{
			$slt_pestana.= "<option value='".$resp['idu_pestana'].'-'.$resp['nom_pestana']."' >".$resp['nom_pestana']."</option>";				
		}	
		echo !empty($slt_pestana) ? "<select id='cbopestanas' style='width:200px' msj='Pesta&ntilde;a'><option value='0'>SELECCIONE</option>
		$slt_pestana</select>" : "<select id='cbopestanas' style='width:200px' msj='Pesta�a' ><option value='0'>SELECCIONE</option></select>";
	}
		
	echo '<div class="informacion">
	<div class="ui-widget-header" style="text-align:center; padding: 4px; margin-bottom: 10px;">AGREGAR COLUMNA A FORMATO</div>
		<div  id="div_contenido" align="center" >
				<table>
					<tr>
						<td align="left">Nombre del Riesgo:</td>
						<td><select id="cboformato" ><option value="0-0">SELECCIONE</option><'.$slt_formato.'></select></td>
					</tr>  
					<tr>
						<td align="left">Pesta&ntilde;as:</td>
						<td><span id="sp_formato"><select id="cbopestanas" ><option value="0">SELECCIONE</option><'.$slt_pestana.'></select></span></td>
					</tr>					
					<tr> 
						<td align="left">Nueva Columna:</td>
						<td align="left"><input type="text" align="left" id="txt_nueva_columna" onkeypress="return fKeyPress(event)";></td>
					</tr>
					<tr> 
						<td align="left">Tipo de Dato:</td>
						<td><select id="cbotipodato" >
							<option value="0">SELECCIONE</option>
							<option value="1">Num&eacute;rico</option>
							<option value="2">Texto</option>
							<option value="3">Importe</option>
							<option value="4">Fecha</option>
							<option value="5">Tel&eacute;fono</option>
						</select></td>
					</tr>
					<tr> 
						<td align="left">Caracteres:</td>
						<td align="left"><input type="text" align="left" id="txt_caracteres" maxlength="4" onkeypress="return justNumbers(event);">  
						<input type="button" align="center" id="btn_guardar" value="Guardar" style="margin-left:30px"></td>
					</tr>
					
				</table><br>	
				<div id="tabla_columnas"></div>
		</div>
	</div>';	
/*}else{		
	echo 'La sesi&oacute;n establecida ya expir&oacute;'; 
}*/
//$db_papeles_trab->disconnect();
		
?>

<script>
$(document).ready(function(){
	$("#btn_guardar").button();
	
	document.getElementById('txt_caracteres').disabled = true;		
})
 
$('#btn_guardar').click(function (){
	if($('#txt_nueva_columna').val() != '' && $('#txt_caracteres').val() != '' && $('#cbotipodato').val() != '0' && $('#cboformato').val() != '0-0')
	{
		//alerta('click en guardar', 'ATENCION');
		var varformato = $('#cboformato').val();
		var varpestana = $('#cbopestanas').val();
		var varnom_columna = $('#txt_nueva_columna').val();
		var vartipo_dato = $('#cbotipodato').val();
		var varcaracteres = $('#txt_caracteres').val();
		var separapestana = varpestana.split("-");
		//$('#div_contenido').load ('papeles_trabajo/componentes/agregar_columna_formato.php?opc=insertar_columna&formato='+formato+'&pestana='+pestana+'&nom_columna='+nom_columna+'&tipo_dato='+tipo_dato+'&caracteres='+caracteres);
		//return false;
			
		$.ajax({			
				url: 'papeles_trabajo/componentes/agregar_columna_formato.php',
				async: false,	
				type: 'GET',			
				dataType: 'html',
				data: {opc:'Insertar_columna',
						formato:varformato, 
						pestana:varpestana, 
						nom_columna:varnom_columna, 
						tipo_dato:vartipo_dato, 
						caracteres:varcaracteres
					},
				success: function(respuesta){
					if (respuesta==1){							
						alerta('Guardo Correctamente','Aviso');
 						carga_grid(varformato, separapestana[0]);
						limpiar_combos();
					}
					else
					{	alerta('No fue posible Guardar', 'Aviso');		}
				}
			});	
		
		
	}
	else
	{	alerta('Verifique los datos para guardar'); }
})


$('#cboformato').change(function (){		
	var formato = $(this).val();		
	//$('#sp_formato').html("<select id='cbo_formato' style='width:200px' disabled><option value='0'>Cargando</option></select>");
	$('#sp_formato').load ('papeles_trabajo/ajax/agregar_columna_formato.php?opc=carga_formato&formato='+formato); 
	$("#grid_areas").jqGrid("clearGridData");
	//$('#tabla_columnas').load('proc_estructura_formato.php?pformato='+formato);
})
	
$('#cbotipodato').change(function (){
	var tipo = $('#cbotipodato').val();
	$('#txt_caracteres').removeAttr("disabled");	
	switch(tipo)
	{
		case '1':
			document.getElementById('txt_caracteres').disabled = true;
			$('#txt_caracteres').val('0');
			break;
		case '2':
			document.getElementById('txt_caracteres').disabled = false;
			$('#txt_caracteres').val('');
			break;
		case '3':
			document.getElementById('txt_caracteres').disabled = true;
			$('#txt_caracteres').val('0');
			break;
		case '4':
			document.getElementById('txt_caracteres').disabled = true;
			$('#txt_caracteres').val('30');
			break;
		case '5':
			document.getElementById('txt_caracteres').disabled = true;
			$('#txt_caracteres').val('0');
			break;
	
	}	
})

function limpiar_combos()
{
	document.getElementById('cboformato').options.selectedIndex = 0; 
	document.getElementById('cbopestanas').options.selectedIndex = 0; 
	$('#txt_nueva_columna').val('');	
	document.getElementById('cbotipodato').options.selectedIndex = 0; 
	$('#txt_caracteres').val('');	
	document.getElementById('txt_caracteres').disabled = true;	
	/*
	$('#cboformato').val()
	$('#cbopestanas').val()
	$('#txt_nueva_columna').val() 
	$('#cbotipodato').val() 
	$('#txt_caracteres').val() 
	*/
}

function justNumbers(e)
{	
	var keynum = window.event ? window.event.keyCode : e.which;
	//alert(keynum);
	if ((keynum == 8) || (keynum == 0))
	{
		return true;
	}
	else if(keynum == 13)
	{
		$('#btn_guardar').focus();
	}
	return /\d/.test(String.fromCharCode(keynum));
}

function fKeyPress(e){
	var evt = (e) ? e : event
	var dKey = (evt.which) ? evt.which : evt.keyCode;
	if(dKey==13) return;
	
	var arreglo="A�BCDE�FGHI�JGKLMN�O�PQRSTU�VWXYZa�bcde�fghi�jklmn�o�pqrstu�vwxyz1234567890";
	if(dKey==8 || dKey==9 || dKey==95 || dKey==32)return; //Permite pulsacion de Backspace y Tab
	
	if (document.all) { //IE
		if(arreglo.indexOf(String.fromCharCode(dKey),0)!=-1){ event.returnValue = true;	}
		else{ event.returnValue = false; }
	}
	else { //Mozilla
		if(arreglo.indexOf(String.fromCharCode(dKey),0)==-1){ if (e.cancelable) { e.preventDefault(); }	}
	}
}


$('#cbopestanas').change(function (){	
	var formato = $('#cboformato').val();
	var pestana = $(this).val();		
	////$('#sp_formato').html("<select id='cbo_formato' style='width:200px' disabled><option value='0'>Cargando</option></select>");
	//$('#sp_formato').load ('papeles_trabajo/ajax/agregar_columna_formato.php?opc_f=carga_columnas&formato='+formato+'&pestana='+pestana); 
	 carga_grid(formato, pestana);
	//limpiar_combos();	
 })

function carga_grid(formato_p, pestana_p){
	var formato  = formato_p;
	var pestana = pestana_p;
  	$('#tabla_columnas').html('<center><table id=\"grid_areas\"></table></center>');
	  $('#grid_areas').jqGrid({
   		url: 'papeles_trabajo/ajax/proc/proc_estructura_formato.php?pformato='+formato+'&ppestana='+pestana
 		  , datatype: 'json'
   		, colNames:['Columnas']
		, colModel:[{name:'nom_columna',index:'nom_columna', align:'center', sortable:true, width:"300px"}]
		, viewrecords: true
	   , sortorder: 'ASC'
	   , rowNum:100
	   , pager: '#pager_grid_areas'
	   , height:true
	   , caption: ''})
}
</script>


<?php
header("Expires: Tue, 11 Feb 1985 22:00:00 GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");	
header("Content-Type: text/html; charset=iso-8859-1");
//header("Content-Type: text/html; charset=UTF-8");
?>
<table width="350px" border="1" align="left" style="border: 1px solid #000000; border-collapse: collapse;"
cellspacing="0" cellpadding="0" class="ui-widget ui-widget-content">
	<tr class="ui-layout-north tbHeader">
		<td valign="center" align="center" colspan="3">Configuraci�n de Menu</td>
	</tr>
	<tr>
		<td valign="center" align="left" colspan="3" style="padding: 15px;">
			N�mero de Empleado: <input type="text" id="txt_nemp" class="text_rc" name="txt_nemp" value="" maxlength="8" onfocus="document.getElementById('getPrivilegios').innerHTML='';" onblur="getPrivilegios();"/>
		</td>
	</tr>
	<tr>
		<td valign="top" align="left" colspan="3" style="padding: 5px;" id="getPrivilegios"></td>
	</tr>
	<tr>
		<td valign="center" id="loading" align="right" colspan="3" style="padding: 10px;">
			<input type="button" id="btn_guardar" onclick="getCheckString('chk_privilegios');" class="botonsito" value="guardar"/>
		</td>
	</tr>
</table>
<script>
$(".botonsito").button();

/*
var object = document.getElementById("getPrivilegios");
$.when($.ajax("ajax/frm_privilegios.php?nemp=93858132")).done(function(data){
	object.innerHTML = data;
	alert("Se termino la carga")
});
*/

function getCheckString(chkName){
	var txt_nemp = document.getElementById("txt_nemp").value;
	if(txt_nemp==""){
		alert("Por favor escriba un numero de empleado.");
		return;
	}
	if(isNaN(txt_nemp)){
		alert("Por favor escriba un numero de empleado valido.");
		return;
	}
	if(txt_nemp<90000000){
		alert("Por favor escriba un numero de empleado valido.");
		return;
	}
	
	var cadena = "";
	$("input[name="+chkName+"]").each(function(){
		var result = "0";
		if(this.checked){ result = "1"; }
		if(cadena==""){	cadena = result; }else{ cadena = cadena + "" + result; }	
	});
	
	if(cadena!=""){
		var object = document.getElementById("loading");
		object.innerHTML="";
		object.innerHTML="<div align=\"center\" valign=\"middle\"><img src=\"images/loading.gif\" border=\"0\"></div>";
		var genera = "ajax/proc_genera_priv.php?nemp="+ txt_nemp +"&arg="+ cadena;
		$.ajax({
			type: "GET",
			url: genera,
			async: true,
			success: function (data){
				object.innerHTML = data;
				$(".botonsito").button();
			}
		});
	}
}
function getPrivilegios(){
	var txt_nemp = document.getElementById("txt_nemp").value;
	if(txt_nemp==""){
		alert("Por favor escriba un numero de empleado.");
		return;
	}
	if(isNaN(txt_nemp)){
		alert("Por favor escriba un numero de empleado valido.");
		return;
	}
	if(txt_nemp<90000000){
		alert("Por favor escriba un numero de empleado valido.");
		return;
	}	

	var object = document.getElementById("getPrivilegios");
	object.innerHTML="<div align=\"center\" valign=\"middle\"><img src=\"images/loading.gif\" border=\"0\"></div>";
	var priv = "ajax/frm_privilegios.php?nemp="+ txt_nemp;	
	$.ajax({
		type: "GET",
		url: priv,
		async: true,
		success: function (data){
			$("#getPrivilegios").fadeOut("slow", function(){
				$("#getPrivilegios").fadeIn("slow");
				object.innerHTML = data;
			});
		}
	});	
}
</script>
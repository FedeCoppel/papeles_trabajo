<?php
include("../cnfg/pdo_database.class.php");
$db = new wArLeY_DBMS("sqlite2", "../cnfg/database.sqlite2", "", "", "", "");
$dbObj = $db->Cnxn();
if($dbObj==false){
	echo "Error de Conexion";
	die;
}
	
$val = $_GET['arg'];
$nemp = $_GET['nemp'];

$priv = 0;
$k=1;
for ($i=0;$i<strlen($val);$i++){
	$priv = $priv + $val[$i]*$k;
	$k*=2;
}

$rs = $db->update("TB_USERS","TB_USERS_PRIVILEGIOS='$priv'","TB_USERS_NUM_EMPLEADO='$nemp'");
$rs = null;
$db = null;
?>
<input type="button" id="btn_guardar" onclick="getCheckString('chk_privilegios');" class="botonsito" value="guardar"/>